namespace GUI_Template
{
    partial class MainPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainPanel));
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage_Main = new System.Windows.Forms.TabPage();
            this.pnlSetColor = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlSetColor1 = new System.Windows.Forms.Panel();
            this.btnBlack1 = new System.Windows.Forms.Button();
            this.btnWhite1 = new System.Windows.Forms.Button();
            this.btnPurple1 = new System.Windows.Forms.Button();
            this.btnBlue1 = new System.Windows.Forms.Button();
            this.btnGreen1 = new System.Windows.Forms.Button();
            this.btnYellow1 = new System.Windows.Forms.Button();
            this.btnOrange1 = new System.Windows.Forms.Button();
            this.btnRed1 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.chbAutoColor = new System.Windows.Forms.CheckBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtGetILed3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblVGetCH2 = new System.Windows.Forms.Label();
            this.txtGetILed2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblVGetCH1 = new System.Windows.Forms.Label();
            this.lblUnits1 = new System.Windows.Forms.Label();
            this.txtGetILed1 = new System.Windows.Forms.TextBox();
            this.btnLEDSlewRate = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.txtLEDSlewRate = new System.Windows.Forms.TextBox();
            this.pnlLEDControl3 = new System.Windows.Forms.Panel();
            this.lblMinIsetLED3 = new System.Windows.Forms.Label();
            this.txtIsetLED3 = new System.Windows.Forms.TextBox();
            this.lblMaxIsetLED3 = new System.Windows.Forms.Label();
            this.sldrIsetLed3 = new System.Windows.Forms.TrackBar();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pnlLedLabel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblString3LblforPanel = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.pnlLedLabel2 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.lblString2LblforPanel = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pnlLEDControl1 = new System.Windows.Forms.Panel();
            this.lblMinIsetLED1 = new System.Windows.Forms.Label();
            this.lblMaxIsetLED1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtIsetLED1 = new System.Windows.Forms.TextBox();
            this.lblVsetCH1 = new System.Windows.Forms.Label();
            this.sldrIsetLed1 = new System.Windows.Forms.TrackBar();
            this.pnlLEDControl2 = new System.Windows.Forms.Panel();
            this.lblMinIsetLED2 = new System.Windows.Forms.Label();
            this.lblMaxIsetLED2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtIsetLED2 = new System.Windows.Forms.TextBox();
            this.sldrIsetLed2 = new System.Windows.Forms.TrackBar();
            this.lblVsetCH2 = new System.Windows.Forms.Label();
            this.pnlLedLabel1 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.lblString1LblforPanel = new System.Windows.Forms.Label();
            this.cmbMainUpdateRate = new System.Windows.Forms.ComboBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.pnlConnect = new System.Windows.Forms.Panel();
            this.btnSetupConnection = new System.Windows.Forms.Button();
            this.MainTimer = new System.Windows.Forms.Timer(this.components);
            this.GraphTimer = new System.Windows.Forms.Timer(this.components);
            this.btnSaveDefaults = new System.Windows.Forms.Button();
            this.btnResetDefaults = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.prbConnectStatus = new System.Windows.Forms.ProgressBar();
            this.pnlLicense = new System.Windows.Forms.Panel();
            this.rtxtLicense = new System.Windows.Forms.RichTextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.btnLicenseDisagree = new System.Windows.Forms.Button();
            this.btnLicenseAgree = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage_Main.SuspendLayout();
            this.pnlSetColor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlSetColor1.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlLEDControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sldrIsetLed3)).BeginInit();
            this.pnlLedLabel3.SuspendLayout();
            this.pnlLedLabel2.SuspendLayout();
            this.pnlLEDControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sldrIsetLed1)).BeginInit();
            this.pnlLEDControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sldrIsetLed2)).BeginInit();
            this.pnlLedLabel1.SuspendLayout();
            this.pnlLicense.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblStatus
            // 
            this.lblStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(40, 330);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(79, 13);
            this.lblStatus.TabIndex = 5;
            this.lblStatus.Text = "Not Connected";
            // 
            // btnConnect
            // 
            this.btnConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConnect.Location = new System.Drawing.Point(630, 293);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(80, 23);
            this.btnConnect.TabIndex = 104;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage_Main);
            this.tabControl1.Location = new System.Drawing.Point(0, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.ShowToolTips = true;
            this.tabControl1.Size = new System.Drawing.Size(724, 287);
            this.tabControl1.TabIndex = 502;
            this.tabControl1.TabStop = false;
            // 
            // tabPage_Main
            // 
            this.tabPage_Main.AutoScroll = true;
            this.tabPage_Main.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage_Main.Controls.Add(this.pnlSetColor);
            this.tabPage_Main.Controls.Add(this.pictureBox1);
            this.tabPage_Main.Controls.Add(this.pnlSetColor1);
            this.tabPage_Main.Controls.Add(this.label24);
            this.tabPage_Main.Controls.Add(this.chbAutoColor);
            this.tabPage_Main.Controls.Add(this.panel9);
            this.tabPage_Main.Controls.Add(this.panel10);
            this.tabPage_Main.Controls.Add(this.panel2);
            this.tabPage_Main.Controls.Add(this.btnLEDSlewRate);
            this.tabPage_Main.Controls.Add(this.label14);
            this.tabPage_Main.Controls.Add(this.txtLEDSlewRate);
            this.tabPage_Main.Controls.Add(this.pnlLEDControl3);
            this.tabPage_Main.Controls.Add(this.pnlLedLabel3);
            this.tabPage_Main.Controls.Add(this.label20);
            this.tabPage_Main.Controls.Add(this.pnlLedLabel2);
            this.tabPage_Main.Controls.Add(this.label19);
            this.tabPage_Main.Controls.Add(this.pnlLEDControl1);
            this.tabPage_Main.Controls.Add(this.pnlLEDControl2);
            this.tabPage_Main.Controls.Add(this.pnlLedLabel1);
            this.tabPage_Main.Controls.Add(this.cmbMainUpdateRate);
            this.tabPage_Main.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Main.Name = "tabPage_Main";
            this.tabPage_Main.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Main.Size = new System.Drawing.Size(716, 261);
            this.tabPage_Main.TabIndex = 0;
            this.tabPage_Main.Text = "Main Panel";
            this.tabPage_Main.ToolTipText = "Change voltages and view the status of the target board.";
            // 
            // pnlSetColor
            // 
            this.pnlSetColor.BackColor = System.Drawing.Color.DimGray;
            this.pnlSetColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSetColor.Controls.Add(this.label12);
            this.pnlSetColor.Controls.Add(this.label18);
            this.pnlSetColor.Location = new System.Drawing.Point(6, 8);
            this.pnlSetColor.Name = "pnlSetColor";
            this.pnlSetColor.Size = new System.Drawing.Size(53, 47);
            this.pnlSetColor.TabIndex = 910;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label12.Location = new System.Drawing.Point(-1, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Color";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label18.Location = new System.Drawing.Point(-1, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 13);
            this.label18.TabIndex = 21;
            this.label18.Text = "Presets:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(552, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(118, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1034;
            this.pictureBox1.TabStop = false;
            // 
            // pnlSetColor1
            // 
            this.pnlSetColor1.BackColor = System.Drawing.Color.White;
            this.pnlSetColor1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSetColor1.Controls.Add(this.btnBlack1);
            this.pnlSetColor1.Controls.Add(this.btnWhite1);
            this.pnlSetColor1.Controls.Add(this.btnPurple1);
            this.pnlSetColor1.Controls.Add(this.btnBlue1);
            this.pnlSetColor1.Controls.Add(this.btnGreen1);
            this.pnlSetColor1.Controls.Add(this.btnYellow1);
            this.pnlSetColor1.Controls.Add(this.btnOrange1);
            this.pnlSetColor1.Controls.Add(this.btnRed1);
            this.pnlSetColor1.Location = new System.Drawing.Point(69, 7);
            this.pnlSetColor1.Name = "pnlSetColor1";
            this.pnlSetColor1.Size = new System.Drawing.Size(248, 48);
            this.pnlSetColor1.TabIndex = 901;
            // 
            // btnBlack1
            // 
            this.btnBlack1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBlack1.BackColor = System.Drawing.Color.Black;
            this.btnBlack1.ForeColor = System.Drawing.Color.Black;
            this.btnBlack1.Location = new System.Drawing.Point(213, 12);
            this.btnBlack1.Name = "btnBlack1";
            this.btnBlack1.Size = new System.Drawing.Size(23, 23);
            this.btnBlack1.TabIndex = 1036;
            this.btnBlack1.UseVisualStyleBackColor = false;
            this.btnBlack1.Click += new System.EventHandler(this.btnBlack1_Click);
            // 
            // btnWhite1
            // 
            this.btnWhite1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWhite1.BackColor = System.Drawing.Color.White;
            this.btnWhite1.ForeColor = System.Drawing.Color.White;
            this.btnWhite1.Location = new System.Drawing.Point(184, 12);
            this.btnWhite1.Name = "btnWhite1";
            this.btnWhite1.Size = new System.Drawing.Size(23, 23);
            this.btnWhite1.TabIndex = 1035;
            this.btnWhite1.UseVisualStyleBackColor = false;
            this.btnWhite1.Click += new System.EventHandler(this.btnWhite1_Click);
            // 
            // btnPurple1
            // 
            this.btnPurple1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPurple1.BackColor = System.Drawing.Color.Violet;
            this.btnPurple1.ForeColor = System.Drawing.Color.Violet;
            this.btnPurple1.Location = new System.Drawing.Point(155, 12);
            this.btnPurple1.Name = "btnPurple1";
            this.btnPurple1.Size = new System.Drawing.Size(23, 23);
            this.btnPurple1.TabIndex = 1033;
            this.btnPurple1.UseVisualStyleBackColor = false;
            this.btnPurple1.Click += new System.EventHandler(this.btnPurple1_Click);
            // 
            // btnBlue1
            // 
            this.btnBlue1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBlue1.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnBlue1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnBlue1.Location = new System.Drawing.Point(126, 12);
            this.btnBlue1.Name = "btnBlue1";
            this.btnBlue1.Size = new System.Drawing.Size(23, 23);
            this.btnBlue1.TabIndex = 1032;
            this.btnBlue1.UseVisualStyleBackColor = false;
            this.btnBlue1.Click += new System.EventHandler(this.btnBlue1_Click);
            // 
            // btnGreen1
            // 
            this.btnGreen1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGreen1.BackColor = System.Drawing.Color.LawnGreen;
            this.btnGreen1.ForeColor = System.Drawing.Color.LawnGreen;
            this.btnGreen1.Location = new System.Drawing.Point(97, 12);
            this.btnGreen1.Name = "btnGreen1";
            this.btnGreen1.Size = new System.Drawing.Size(23, 23);
            this.btnGreen1.TabIndex = 1031;
            this.btnGreen1.UseVisualStyleBackColor = false;
            this.btnGreen1.Click += new System.EventHandler(this.btnGreen1_Click);
            // 
            // btnYellow1
            // 
            this.btnYellow1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnYellow1.BackColor = System.Drawing.Color.Yellow;
            this.btnYellow1.ForeColor = System.Drawing.Color.Yellow;
            this.btnYellow1.Location = new System.Drawing.Point(68, 12);
            this.btnYellow1.Name = "btnYellow1";
            this.btnYellow1.Size = new System.Drawing.Size(23, 23);
            this.btnYellow1.TabIndex = 1030;
            this.btnYellow1.UseVisualStyleBackColor = false;
            this.btnYellow1.Click += new System.EventHandler(this.btnYellow1_Click);
            // 
            // btnOrange1
            // 
            this.btnOrange1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOrange1.BackColor = System.Drawing.Color.Orange;
            this.btnOrange1.ForeColor = System.Drawing.Color.Orange;
            this.btnOrange1.Location = new System.Drawing.Point(39, 12);
            this.btnOrange1.Name = "btnOrange1";
            this.btnOrange1.Size = new System.Drawing.Size(23, 23);
            this.btnOrange1.TabIndex = 1029;
            this.btnOrange1.UseVisualStyleBackColor = false;
            this.btnOrange1.Click += new System.EventHandler(this.btnOrange1_Click);
            // 
            // btnRed1
            // 
            this.btnRed1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRed1.BackColor = System.Drawing.Color.Red;
            this.btnRed1.ForeColor = System.Drawing.Color.Red;
            this.btnRed1.Location = new System.Drawing.Point(10, 12);
            this.btnRed1.Name = "btnRed1";
            this.btnRed1.Size = new System.Drawing.Size(23, 23);
            this.btnRed1.TabIndex = 1028;
            this.btnRed1.UseVisualStyleBackColor = false;
            this.btnRed1.Click += new System.EventHandler(this.btnRed1_Click);
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.DimGray;
            this.label24.Location = new System.Drawing.Point(371, 25);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(135, 13);
            this.label24.TabIndex = 1026;
            this.label24.Tag = "0";
            this.label24.Text = "Automatic LED Control";
            // 
            // chbAutoColor
            // 
            this.chbAutoColor.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chbAutoColor.AutoSize = true;
            this.chbAutoColor.Checked = global::GUI_Template.Properties.Settings.Default.AutoLEDs;
            this.chbAutoColor.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::GUI_Template.Properties.Settings.Default, "AutoLEDs", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.chbAutoColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbAutoColor.ForeColor = System.Drawing.Color.DimGray;
            this.chbAutoColor.Location = new System.Drawing.Point(348, 24);
            this.chbAutoColor.Name = "chbAutoColor";
            this.chbAutoColor.Size = new System.Drawing.Size(15, 14);
            this.chbAutoColor.TabIndex = 1025;
            this.chbAutoColor.UseVisualStyleBackColor = true;
            this.chbAutoColor.CheckedChanged += new System.EventHandler(this.chbAutoColor_CheckedChanged);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label5);
            this.panel9.Controls.Add(this.txtGetILed3);
            this.panel9.Controls.Add(this.label3);
            this.panel9.Location = new System.Drawing.Point(513, 167);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(197, 47);
            this.panel9.TabIndex = 804;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 722;
            this.label5.Tag = "2";
            this.label5.Text = "Red Current:";
            // 
            // txtGetILed3
            // 
            this.txtGetILed3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGetILed3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.txtGetILed3.Location = new System.Drawing.Point(93, 12);
            this.txtGetILed3.Name = "txtGetILed3";
            this.txtGetILed3.ReadOnly = true;
            this.txtGetILed3.Size = new System.Drawing.Size(64, 20);
            this.txtGetILed3.TabIndex = 38;
            this.txtGetILed3.TabStop = false;
            this.txtGetILed3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(162, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 813;
            this.label3.Text = "A";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.lblVGetCH2);
            this.panel10.Controls.Add(this.txtGetILed2);
            this.panel10.Controls.Add(this.label11);
            this.panel10.Location = new System.Drawing.Point(513, 114);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(197, 47);
            this.panel10.TabIndex = 804;
            // 
            // lblVGetCH2
            // 
            this.lblVGetCH2.AutoSize = true;
            this.lblVGetCH2.Location = new System.Drawing.Point(10, 16);
            this.lblVGetCH2.Name = "lblVGetCH2";
            this.lblVGetCH2.Size = new System.Drawing.Size(76, 13);
            this.lblVGetCH2.TabIndex = 721;
            this.lblVGetCH2.Tag = "2";
            this.lblVGetCH2.Text = "Green Current:";
            // 
            // txtGetILed2
            // 
            this.txtGetILed2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGetILed2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.txtGetILed2.Location = new System.Drawing.Point(92, 12);
            this.txtGetILed2.Name = "txtGetILed2";
            this.txtGetILed2.ReadOnly = true;
            this.txtGetILed2.Size = new System.Drawing.Size(64, 20);
            this.txtGetILed2.TabIndex = 37;
            this.txtGetILed2.TabStop = false;
            this.txtGetILed2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(162, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 13);
            this.label11.TabIndex = 812;
            this.label11.Text = "A";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblVGetCH1);
            this.panel2.Controls.Add(this.lblUnits1);
            this.panel2.Controls.Add(this.txtGetILed1);
            this.panel2.Location = new System.Drawing.Point(513, 61);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(197, 47);
            this.panel2.TabIndex = 803;
            // 
            // lblVGetCH1
            // 
            this.lblVGetCH1.AutoSize = true;
            this.lblVGetCH1.BackColor = System.Drawing.Color.White;
            this.lblVGetCH1.Location = new System.Drawing.Point(10, 16);
            this.lblVGetCH1.Name = "lblVGetCH1";
            this.lblVGetCH1.Size = new System.Drawing.Size(68, 13);
            this.lblVGetCH1.TabIndex = 720;
            this.lblVGetCH1.Tag = "1";
            this.lblVGetCH1.Text = "Blue Current:";
            // 
            // lblUnits1
            // 
            this.lblUnits1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblUnits1.AutoSize = true;
            this.lblUnits1.Location = new System.Drawing.Point(162, 16);
            this.lblUnits1.Name = "lblUnits1";
            this.lblUnits1.Size = new System.Drawing.Size(14, 13);
            this.lblUnits1.TabIndex = 811;
            this.lblUnits1.Text = "A";
            // 
            // txtGetILed1
            // 
            this.txtGetILed1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGetILed1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.txtGetILed1.Location = new System.Drawing.Point(94, 12);
            this.txtGetILed1.Name = "txtGetILed1";
            this.txtGetILed1.ReadOnly = true;
            this.txtGetILed1.Size = new System.Drawing.Size(64, 20);
            this.txtGetILed1.TabIndex = 32;
            this.txtGetILed1.TabStop = false;
            this.txtGetILed1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnLEDSlewRate
            // 
            this.btnLEDSlewRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLEDSlewRate.Location = new System.Drawing.Point(176, 226);
            this.btnLEDSlewRate.Name = "btnLEDSlewRate";
            this.btnLEDSlewRate.Size = new System.Drawing.Size(44, 23);
            this.btnLEDSlewRate.TabIndex = 14;
            this.btnLEDSlewRate.Text = "Set";
            this.btnLEDSlewRate.UseVisualStyleBackColor = true;
            this.btnLEDSlewRate.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.DimGray;
            this.label14.Location = new System.Drawing.Point(20, 231);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 13);
            this.label14.TabIndex = 120;
            this.label14.Tag = "0";
            this.label14.Text = "LED Slew Rate:";
            // 
            // txtLEDSlewRate
            // 
            this.txtLEDSlewRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtLEDSlewRate.Location = new System.Drawing.Point(122, 227);
            this.txtLEDSlewRate.Name = "txtLEDSlewRate";
            this.txtLEDSlewRate.Size = new System.Drawing.Size(41, 20);
            this.txtLEDSlewRate.TabIndex = 13;
            this.txtLEDSlewRate.Text = "400";
            this.txtLEDSlewRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLEDSlewRate.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtLEDSlewRate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // pnlLEDControl3
            // 
            this.pnlLEDControl3.BackColor = System.Drawing.Color.White;
            this.pnlLEDControl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLEDControl3.Controls.Add(this.lblMinIsetLED3);
            this.pnlLEDControl3.Controls.Add(this.txtIsetLED3);
            this.pnlLEDControl3.Controls.Add(this.lblMaxIsetLED3);
            this.pnlLEDControl3.Controls.Add(this.sldrIsetLed3);
            this.pnlLEDControl3.Controls.Add(this.label10);
            this.pnlLEDControl3.Controls.Add(this.label9);
            this.pnlLEDControl3.Location = new System.Drawing.Point(69, 167);
            this.pnlLEDControl3.Name = "pnlLEDControl3";
            this.pnlLEDControl3.Size = new System.Drawing.Size(437, 47);
            this.pnlLEDControl3.TabIndex = 903;
            // 
            // lblMinIsetLED3
            // 
            this.lblMinIsetLED3.AutoSize = true;
            this.lblMinIsetLED3.Location = new System.Drawing.Point(108, 16);
            this.lblMinIsetLED3.Name = "lblMinIsetLED3";
            this.lblMinIsetLED3.Size = new System.Drawing.Size(13, 13);
            this.lblMinIsetLED3.TabIndex = 55;
            this.lblMinIsetLED3.Text = "0";
            // 
            // txtIsetLED3
            // 
            this.txtIsetLED3.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "LED3TargetCurrentInit", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtIsetLED3.Location = new System.Drawing.Point(360, 12);
            this.txtIsetLED3.Name = "txtIsetLED3";
            this.txtIsetLED3.Size = new System.Drawing.Size(46, 20);
            this.txtIsetLED3.TabIndex = 6;
            this.txtIsetLED3.Text = global::GUI_Template.Properties.Settings.Default.LED3TargetCurrentInit;
            this.txtIsetLED3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIsetLED3.TextChanged += new System.EventHandler(this.GenericEventHandler_SetSldr_TxtChanged);
            this.txtIsetLED3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetSldr_TxtKeyDown);
            // 
            // lblMaxIsetLED3
            // 
            this.lblMaxIsetLED3.AutoSize = true;
            this.lblMaxIsetLED3.Location = new System.Drawing.Point(327, 16);
            this.lblMaxIsetLED3.Name = "lblMaxIsetLED3";
            this.lblMaxIsetLED3.Size = new System.Drawing.Size(28, 13);
            this.lblMaxIsetLED3.TabIndex = 54;
            this.lblMaxIsetLED3.Text = "0.05";
            // 
            // sldrIsetLed3
            // 
            this.sldrIsetLed3.LargeChange = 15;
            this.sldrIsetLed3.Location = new System.Drawing.Point(126, 0);
            this.sldrIsetLed3.Margin = new System.Windows.Forms.Padding(2);
            this.sldrIsetLed3.Maximum = 32768;
            this.sldrIsetLed3.Name = "sldrIsetLed3";
            this.sldrIsetLed3.Size = new System.Drawing.Size(202, 45);
            this.sldrIsetLed3.SmallChange = 2;
            this.sldrIsetLed3.TabIndex = 5;
            this.sldrIsetLed3.TabStop = false;
            this.sldrIsetLed3.TickFrequency = 4096;
            this.sldrIsetLed3.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.sldrIsetLed3.Scroll += new System.EventHandler(this.GenericEventHandler_SetSldr_SldrScroll);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(410, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 13);
            this.label10.TabIndex = 805;
            this.label10.Text = "A";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 705;
            this.label9.Text = "Target Current:";
            // 
            // pnlLedLabel3
            // 
            this.pnlLedLabel3.BackColor = System.Drawing.Color.DimGray;
            this.pnlLedLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLedLabel3.Controls.Add(this.label1);
            this.pnlLedLabel3.Controls.Add(this.lblString3LblforPanel);
            this.pnlLedLabel3.Location = new System.Drawing.Point(6, 167);
            this.pnlLedLabel3.Name = "pnlLedLabel3";
            this.pnlLedLabel3.Size = new System.Drawing.Size(53, 47);
            this.pnlLedLabel3.TabIndex = 911;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(-1, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 24;
            this.label1.Text = "Red";
            // 
            // lblString3LblforPanel
            // 
            this.lblString3LblforPanel.AutoSize = true;
            this.lblString3LblforPanel.BackColor = System.Drawing.Color.Transparent;
            this.lblString3LblforPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblString3LblforPanel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblString3LblforPanel.Location = new System.Drawing.Point(-1, 22);
            this.lblString3LblforPanel.Name = "lblString3LblforPanel";
            this.lblString3LblforPanel.Size = new System.Drawing.Size(44, 13);
            this.lblString3LblforPanel.TabIndex = 23;
            this.lblString3LblforPanel.Text = "String:";
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(696, 231);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(12, 13);
            this.label20.TabIndex = 820;
            this.label20.Text = "s";
            // 
            // pnlLedLabel2
            // 
            this.pnlLedLabel2.BackColor = System.Drawing.Color.DimGray;
            this.pnlLedLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLedLabel2.Controls.Add(this.label28);
            this.pnlLedLabel2.Controls.Add(this.lblString2LblforPanel);
            this.pnlLedLabel2.Location = new System.Drawing.Point(6, 114);
            this.pnlLedLabel2.Name = "pnlLedLabel2";
            this.pnlLedLabel2.Size = new System.Drawing.Size(53, 47);
            this.pnlLedLabel2.TabIndex = 910;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label28.Location = new System.Drawing.Point(-1, 9);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(41, 13);
            this.label28.TabIndex = 24;
            this.label28.Text = "Green";
            // 
            // lblString2LblforPanel
            // 
            this.lblString2LblforPanel.AutoSize = true;
            this.lblString2LblforPanel.BackColor = System.Drawing.Color.Transparent;
            this.lblString2LblforPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblString2LblforPanel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblString2LblforPanel.Location = new System.Drawing.Point(-1, 22);
            this.lblString2LblforPanel.Name = "lblString2LblforPanel";
            this.lblString2LblforPanel.Size = new System.Drawing.Size(44, 13);
            this.lblString2LblforPanel.TabIndex = 23;
            this.lblString2LblforPanel.Text = "String:";
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.Location = new System.Drawing.Point(569, 231);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 13);
            this.label19.TabIndex = 107;
            this.label19.Text = "Update Rate:";
            // 
            // pnlLEDControl1
            // 
            this.pnlLEDControl1.BackColor = System.Drawing.Color.White;
            this.pnlLEDControl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLEDControl1.Controls.Add(this.lblMinIsetLED1);
            this.pnlLEDControl1.Controls.Add(this.lblMaxIsetLED1);
            this.pnlLEDControl1.Controls.Add(this.label6);
            this.pnlLEDControl1.Controls.Add(this.txtIsetLED1);
            this.pnlLEDControl1.Controls.Add(this.lblVsetCH1);
            this.pnlLEDControl1.Controls.Add(this.sldrIsetLed1);
            this.pnlLEDControl1.Location = new System.Drawing.Point(69, 61);
            this.pnlLEDControl1.Name = "pnlLEDControl1";
            this.pnlLEDControl1.Size = new System.Drawing.Size(437, 47);
            this.pnlLEDControl1.TabIndex = 901;
            // 
            // lblMinIsetLED1
            // 
            this.lblMinIsetLED1.AutoSize = true;
            this.lblMinIsetLED1.Location = new System.Drawing.Point(108, 16);
            this.lblMinIsetLED1.Name = "lblMinIsetLED1";
            this.lblMinIsetLED1.Size = new System.Drawing.Size(13, 13);
            this.lblMinIsetLED1.TabIndex = 47;
            this.lblMinIsetLED1.Text = "0";
            // 
            // lblMaxIsetLED1
            // 
            this.lblMaxIsetLED1.AutoSize = true;
            this.lblMaxIsetLED1.Location = new System.Drawing.Point(326, 16);
            this.lblMaxIsetLED1.Name = "lblMaxIsetLED1";
            this.lblMaxIsetLED1.Size = new System.Drawing.Size(28, 13);
            this.lblMaxIsetLED1.TabIndex = 49;
            this.lblMaxIsetLED1.Text = "0.05";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(410, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 13);
            this.label6.TabIndex = 803;
            this.label6.Text = "A";
            // 
            // txtIsetLED1
            // 
            this.txtIsetLED1.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "LED1TargetCurrentInit", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtIsetLED1.Location = new System.Drawing.Point(360, 12);
            this.txtIsetLED1.Name = "txtIsetLED1";
            this.txtIsetLED1.Size = new System.Drawing.Size(46, 20);
            this.txtIsetLED1.TabIndex = 2;
            this.txtIsetLED1.Text = global::GUI_Template.Properties.Settings.Default.LED1TargetCurrentInit;
            this.txtIsetLED1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIsetLED1.TextChanged += new System.EventHandler(this.GenericEventHandler_SetSldr_TxtChanged);
            this.txtIsetLED1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetSldr_TxtKeyDown);
            // 
            // lblVsetCH1
            // 
            this.lblVsetCH1.AutoSize = true;
            this.lblVsetCH1.Location = new System.Drawing.Point(11, 16);
            this.lblVsetCH1.Name = "lblVsetCH1";
            this.lblVsetCH1.Size = new System.Drawing.Size(78, 13);
            this.lblVsetCH1.TabIndex = 703;
            this.lblVsetCH1.Text = "Target Current:";
            // 
            // sldrIsetLed1
            // 
            this.sldrIsetLed1.BackColor = System.Drawing.Color.White;
            this.sldrIsetLed1.LargeChange = 15;
            this.sldrIsetLed1.Location = new System.Drawing.Point(126, 0);
            this.sldrIsetLed1.Margin = new System.Windows.Forms.Padding(2);
            this.sldrIsetLed1.Maximum = 32768;
            this.sldrIsetLed1.Name = "sldrIsetLed1";
            this.sldrIsetLed1.Size = new System.Drawing.Size(202, 45);
            this.sldrIsetLed1.SmallChange = 2;
            this.sldrIsetLed1.TabIndex = 1;
            this.sldrIsetLed1.TabStop = false;
            this.sldrIsetLed1.TickFrequency = 4096;
            this.sldrIsetLed1.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.sldrIsetLed1.Scroll += new System.EventHandler(this.GenericEventHandler_SetSldr_SldrScroll);
            // 
            // pnlLEDControl2
            // 
            this.pnlLEDControl2.BackColor = System.Drawing.Color.White;
            this.pnlLEDControl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLEDControl2.Controls.Add(this.lblMinIsetLED2);
            this.pnlLEDControl2.Controls.Add(this.lblMaxIsetLED2);
            this.pnlLEDControl2.Controls.Add(this.label7);
            this.pnlLEDControl2.Controls.Add(this.txtIsetLED2);
            this.pnlLEDControl2.Controls.Add(this.sldrIsetLed2);
            this.pnlLEDControl2.Controls.Add(this.lblVsetCH2);
            this.pnlLEDControl2.Location = new System.Drawing.Point(69, 115);
            this.pnlLEDControl2.Name = "pnlLEDControl2";
            this.pnlLEDControl2.Size = new System.Drawing.Size(437, 45);
            this.pnlLEDControl2.TabIndex = 902;
            // 
            // lblMinIsetLED2
            // 
            this.lblMinIsetLED2.AutoSize = true;
            this.lblMinIsetLED2.Location = new System.Drawing.Point(108, 15);
            this.lblMinIsetLED2.Name = "lblMinIsetLED2";
            this.lblMinIsetLED2.Size = new System.Drawing.Size(13, 13);
            this.lblMinIsetLED2.TabIndex = 48;
            this.lblMinIsetLED2.Text = "0";
            // 
            // lblMaxIsetLED2
            // 
            this.lblMaxIsetLED2.AutoSize = true;
            this.lblMaxIsetLED2.Location = new System.Drawing.Point(327, 15);
            this.lblMaxIsetLED2.Name = "lblMaxIsetLED2";
            this.lblMaxIsetLED2.Size = new System.Drawing.Size(28, 13);
            this.lblMaxIsetLED2.TabIndex = 50;
            this.lblMaxIsetLED2.Text = "0.05";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(410, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 13);
            this.label7.TabIndex = 804;
            this.label7.Text = "A";
            // 
            // txtIsetLED2
            // 
            this.txtIsetLED2.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "LED2TargetCurrentInit", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtIsetLED2.Location = new System.Drawing.Point(360, 11);
            this.txtIsetLED2.Name = "txtIsetLED2";
            this.txtIsetLED2.Size = new System.Drawing.Size(46, 20);
            this.txtIsetLED2.TabIndex = 4;
            this.txtIsetLED2.Text = global::GUI_Template.Properties.Settings.Default.LED2TargetCurrentInit;
            this.txtIsetLED2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIsetLED2.TextChanged += new System.EventHandler(this.GenericEventHandler_SetSldr_TxtChanged);
            this.txtIsetLED2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetSldr_TxtKeyDown);
            // 
            // sldrIsetLed2
            // 
            this.sldrIsetLed2.LargeChange = 15;
            this.sldrIsetLed2.Location = new System.Drawing.Point(124, -1);
            this.sldrIsetLed2.Margin = new System.Windows.Forms.Padding(2);
            this.sldrIsetLed2.Maximum = 32767;
            this.sldrIsetLed2.Name = "sldrIsetLed2";
            this.sldrIsetLed2.Size = new System.Drawing.Size(204, 45);
            this.sldrIsetLed2.SmallChange = 2;
            this.sldrIsetLed2.TabIndex = 3;
            this.sldrIsetLed2.TabStop = false;
            this.sldrIsetLed2.TickFrequency = 4096;
            this.sldrIsetLed2.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.sldrIsetLed2.Scroll += new System.EventHandler(this.GenericEventHandler_SetSldr_SldrScroll);
            // 
            // lblVsetCH2
            // 
            this.lblVsetCH2.AutoSize = true;
            this.lblVsetCH2.Location = new System.Drawing.Point(10, 15);
            this.lblVsetCH2.Name = "lblVsetCH2";
            this.lblVsetCH2.Size = new System.Drawing.Size(78, 13);
            this.lblVsetCH2.TabIndex = 704;
            this.lblVsetCH2.Text = "Target Current:";
            // 
            // pnlLedLabel1
            // 
            this.pnlLedLabel1.BackColor = System.Drawing.Color.DimGray;
            this.pnlLedLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLedLabel1.Controls.Add(this.label27);
            this.pnlLedLabel1.Controls.Add(this.lblString1LblforPanel);
            this.pnlLedLabel1.Location = new System.Drawing.Point(6, 61);
            this.pnlLedLabel1.Name = "pnlLedLabel1";
            this.pnlLedLabel1.Size = new System.Drawing.Size(53, 47);
            this.pnlLedLabel1.TabIndex = 909;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label27.Location = new System.Drawing.Point(-1, 9);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(32, 13);
            this.label27.TabIndex = 22;
            this.label27.Text = "Blue";
            // 
            // lblString1LblforPanel
            // 
            this.lblString1LblforPanel.AutoSize = true;
            this.lblString1LblforPanel.BackColor = System.Drawing.Color.Transparent;
            this.lblString1LblforPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblString1LblforPanel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblString1LblforPanel.Location = new System.Drawing.Point(-1, 22);
            this.lblString1LblforPanel.Name = "lblString1LblforPanel";
            this.lblString1LblforPanel.Size = new System.Drawing.Size(44, 13);
            this.lblString1LblforPanel.TabIndex = 21;
            this.lblString1LblforPanel.Text = "String:";
            // 
            // cmbMainUpdateRate
            // 
            this.cmbMainUpdateRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbMainUpdateRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMainUpdateRate.Items.AddRange(new object[] {
            "---",
            "1.50",
            "2.00",
            "2.50",
            "3.00"});
            this.cmbMainUpdateRate.Location = new System.Drawing.Point(646, 227);
            this.cmbMainUpdateRate.Name = "cmbMainUpdateRate";
            this.cmbMainUpdateRate.Size = new System.Drawing.Size(49, 21);
            this.cmbMainUpdateRate.TabIndex = 16;
            this.cmbMainUpdateRate.SelectedIndexChanged += new System.EventHandler(this.cmbMainUpdateRate_SelectedIndexChanged);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.statusStrip1.AutoSize = false;
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.statusStrip1.Location = new System.Drawing.Point(0, 325);
            this.statusStrip1.Margin = new System.Windows.Forms.Padding(2);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(724, 22);
            this.statusStrip1.TabIndex = 13;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // pnlConnect
            // 
            this.pnlConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlConnect.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlConnect.Location = new System.Drawing.Point(16, 330);
            this.pnlConnect.Name = "pnlConnect";
            this.pnlConnect.Size = new System.Drawing.Size(14, 13);
            this.pnlConnect.TabIndex = 15;
            // 
            // btnSetupConnection
            // 
            this.btnSetupConnection.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetupConnection.Location = new System.Drawing.Point(517, 293);
            this.btnSetupConnection.Name = "btnSetupConnection";
            this.btnSetupConnection.Size = new System.Drawing.Size(107, 23);
            this.btnSetupConnection.TabIndex = 103;
            this.btnSetupConnection.Text = "Setup Connection";
            this.btnSetupConnection.UseVisualStyleBackColor = true;
            this.btnSetupConnection.Click += new System.EventHandler(this.btnSetupConnection_Click);
            // 
            // MainTimer
            // 
            this.MainTimer.Interval = 1000;
            this.MainTimer.Tick += new System.EventHandler(this.MainTimer_Tick);
            // 
            // GraphTimer
            // 
            this.GraphTimer.Interval = 3000;
            // 
            // btnSaveDefaults
            // 
            this.btnSaveDefaults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSaveDefaults.Location = new System.Drawing.Point(4, 293);
            this.btnSaveDefaults.Name = "btnSaveDefaults";
            this.btnSaveDefaults.Size = new System.Drawing.Size(115, 23);
            this.btnSaveDefaults.TabIndex = 101;
            this.btnSaveDefaults.Text = "Save Configuration";
            this.btnSaveDefaults.UseVisualStyleBackColor = true;
            this.btnSaveDefaults.Click += new System.EventHandler(this.btnSaveDefaults_Click);
            // 
            // btnResetDefaults
            // 
            this.btnResetDefaults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnResetDefaults.Location = new System.Drawing.Point(124, 293);
            this.btnResetDefaults.Name = "btnResetDefaults";
            this.btnResetDefaults.Size = new System.Drawing.Size(65, 23);
            this.btnResetDefaults.TabIndex = 102;
            this.btnResetDefaults.Text = "Reset";
            this.btnResetDefaults.UseVisualStyleBackColor = true;
            this.btnResetDefaults.Click += new System.EventHandler(this.btnResetDefaults_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 10000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.ReshowDelay = 100;
            // 
            // prbConnectStatus
            // 
            this.prbConnectStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.prbConnectStatus.Location = new System.Drawing.Point(630, 329);
            this.prbConnectStatus.Name = "prbConnectStatus";
            this.prbConnectStatus.Size = new System.Drawing.Size(66, 16);
            this.prbConnectStatus.TabIndex = 16;
            // 
            // pnlLicense
            // 
            this.pnlLicense.BackColor = System.Drawing.SystemColors.Control;
            this.pnlLicense.Controls.Add(this.rtxtLicense);
            this.pnlLicense.Controls.Add(this.label53);
            this.pnlLicense.Controls.Add(this.label52);
            this.pnlLicense.Controls.Add(this.label47);
            this.pnlLicense.Controls.Add(this.btnLicenseDisagree);
            this.pnlLicense.Controls.Add(this.btnLicenseAgree);
            this.pnlLicense.Controls.Add(this.statusStrip1);
            this.pnlLicense.Location = new System.Drawing.Point(0, 1);
            this.pnlLicense.Name = "pnlLicense";
            this.pnlLicense.Size = new System.Drawing.Size(724, 347);
            this.pnlLicense.TabIndex = 503;
            // 
            // rtxtLicense
            // 
            this.rtxtLicense.Location = new System.Drawing.Point(7, 110);
            this.rtxtLicense.Name = "rtxtLicense";
            this.rtxtLicense.Size = new System.Drawing.Size(703, 146);
            this.rtxtLicense.TabIndex = 1;
            this.rtxtLicense.Text = global::GUI_Template.Properties.Resources.String1;
            // 
            // label53
            // 
            this.label53.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(18, 259);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(236, 13);
            this.label53.TabIndex = 5;
            this.label53.Text = "I have read the above terms and conditions and:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(18, 83);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(487, 13);
            this.label52.TabIndex = 4;
            this.label52.Text = "Please read the license agreement below and click \"I Agree\" if you agree with its" +
                " terms and conditions";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(14, 21);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(304, 36);
            this.label47.TabIndex = 3;
            this.label47.Text = "TI License Agreement";
            // 
            // btnLicenseDisagree
            // 
            this.btnLicenseDisagree.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnLicenseDisagree.Location = new System.Drawing.Point(232, 278);
            this.btnLicenseDisagree.Name = "btnLicenseDisagree";
            this.btnLicenseDisagree.Size = new System.Drawing.Size(130, 23);
            this.btnLicenseDisagree.TabIndex = 2;
            this.btnLicenseDisagree.Text = "I Disagree";
            this.btnLicenseDisagree.UseVisualStyleBackColor = true;
            this.btnLicenseDisagree.Click += new System.EventHandler(this.btnLicenseDisagree_Click);
            // 
            // btnLicenseAgree
            // 
            this.btnLicenseAgree.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnLicenseAgree.Location = new System.Drawing.Point(373, 278);
            this.btnLicenseAgree.Name = "btnLicenseAgree";
            this.btnLicenseAgree.Size = new System.Drawing.Size(130, 23);
            this.btnLicenseAgree.TabIndex = 0;
            this.btnLicenseAgree.Text = "I Agree";
            this.btnLicenseAgree.UseVisualStyleBackColor = true;
            this.btnLicenseAgree.Click += new System.EventHandler(this.btnLicenseAgree_Click);
            // 
            // MainPanel
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(723, 348);
            this.Controls.Add(this.pnlLicense);
            this.Controls.Add(this.prbConnectStatus);
            this.Controls.Add(this.btnSaveDefaults);
            this.Controls.Add(this.btnSetupConnection);
            this.Controls.Add(this.btnResetDefaults);
            this.Controls.Add(this.pnlConnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainPanel";
            this.Text = "Texas Instruments - C2000 LED Booster Pack";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TwoChannelBuck_FormClosing);
            this.tabControl1.ResumeLayout(false);
            this.tabPage_Main.ResumeLayout(false);
            this.tabPage_Main.PerformLayout();
            this.pnlSetColor.ResumeLayout(false);
            this.pnlSetColor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlSetColor1.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlLEDControl3.ResumeLayout(false);
            this.pnlLEDControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sldrIsetLed3)).EndInit();
            this.pnlLedLabel3.ResumeLayout(false);
            this.pnlLedLabel3.PerformLayout();
            this.pnlLedLabel2.ResumeLayout(false);
            this.pnlLedLabel2.PerformLayout();
            this.pnlLEDControl1.ResumeLayout(false);
            this.pnlLEDControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sldrIsetLed1)).EndInit();
            this.pnlLEDControl2.ResumeLayout(false);
            this.pnlLEDControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sldrIsetLed2)).EndInit();
            this.pnlLedLabel1.ResumeLayout(false);
            this.pnlLedLabel1.PerformLayout();
            this.pnlLicense.ResumeLayout(false);
            this.pnlLicense.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage_Main;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel pnlConnect;
        private System.Windows.Forms.Button btnSetupConnection;
        private System.Windows.Forms.Label lblVGetCH2;
        private System.Windows.Forms.Label lblVGetCH1;
        private System.Windows.Forms.Label lblVsetCH2;
        private System.Windows.Forms.Label lblVsetCH1;
        private System.Windows.Forms.TrackBar sldrIsetLed1;
        private System.Windows.Forms.TrackBar sldrIsetLed2;
        private System.Windows.Forms.TextBox txtIsetLED2;
        private System.Windows.Forms.TextBox txtIsetLED1;
        private System.Windows.Forms.Label lblMaxIsetLED2;
        private System.Windows.Forms.Label lblMaxIsetLED1;
        private System.Windows.Forms.Label lblMinIsetLED2;
        private System.Windows.Forms.Label lblMinIsetLED1;
        private System.Windows.Forms.Timer GraphTimer;
        private System.Windows.Forms.TextBox txtGetILed1;
        private System.Windows.Forms.TextBox txtGetILed3;
        private System.Windows.Forms.TextBox txtGetILed2;
        public System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Timer MainTimer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblUnits1;
        private System.Windows.Forms.Panel pnlLedLabel2;
        private System.Windows.Forms.Panel pnlLedLabel1;
        private System.Windows.Forms.Label lblString1LblforPanel;
        private System.Windows.Forms.Panel pnlLEDControl2;
        private System.Windows.Forms.Panel pnlLEDControl1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSaveDefaults;
        private System.Windows.Forms.Button btnResetDefaults;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ProgressBar prbConnectStatus;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cmbMainUpdateRate;
        private System.Windows.Forms.Panel pnlLedLabel3;
        private System.Windows.Forms.Panel pnlLEDControl3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblMinIsetLED3;
        private System.Windows.Forms.Label lblMaxIsetLED3;
        private System.Windows.Forms.TrackBar sldrIsetLed3;
        private System.Windows.Forms.TextBox txtIsetLED3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblString3LblforPanel;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblString2LblforPanel;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtLEDSlewRate;
        private System.Windows.Forms.Button btnLEDSlewRate;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel pnlLicense;
        private System.Windows.Forms.Button btnLicenseAgree;
        private System.Windows.Forms.RichTextBox rtxtLicense;
        private System.Windows.Forms.Button btnLicenseDisagree;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox chbAutoColor;
        private System.Windows.Forms.Panel pnlSetColor1;
        private System.Windows.Forms.Button btnPurple1;
        private System.Windows.Forms.Button btnBlue1;
        private System.Windows.Forms.Button btnGreen1;
        private System.Windows.Forms.Button btnYellow1;
        private System.Windows.Forms.Button btnOrange1;
        private System.Windows.Forms.Button btnRed1;
        private System.Windows.Forms.Button btnWhite1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlSetColor;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnBlack1;
    }
}

