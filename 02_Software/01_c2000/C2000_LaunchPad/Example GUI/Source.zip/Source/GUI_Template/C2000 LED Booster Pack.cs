using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GUI_Template
{
    public partial class MainPanel : Form
    {
        //---global variables---
        GuiSetBtn[] btnGroup;
        GuiSetTxt[] txtGroup;
        GuiSetSldr[] sldrGroup;

        GuiGetVar[] varGroup;
        GuiGetArray[] arrayGroup;
        //public GuiGraphTSArray[] TSGraphGroup;
        GuiGetMemory[] memoryGroup;

        bool autoUpdateOn = false;
        bool graphOn = false;
        bool powerCycled = false;

        //GraphForm grphForm;
        ProjectProperties propsForm;

        public CommsManager commsMngr;

        int guiSetBtnSize = 0;
        int guiSetTxtSize = 7;
        int guiSetSldrSize = 3;

        int guiGetVarSize = 5;
        int guiGetArraySize = 0;
        int guiGetTSGraphSize = 0;
        int guiGetMemorySize = 0;

        //---initialization---
        public MainPanel()
        {      
            InitializeComponent();
            EnableCtrls(false);

            if (Properties.Settings.Default.LicenseAccept == true)
            {
                btnLicenseAgree_Click(null, null);
            }

            #region Show License
            rtxtLicense.Text = @"C2000 License Agreement 
(Version 1 as of July 12, 2004) 

Important - Please read the following license agreement carefully.  This is a legally binding agreement.  After you read this license agreement, you will be asked whether you accept and agree to the terms of this license agreement.  Do not click  �I have read and agree� unless: (1) you are authorized to accept and agree to the terms of this license agreement on behalf of yourself and your company; and (2) you intend to enter into and to be bound by the terms of this legally binding agreement on behalf of yourself and your company 

Important - Read carefully: This software license agreement (�Agreement�) is a legal agreement between you (either an individual or entity) and Texas Instruments Incorporated (�TI�).  The �Licensed Materials� subject to this Agreement include the software programs TI has granted you access to download and any �on-line� or electronic documentation associated with these programs, or any portion thereof, as well as any updates or upgrades to such software programs and documentation, if any, or any portion thereof, provided to you at TI's sole discretion.  The Licensed Materials are specifically designed and licensed for use solely and exclusively with the C2000 family of processing devices manufactured by or for TI (�TI Devices�).  By installing, copying or otherwise using the Licensed Materials you agree to abide by the following provisions.  This Agreement is displayed for you to read prior to using the Licensed Materials.  If you choose not to accept or agree with these provisions, do not download or install the Licensed Materials, but instead delete them and, if applicable, send your request for a full refund to: Texas Instruments Incorporated, 12203 Southwest Freeway, Mail Station 728, Stafford, Texas 77477, Attention: Manager, C2000 Digital Signal Controllers. 

1) License Grant and Use Restrictions.   

a.  Limited Source Code License.  Subject to the terms of this Agreement, TI hereby grants to you a non-transferable, non-exclusive, non-assignable, non-sublicensable license to make copies, prepare derivative works, display internally and use internally the Licensed Materials provided to you in source code for the sole purpose of developing object and executable versions of such Licensed Materials or any derivative thereof, that execute solely and exclusively on TI Devices, for use in OEM Products, and maintaining and supporting such Licensed Materials, or any derivative thereof, and such OEM Products.  For purposes of this Agreement, �OEM Product� means a product that (i) consists of both hardware and software components, including executable only versions of the Licensed Materials, or any derivative thereof, that execute solely and exclusively on TI Devices and not on devices manufactured by or for an entity other than TI, and (ii) is sold by or for an original equipment manufacturer (�OEM�) bearing such OEM brand name and part number.  

b.  Demonstration License.  Subject to the terms of this Agreement, TI grants to you a non-transferable, non-exclusive, non-assignable, non-sublicensable worldwide license to demonstrate to third parties the Licensed Materials, or any derivative thereof, as they are used in OEM Products executing solely and exclusively on TI Devices, provided that such Licensed Materials, or any derivative thereof, are demonstrated in object or executable versions only and are not left with or retained by such third parties.

c.  Distribution License and Limited Sublicense Rights.  Subject to the terms of this Agreement, TI hereby grants to you a non-exclusive, non-transferable, non-assignable, worldwide license to:

    (i)  Use object code versions of the Licensed Materials, or any derivative thereof, to make, use, sell, offer to sell, import, export and otherwise distribute OEM Products, provided that such OEM Products include only embedded executable copies of such Licensed Materials, or derivatives thereof, that execute solely and exclusively on TI Devices.
    (ii) Make, use, sell, offer to sell, and otherwise distribute object code only versions of the Licensed Materials, or any derivative thereof, to ODMs or OEMs for use in OEM Products, provided that such OEM Products include only embedded executable copies of such Licensed Materials, or derivatives thereof, that execute solely and exclusively on TI Devices.  For purposes of this Agreement, �ODM� means an original design manufacturer that designs, manufactures, and/or distributes OEM Products or OEM Product designs for or to OEMs. 
    (iii)Sublicense such ODMs or OEMs to make copies, display, distribute internally and use internally object code versions of the Licensed Materials, or any derivative thereof, for the sole purpose of such ODMs or OEMs designing, developing, manufacturing, using, selling, offering to sell and otherwise distributing OEM Products, provided that (A) such OEM Products include only embedded executable copies of such Licensed Materials, or derivatives thereof, that execute solely and exclusively on TI Devices, and (B) you sublicense such software programs pursuant to an enforceable written license agreement that includes a provision whereby the ODM and OEM agree that neither TI nor its licensors shall be liable for any damages (whether direct, indirect, incidental, punitive or consequential) in connection with the use of the Licensed Materials, or any derivative thereof, regardless of how arising, and regardless of whether advised beforehand of the possibility of such damages.

d.  Limited License to TI and Covenant not to Sue.  Continuing for the term of this Agreement, you hereby grant to TI under any of your patents embodied in the Licensed Materials a non-transferable, non-exclusive, non-assignable, worldwide, fully paid-up, royalty-free license to make, use, sell, offer to sell, import, export and otherwise distribute such Licensed Materials.  You covenant not to sue or otherwise assert Derived Patents against TI and TI's affiliates and their licensees of the Licensed Materials.  In the event you assign a Derived Patent, you shall require as a condition of any such assignment that the assignee agree to be bound by the provisions in this Section 1(d) with respect to such Derived Patent.  Any attempted assignment or transfer in violation of this Section 1(d) shall be null and void.  For purposes of this Agreement, �Derived Patents� means any of your patents issuing from a patent application that discloses and claims an invention conceived of by you after delivery of the Licensed Materials, and derived by you from your access to the Licensed Materials.

e.	No Other License.  Notwithstanding anything to the contrary, nothing in this Agreement shall be construed as a license to any intellectual property rights of TI other than those rights embodied in the Licensed Materials provided to you by TI.  EXCEPT AS PROVIDED HEREIN, NO OTHER LICENSE, EXPRESS OR IMPLIED, BY ESTOPPEL OR OTHERWISE, TO ANY OTHER TI INTELLECTUAL PROPERTY RIGHTS IS GRANTED HEREIN.

f.	Restrictions.  You shall maintain the source code versions of the Licensed Materials under password control protection and shall not disclose such source code versions of the Licensed Materials, or any derivative thereof, to any person other than your employees whose job performance requires access.  You shall not use the Licensed Materials, or any modification or derivative thereof, with a processing device manufactured by or for an entity other than TI, and you agree that any such unauthorized use of the Licensed Materials is a material breach of this Agreement.  Except as otherwise provided in this Agreement, you will not sublicense, transfer, or assign the Licensed Materials or your rights under this Agreement to any third party.  You shall not (i) incorporate, combine, or distribute the Licensed Materials, or any derivative thereof, with any Public Software, or (ii) use Public Software in the development of any derivatives of the Licensed Materials, each in such a way that would cause the Licensed Materials, or any derivative thereof, to be subject to all or part of the license obligations or other intellectual property related terms with respect to such Public Software, including but not limited to, the obligations that the Licensed Materials, or any derivative thereof, incorporated into, combined, or distributed with such Public Software (x) be disclosed or distributed in source code form, be licensed for the purpose of making derivatives of such software, or be redistributed free of charge, contrary to the terms and conditions of this Agreement, (y) be used with devices other than TI Devices, or (z) be otherwise used or distributed in a manner contrary to the terms and conditions of this Agreement.  As used in this Section 1(f), �Public Software� means any software that contains, or is derived in whole or in part from, any software distributed as open source software, including but not limited to software licensed under the following or similar models:  (A) GNU's General Public License (GPL) or Lesser/Library GPL (LGPL), (B) the Artistic License (e.g., PERL), (C) the Mozilla Public License, (D) the Netscape Public License, (E) the Sun Community Source License (SCSL), (F) the Sun Industry Standards Source License (SISL), (G) the Apache Server license, (H) QT Free Edition License, (I) IBM Public License, and (J) BitKeeper.

g.	Termination.  This Agreement is effective until terminated.  You may terminate this Agreement at any time by written notice to TI.  Without prejudice to any other rights, if you fail to comply with the terms of this Agreement, TI may terminate your right to use the Licensed Materials, or any derivative thereof, and any applications generated using the Licensed Materials, or any derivative thereof.  Upon termination of this Agreement, you will destroy any and all copies of the Licensed Materials, including any derivatives thereof, in your possession, custody or control and provide to TI a written statement signed by your authorized representative certifying such destruction.

2.	Licensed Materials Ownership.  

The Licensed Materials are licensed, not sold to you, and can only be used in accordance with the terms of this Agreement.  Subject to the licenses granted to you pursuant to this Agreement, TI and its licensors own and shall continue to own all right, title, and interest in and to the Licensed Materials, including all copies thereof.  The parties agree that all fixes, modifications and improvements to the Licensed Materials conceived of or made by TI that are based, either in whole or in part, on your feedback, suggestions or recommendations are the exclusive property of TI and all right, title and interest in and to such fixes, modifications or improvements to the Licensed Materials will vest solely in TI.  You acknowledge and agree that regardless of the changes made to the Licensed Materials, your right to use any and all derivatives of the Licensed Materials shall remain subject to the terms and conditions of this Agreement.  Moreover, you acknowledge and agree that when your independently developed software or hardware components are combined, in whole or in part, with the Licensed Materials, or any derivative thereof, your right to use the Licensed Materials, or any derivative thereof, embodied in such resulting combined work shall remain subject to the terms and conditions of this Agreement.

3.	Intellectual Property Rights.  

The Licensed Materials contain copyrighted material, trade secrets and other proprietary information of TI and its licensors and are protected by copyright laws, international copyright treaties, and trade secret laws, as well as other intellectual property laws.  To protect TI's and its licensors' rights in the Licensed Materials provided in an object code only format, you agree not to �unlock�, decompile, reverse engineer, disassemble or otherwise translate any such object code portions of the Licensed Materials to a human-perceivable form nor to permit any person or entity, including but not limited to your sublicensees, to do so.  You and your sublicensees shall not remove, alter, cover, or obscure any confidentiality, trade secret, proprietary, or copyright notices, trade-marks, proprietary, patent, or other identifying marks or designs from any component of the Licensed Materials and you shall reproduce and include in all copies of the Licensed Materials the copyright notice(s) and proprietary legend(s) of TI and its licensors as they appear in the Licensed Materials.  TI reserves all rights not specifically granted under this Agreement.

4.	Confidential Information.  

You acknowledge and agree that the Licensed Materials, and any derivative thereof, contain trade secrets and other confidential information of TI.  You agree to use the Licensed Materials, or any derivative thereof, solely within the scope of the licenses set forth herein, to employ reasonable security precautions to maintain such trade secrets and confidential information in strict confidence, and to prevent disclosure of the Licensed Materials, or any derivative thereof, to any third party, except as may be necessary and required in connection with your rights and obligations hereunder.  You agree to obtain executed confidentiality agreements with your employees having access to the Licensed Materials, or any derivative thereof, and to diligently take steps to enforce such agreements in this respect.  TI agrees that the employment agreements used in the normal course of your business shall satisfy the requirements of this section. TI may disclose your contact information to TI's applicable licensors.

5.	Warranties and Limitations.  

THE LICENSED MATERIALS ARE PROVIDED �AS IS�.  TI MAKES NO WARRANTY OR REPRESENTATION, EXPRESS, IMPLIED OR STATUTORY, REGARDING THE LICENSED MATERIALS, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT OF ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADE SECRETS OR OTHER INTELLECTUAL PROPERTY RIGHTS.  YOU AGREE TO USE YOUR INDEPENDENT JUDGMENT IN DEVELOPING YOUR PRODUCTS AND DERIVATIVES OF THE LICENSED MATERIALS.

IN NO EVENT SHALL TI, OR ANY APPLICABLE LICENSOR, BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL, PUNITIVE OR CONSEQUENTIAL DAMAGES, HOWEVER CAUSED, ON ANY THEORY OF LIABILITY, IN CONNECTION WITH OR ARISING OUT OF THIS AGREEMENT OR THE USE OF THE LICENSED MATERIALS, OR ANY DERIVATIVE THEREOF, REGARDLESS OF WHETHER TI HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.  EXCLUDED DAMAGES INCLUDE, BUT ARE NOT LIMITED TO, COST OF REMOVAL OR REINSTALLATION, OUTSIDE COMPUTER TIME, LABOR COSTS, LOSS OF DATA, LOSS OF GOODWILL, LOSS OF PROFITS, LOSS OF SAVINGS, OR LOSS OF USE OR INTERRUPTION OF BUSINESS. 

Because some jurisdictions do not allow the exclusion or limitation of incidental or consequential damages or limitation on how long an implied warranty lasts, the above limitations or exclusions may not apply to you.

6.	Indemnification Disclaimer.  

YOU ACKNOWLEDGE AND AGREE THAT TI SHALL NOT BE LIABLE FOR AND SHALL NOT DEFEND OR INDEMNIFY YOU AGAINST ANY THIRD PARTY INFRINGEMENT CLAIM THAT RELATES TO OR IS BASED ON YOUR MANUFACTURE, USE, OR DISTRIBUTION OF THE LICENSED MATERIALS, OR ANY DERIVATIVE THEREOF, OR YOUR MANUFACTURE, USE, OFFER FOR SALE, SALE, IMPORTATION OR DISTRIBUTION OF YOUR PRODUCTS THAT INCLUDE OR INCORPORATE THE LICENSED MATERIALS, OR ANY DERIVATIVE THEREOF.

7.	No Technical Support.  

TI is under no obligation to install, maintain or support the Licensed Materials.  

8.	Export Control.  

You hereby acknowledge that the Licensed Materials are subject to export control under the U.S. Commerce Department's Export Administration Regulations (�EAR�).  You further hereby acknowledge and agree that unless prior authorization is obtained from the U.S. Commerce Department, neither you nor your customers will export, re-export, or release, directly or indirectly, any technology, software, or software source code (as defined in Part 772 of the EAR), received from TI, or export, directly or indirectly, any direct product of such technology, software, or software source code (as defined in Part 734 of the EAR), to any destination or country to which the export, re-export, or release of the technology, software, or software source code, or direct product is prohibited by the EAR.  You agree that none of the Licensed Materials may be downloaded or otherwise exported or reexported (i) into (or to a national or resident of) Cuba, Iran, Iraq, Libya, North Korea, Sudan and Syria or any other country the U.S. has embargoed goods; or (ii) to anyone on the U.S. Treasury Department's List of Specially Designated Nationals or the U.S. Commerce Department's Denied Person List or Entity List.  You represent and warrant that you are not located in, under the control of, or a national or resident of any such country or on any such list and you will not use or transfer the Licensed Materials for use in any sensitive nuclear, chemical or biological weapons, or missile technology end-uses unless authorized by the U.S. Government by regulation or specific license.  

9.	Governing Law and Severability.  

This Agreement will be governed by and interpreted in accordance with the laws of the State of Texas, without reference to conflict of laws principles.  If for any reason a court of competent jurisdiction finds any provision of the Agreement to be unenforceable, that provision will be enforced to the maximum extent possible to effectuate the intent of the parties, and the remainder of the Agreement shall continue in full force and effect.  This Agreement shall not be governed by the United Nations Convention on Contracts for the International Sale of Goods, or by the Uniform Computer Information Transactions Act (UCITA).  The parties agree that non-exclusive jurisdiction for any dispute arising out of or relating to this Agreement lies within the courts located in the State of Texas.  Notwithstanding the foregoing, any judgment may be enforced in any United States or foreign court, and either party may seek injunctive relief in any United States or foreign court.

10.	Entire Agreement.  

This is the entire Agreement between you and TI and supersedes any prior agreement between the parties related to the subject matter of this Agreement.  Notwithstanding the foregoing, any signed and effective software license agreement relating to the subject matter hereof will supersede the terms of this Agreement.  No amendment or modification of this Agreement will be effective unless in writing and signed by a duly authorized representative of TI.  You hereby warrant and represent that you have obtained all authorizations and other applicable consents required empowering you to enter into this Agreement.
";
            #endregion

            commsMngr = new CommsManager(this);

            //grphForm = new GraphForm(this);
            propsForm = new ProjectProperties(this,commsMngr);

            commsMngr.Close();

            MainTimer.Enabled = true;
            MainTimer.Stop();
            GraphTimer.Enabled = true;
            GraphTimer.Stop();

            btnGroup = new GuiSetBtn[guiSetBtnSize];
            txtGroup = new GuiSetTxt[guiSetTxtSize];
            sldrGroup = new GuiSetSldr[guiSetSldrSize];

            varGroup = new GuiGetVar[guiGetVarSize];
            arrayGroup = new GuiGetArray[guiGetArraySize];
            //TSGraphGroup = new GuiGraphTSArray[guiGetTSGraphSize];
            memoryGroup = new GuiGetMemory[guiGetMemorySize];

            //---Set Controls---
            //btns
            //btnGroup[0] = new GuiSetBtn(btnEnableCH1, 0x00);
            //btnGroup[1] = new GuiSetBtn(btnEnableCH2, 0x01);
            //btnGroup[2] = new GuiSetBtn(btnStartUp, "Stop All", "Start All", 0x02);

            //txts
//            txtGroup[0] is MergeLEDs
            txtGroup[1] = new GuiSetTxt(txtLEDSlewRate, btnLEDSlewRate, 0, 1, 1000, 0x01);
//            txtGroup[2] is AutoColor
//            txtGroup[3] is SetColor1
//            txtGroup[4] is SetColor2
//            txtGroup[5] is StopAll
//            txtGroup[6] is EnableAll

            //sldrs
            sldrGroup[0] = new GuiSetSldr(sldrIsetLed1, txtIsetLED1, lblMinIsetLED1, lblMaxIsetLED1, 0x00, 15);
            sldrGroup[1] = new GuiSetSldr(sldrIsetLed2, txtIsetLED2, lblMinIsetLED2, lblMaxIsetLED2, 0x01, 15);
            sldrGroup[2] = new GuiSetSldr(sldrIsetLed3, txtIsetLED3, lblMinIsetLED3, lblMaxIsetLED3, 0x02, 15);

            //---Get Controls---
            //vars
            //varGroup[0] is the board's FlashID
//            varGroup[1] = new GuiGetVar(txtGetVin, 0x01, 9);
            varGroup[2] = new GuiGetVar(txtGetILed1, 0x02, 15);
            varGroup[3] = new GuiGetVar(txtGetILed2, 0x03, 15);
            varGroup[4] = new GuiGetVar(txtGetILed3, 0x04, 15);

            //arrays
//            arrayGroup[0] = new GuiGetArray(new TextBox[6] {txtGetILed1, txtGetILed2, txtGetILed3, txtGetILed4, txtGetILed5, txtGetILed6}, 0x00, 14);
            //arrayGroup[1] = new GuiGetArray(new TextBox[2] {txtGetVSepic, txtTGetCH2}, 0x01, 6);
            //arrayGroup[2] = new GuiGetArray(new TextBox[2] { txtGetILed2, txtGetILed3 }, 0x02, 9);

            //Time-sequenced graphs (block of data from target)
            //TSGraphGroup[0] = new GuiGraphTSArray(300, 0x05, grphForm.graphPane);

            //memory gets
            //memoryGroup[0] = new GuiGetMemory(textBox1, textBox2, 0x00);


            #region Initialize common components among the ctrl groups (ex. commsMngr reference)

            for (int i = 0; i < guiSetBtnSize; i++)
            {
                if (btnGroup[i] != null)
                {
                    btnGroup[i].commsMngr = commsMngr;
                }
            }

            for (int i = 0; i < guiSetTxtSize; i++)
            {
                if (txtGroup[i] != null)
                {
                    txtGroup[i].commsMngr = commsMngr;
                }
            }

            for (int i = 0; i < guiSetSldrSize; i++)
            {
                if (sldrGroup[i] != null)
                {
                    sldrGroup[i].commsMngr = commsMngr;
                }
            }

            for (int i = 0; i < guiGetVarSize; i++)
            {
                if (varGroup[i] != null)
                {
                    varGroup[i].commsMngr = commsMngr;
                }
            }
            for (int i = 0; i < guiGetArraySize; i++)
            {
                if (arrayGroup[i] != null)
                {
                    arrayGroup[i].commsMngr = commsMngr;
                }
            }
            /*for (int i = 0; i < guiGetTSGraphSize; i++)
            {
                if (TSGraphGroup[i] != null)
                {
                    TSGraphGroup[i].commsMngr = commsMngr;
                }
            }*/
            for (int i = 0; i < guiGetMemorySize; i++)
            {
                if (memoryGroup[i] != null)
                {
                    memoryGroup[i].commsMngr = commsMngr;
                }
            }

            #endregion
        }


        //----------------------------------------------------------
        #region Main Form Event Handlers and Timers
        //----------------------------------------------------------

        //---Connect to the target via SCI and change displays to show this---
        public void Connect()
        {
            if (commsMngr.SciConnect() == false)
            {
                pnlConnect.BackColor = System.Drawing.Color.Red;
                lblStatus.Text = "Could Not Connect:  Please Check Connections";
                btnConnect.Text = "Connect";
            }
            else
            {
                #region Connected Successfully
                commsMngr.ClearCommands();
                commsMngr.isReceiving = false;

                EnableCtrls(true);

                commsMngr.ptrWriteAt = 0;
                commsMngr.ptrWorkingAt = 0;

                //Set Gui Controls to default settings
                Properties.Settings.Default.Reload();
                SetDefault();

                MainTimer.Start();

                #region Check Flash ID
                Application.DoEvents();
                System.Threading.Thread.Sleep(50);

                commsMngr.NewGetTask(null, 0x04, 0x00, 0xFF, 1);

                while (commsMngr.dataRxedBufferFilled == false)
                {
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(20);
                }
                commsMngr.dataRxedBufferFilled = false;

                if (commsMngr.dataRxedBuffer[0] != 0x5055)
                {
                    Disconnect();
                    //pnlMotorCtrls.Enabled = false;
                    //pnlMotorType.Enabled = false;
                    lblStatus.Text = "Target code incompatible with the GUI";
                    autoUpdateOn = false;
                    pnlConnect.BackColor = System.Drawing.Color.Red;
                }
                #endregion

                lblStatus.Text = "Connected";
                pnlConnect.BackColor = System.Drawing.Color.Green;

                btnConnect.Text = "Disconnect";
                cmbMainUpdateRate_SelectedIndexChanged(this, new EventArgs());

                System.Threading.Thread.Sleep(200);
                commsMngr.NewSetTask(null, 0x01, 0x00, 0);
                // AutoLEDs to false
                chbAutoColor.Checked = false;
                commsMngr.NewSetTask(null, 0x01, 0x02, 0);
                // Send StopAll command
                commsMngr.NewSetTask(null, 0x01, 0x05, 1);
                // EnableAll to On
                commsMngr.NewSetTask(null, 0x01, 0x06, 1);
                #endregion
            }
        }


        //---Boot to the target and display status/errors---
        public void Boot()
        {
            string portName = propsForm.PortName;
            string hexPath = propsForm.HexPath;

            if (portName == null)
            {
                lblStatus.Text = "Error: COM Port is Invalid.";
                pnlConnect.BackColor = System.Drawing.Color.Red;
            }
            else if (hexPath.Length < 6)
            {
                lblStatus.Text = "Error: Please load a valid .a00 file";
                pnlConnect.BackColor = System.Drawing.Color.Red;
            }
            else if (hexPath.Substring(hexPath.Length - 4) != ".a00")
            {
                lblStatus.Text = "Error: Please load a valid .a00 file";
                pnlConnect.BackColor = System.Drawing.Color.Red;
            }
            else if (powerCycled == true)
            {
                lblStatus.Text = "Loading Program...";
                Application.DoEvents();
                lblStatus.Text = commsMngr.LoadProgramFromFile(portName, hexPath, prbConnectStatus);
                if (lblStatus.Text.StartsWith("Error")) pnlConnect.BackColor = System.Drawing.Color.Crimson;
                else pnlConnect.BackColor = System.Drawing.Color.SeaGreen;
                powerCycled = false;
            }
            else
            {
                lblStatus.Text = "Please Power Cycle Board then Push \"Connect\"";
                lblStatus.ForeColor = System.Drawing.Color.Black;
                Application.DoEvents();
                powerCycled = true;
            }
        }


        //---Disconnect from the target and change displays to show this---
        public void Disconnect()
        {

            // Send StopAll command
            commsMngr.NewSetTask(null, 0x01, 0x05, 1);

            if (commsMngr.comValid == true && commsMngr.IsOpen == true)
            {
                autoUpdateOn = false;       //stop automatically getting variables from target 
                MainTimer.Stop();
                //GraphTimer.Stop();

                //Allow SerialPort to finish backlogged commands
                for (int i = 0; commsMngr.ptrWorkingAt != commsMngr.ptrWriteAt; i++)
                {
                    Application.DoEvents();                 //allow main thread to update GUI items (textboxes, etc)
                    System.Threading.Thread.Sleep(20);      // 50 ms
                    if (i > 100)
                    {
                        commsMngr.isReceiving = false;
                        commsMngr.TryNewCommsTask();
                    }
                }
                Application.DoEvents();
            }

            
            commsMngr.Close();
            btnConnect.Text = "Connect";
            lblStatus.Text = "Disconnected";
            pnlConnect.BackColor = System.Drawing.Color.Red;
            EnableCtrls(false);
        }


        //---Lost Connection so Disconnect and warn user---
        public void connectionLost()
        {
            MainTimer.Stop();
            commsMngr.Close();
            commsMngr.ptrWorkingAt = commsMngr.ptrWriteAt;
            pnlConnect.BackColor = System.Drawing.Color.Yellow;
            System.Threading.Thread.Sleep(200);
            lblStatus.Text = "Connection Lost : Board May Not Be Properly Turned Off";
            btnConnect.Text = "Connect";
            EnableCtrls(false);
        }


        //---Choose whether to disconnect, boot or connect then do this---
        public void btnConnect_Click(object sender, EventArgs e)
        {
            pnlConnect.BackColor = System.Drawing.Color.Yellow;
            //comErrorFound = false;

            if (commsMngr.IsOpen == true)
            {
                Disconnect();
            }
            else
            {
                //Connect Sequence               
                bool bootOnConnect = Properties.Settings.Default.BootOnConnect;

                if (bootOnConnect == true)
                {
                    Boot();
                    Application.DoEvents();
                }

                if (bootOnConnect == false || (lblStatus.Text.StartsWith("Error") == false && lblStatus.Text.StartsWith("Please") == false))
                {
                    Connect();
                }
            }
        }


        //---Enables and Disables Controls on the TabPages
        private void EnableCtrls(bool status)
        {
            int showedTabpageIndex;
            foreach (Control ctrl in tabControl1.Controls)
            {
                ctrl.Enabled = status;
            }

            showedTabpageIndex = tabControl1.SelectedIndex;
            if (status == true)
            {
                foreach (TabPage tabpage in tabControl1.TabPages)
                {
                    tabpage.Show();
                }
                tabControl1.SelectedIndex = 0;
            }
        }


        //---Get variables/arrays/data from host---
        private void GetData()
        {
            // note: varGroup[0] is skipped because it is the flash ID
            for (int i = 2; i < varGroup.Length; i++)
            {
                varGroup[i].RequestBuffer();
            }
            for (int i = 0; i < arrayGroup.Length; i++)
            {
                arrayGroup[i].RequestBuffer();
            }
        }


        //---(After [interval] ms this event triggers)---
        //---Blink LED and update the Get Group if autoUpdateOn is enabled---
        private void MainTimer_Tick(object sender, EventArgs e)
        {
            //toggle an LED
            //NewSetTask(ctrl who sent cmd, cmd#, item#, data)
            commsMngr.NewSetTask(null, 0x00, 0x00, 2);

            if (autoUpdateOn == true && this.tabControl1.SelectedIndex == 0)
            {
                //update the "get" group
                GetData();
            }

            commsMngr.TryNewCommsTask();


            //lblStatus.Text = lblStatus.Text + "Tick";    //debug
        }


        //---Change update rate when user changes the value---
        private void cmbMainUpdateRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMainUpdateRate.SelectedIndex == -1)
            {
                cmbMainUpdateRate.SelectedIndex = 0;
            }
            else if (cmbMainUpdateRate.SelectedIndex == 0)
            {
                autoUpdateOn = false;
                MainTimer.Interval = 1000;   // time between update (in ms)
            }
            else
            {
                MainTimer.Interval = (int)(Convert.ToDouble(cmbMainUpdateRate.SelectedItem.ToString()) * 1000);
                autoUpdateOn = true;
            }
        }


        //---Sets all 'Set' Controls to their default state
        private void SetDefault()
        {
            int defaultValIndex = cmbMainUpdateRate.Items.IndexOf(Properties.Settings.Default.VariableUpdateInterval);
            if (defaultValIndex != -1)
            {
                cmbMainUpdateRate.SelectedIndex = defaultValIndex;
            }
            else cmbMainUpdateRate.SelectedIndex = 0;
            /*defaultValIndex = cmbGraphUpdateRate.Items.IndexOf(Properties.Settings.Default.GraphUpdateInterval);
            if (defaultValIndex != -1)
            {
                cmbGraphUpdateRate.SelectedIndex = defaultValIndex;
            }
            else cmbGraphUpdateRate.SelectedIndex = 0;
            */
            for (int i = 0; i < guiSetBtnSize; i++)
            {
                if (btnGroup[i] != null)
                {
                    btnGroup[i].SetDefault();
                }
            }

            for (int i = 0; i < guiSetTxtSize; i++)
            {
                if (txtGroup[i] != null)
                {
                    txtGroup[i].SetDefault();
                }
            }

            for (int i = 0; i < guiSetSldrSize; i++)
            {
                if (sldrGroup[i] != null)
                {
                    sldrGroup[i].SetDefault();
                }
            }
        }


        //---Restore Old Settings (internal storage or the settings stored in "[Project].exe.config")
        private void btnResetDefaults_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Reload();

            if (commsMngr.IsOpen == true)
            {
                SetDefault();
            }
            else
            {
                propsForm.SetDefault();
            }
        }


        //---Save new Settings to Internal Storage
        private void btnSaveDefaults_Click(object sender, EventArgs e)
        {
            if (cmbMainUpdateRate.SelectedItem != null)
            {
                Properties.Settings.Default.VariableUpdateInterval = cmbMainUpdateRate.SelectedItem.ToString();
            }
            Properties.Settings.Default.Save();
        }


        //---Close sci and peripheral forms in case user closes form---
        private void TwoChannelBuck_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (btnConnect.Text == "Disconnect")
            {
                btnConnect_Click(this, new EventArgs());
            }
            propsForm.Close();
            //grphForm.Close();
            commsMngr.Close();
        }


        //***************************************
        #region Graph and Graph Timer code
        /*
        //Show the GraphForm and start the graph's timer
        public void btnShowGraph_Click(object sender, EventArgs e)
        {
            if (btnShowGraph.Text == "Show Graph")
            {
                grphForm.Show();
                btnShowGraph.Text = "Hide Graph";
                graphOn = true;
                GraphTimer.Interval = (int)(Convert.ToDouble(cmbGraphUpdateRate.SelectedItem.ToString()) * 1000);
                GraphTimer.Start();
            }
            else
            {
                GraphTimer.Stop();
                grphForm.TopMost = false;
                grphForm.Hide();
                btnShowGraph.Text = "Show Graph";
                graphOn = false;
            }
        }


        //Call GetGraphData each time the graph timer ticks
        private void GraphTimer_Tick(object sender, EventArgs e)
        {
            if (graphOn == true)
            {
                GetGraphData();
            }
        }


        //Request Data Buffer from the target
        private void GetGraphData()
        {
            for (int i = 0; i < TSGraphGroup.Length; i++)
            {
                TSGraphGroup[i].RequestBuffer();
            }
        }
        

        //Change the graph's update rate when the user changes it
        private void cmbGraphUpdateRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbGraphUpdateRate.SelectedIndex == -1)
            {
                cmbGraphUpdateRate.SelectedIndex = 0;
            }
            else
            {
                GraphTimer.Interval = (int)(Convert.ToDouble(cmbGraphUpdateRate.SelectedItem.ToString()) * 1000);
            }
        }
        */
        #endregion
        //***************************************

        //Begin ProjectProperties Form
        private void btnSetupConnection_Click(object sender, EventArgs e)
        {
            Disconnect();
            Properties.Settings.Default.Reload();
            propsForm.Refresh();
            powerCycled = false;
            propsForm.Show();
        }


        #endregion



        //----------------------------------------------------------

        #region Individual Event Handlers
        //---------------------------------------------------------

        #region Button Set Event Handlers

        private void GenericEventHandler_SetBtn_BtnClick(object sender, EventArgs e)
        {
            int temp = (int)((Control)sender).Tag;
            btnGroup[temp].SetButton();
        }

        //**Instructions specific to this control
        //Start Up controls channel 1 enable and channel 2 enable in code
        /*private void btnStartUp_Click(object sender, EventArgs e)
        {
            int temp = (int)((Control)sender).Tag;
            btnGroup[temp].SetButton();

            
            if (btnGroup[temp].value == 1)
            {
                btnGroup[0].value = 1;
                //btnEnableCH1.Text = "On";
                //btnEnableCH1.ForeColor = System.Drawing.Color.Green;
                btnGroup[1].value = 1;
                btnEnableCH2.Text = "On";
                btnEnableCH2.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                //btnGroup[0].value = 0;
                //btnEnableCH1.Text = "Off";
                //btnEnableCH1.ForeColor = System.Drawing.Color.Red;
                //btnGroup[1].value = 0;
                //btnEnableCH2.Text = "Off";
                //btnEnableCH2.ForeColor = System.Drawing.Color.Red;
            }
            //**
        }*/

        #endregion



        #region Text Set Event Handlers

        private void GenericEventHandler_SetTxt_TxtChanged(object sender, EventArgs e)
        {
            int temp = (int)((Control)sender).Tag;
            txtGroup[temp].CheckValidity();
        }

        private void GenericEventHandler_SetTxt_TxtKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                int temp = (int)((Control)sender).Tag;
                txtGroup[temp].SetText();
            }
        }

        private void GenericEventHandler_SetTxt_BtnClick(object sender, EventArgs e)
        {
            int temp = (int)((Control)sender).Tag;
            txtGroup[temp].SetText();
        }

        #endregion



        #region Slider Set Event Handlers
        private void GenericEventHandler_SetSldr_SldrScroll(object sender, EventArgs e)
        {
            int temp = (int)((Control)sender).Tag;
            sldrGroup[temp].SetSlider();
        }

        private void GenericEventHandler_SetSldr_TxtKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                int temp = (int)((Control)sender).Tag;
                sldrGroup[temp].SetText();
            }
        }

        private void GenericEventHandler_SetSldr_TxtChanged(object sender, EventArgs e)
        {
            int temp = (int)((Control)sender).Tag;
            sldrGroup[temp].CheckValidity();
        }
        #endregion

        private void chbAutoColor_CheckedChanged(object sender, EventArgs e)
        {
            if (chbAutoColor.Checked == true)
            {
                commsMngr.NewSetTask(null, 0x01, 0x02, 1);

                pnlLEDControl1.Enabled = false;
                pnlLEDControl2.Enabled = false;
                pnlLEDControl3.Enabled = false;
                pnlSetColor1.Enabled = false;

                pnlLedLabel1.BackColor = System.Drawing.Color.LightGray;
                pnlLedLabel2.BackColor = System.Drawing.Color.LightGray;
                pnlLedLabel3.BackColor = System.Drawing.Color.LightGray;
                pnlSetColor.BackColor = System.Drawing.Color.LightGray;

                Application.DoEvents();
            }
            else
            {
                commsMngr.NewSetTask(null, 0x01, 0x02, 0);

                pnlLedLabel1.BackColor = System.Drawing.Color.DimGray;
                pnlLedLabel2.BackColor = System.Drawing.Color.DimGray;
                pnlLedLabel3.BackColor = System.Drawing.Color.DimGray;
                pnlSetColor.BackColor = System.Drawing.Color.DimGray;

                pnlLEDControl1.Enabled = true;
                pnlLEDControl2.Enabled = true;
                pnlLEDControl3.Enabled = true;
                pnlSetColor1.Enabled = true;

                txtIsetLED1.ForeColor = System.Drawing.Color.SeaGreen;
                txtIsetLED2.ForeColor = System.Drawing.Color.SeaGreen;
                txtIsetLED3.ForeColor = System.Drawing.Color.SeaGreen;
 
                int temp = (int)((Control)txtIsetLED1).Tag;
                sldrGroup[temp].SetText();
                temp = (int)((Control)txtIsetLED2).Tag;
                sldrGroup[temp].SetText();
                temp = (int)((Control)txtIsetLED3).Tag;
                sldrGroup[temp].SetText();
 
                Application.DoEvents();
            }
        }

        private void btnLicenseAgree_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.LicenseAccept = true;
            Properties.Settings.Default.Save();
            pnlLicense.Visible = false;
        }

        private void btnLicenseDisagree_Click(object sender, EventArgs e)
        {
            Close();
        }

        #region SetColor1
        private void btnRed1_Click(object sender, EventArgs e)
        {
            commsMngr.NewSetTask(null, 0x01, 0x03, 1);

            txtIsetLED1.Text = "0.0";
            txtIsetLED2.Text = "0.0";
            txtIsetLED3.Text = "0.03";

            int temp = (int)((Control)txtIsetLED1).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED2).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED3).Tag;
            sldrGroup[temp].SetText();
        }

        private void btnOrange1_Click(object sender, EventArgs e)
        {
            commsMngr.NewSetTask(null, 0x01, 0x03, 2);

            txtIsetLED1.Text = "0.0";
            txtIsetLED2.Text = "0.01";
            txtIsetLED3.Text = "0.035";

            int temp = (int)((Control)txtIsetLED1).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED2).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED3).Tag;
            sldrGroup[temp].SetText();
        }

        private void btnYellow1_Click(object sender, EventArgs e)
        {
            commsMngr.NewSetTask(null, 0x01, 0x03, 3);

            txtIsetLED1.Text = "0.0";
            txtIsetLED2.Text = "0.025";
            txtIsetLED3.Text = "0.035";

            int temp = (int)((Control)txtIsetLED1).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED2).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED3).Tag;
            sldrGroup[temp].SetText();
        }

        private void btnGreen1_Click(object sender, EventArgs e)
        {
            commsMngr.NewSetTask(null, 0x01, 0x03, 4);

            txtIsetLED1.Text = "0.0";
            txtIsetLED2.Text = "0.03";
            txtIsetLED3.Text = "0.0";

            int temp = (int)((Control)txtIsetLED1).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED2).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED3).Tag;
            sldrGroup[temp].SetText();
        }

        private void btnBlue1_Click(object sender, EventArgs e)
        {
            commsMngr.NewSetTask(null, 0x01, 0x03, 5);

            txtIsetLED1.Text = "0.03";
            txtIsetLED2.Text = "0.0";
            txtIsetLED3.Text = "0.0";

            int temp = (int)((Control)txtIsetLED1).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED2).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED3).Tag;
            sldrGroup[temp].SetText();
        }

        private void btnPurple1_Click(object sender, EventArgs e)
        {
            commsMngr.NewSetTask(null, 0x01, 0x03, 6);

            txtIsetLED1.Text = "0.025";
            txtIsetLED2.Text = "0.0";
            txtIsetLED3.Text = "0.025";

            int temp = (int)((Control)txtIsetLED1).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED2).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED3).Tag;
            sldrGroup[temp].SetText();
        }

        private void btnWhite1_Click(object sender, EventArgs e)
        {
            commsMngr.NewSetTask(null, 0x01, 0x03, 7);

            txtIsetLED1.Text = "0.015";
            txtIsetLED2.Text = "0.02";
            txtIsetLED3.Text = "0.025";

            int temp = (int)((Control)txtIsetLED1).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED2).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED3).Tag;
            sldrGroup[temp].SetText();
        }

        private void btnBlack1_Click(object sender, EventArgs e)
        {
            commsMngr.NewSetTask(null, 0x01, 0x03, 8);

            txtIsetLED1.Text = "0.0";
            txtIsetLED2.Text = "0.0";
            txtIsetLED3.Text = "0.0";

            int temp = (int)((Control)txtIsetLED1).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED2).Tag;
            sldrGroup[temp].SetText();
            temp = (int)((Control)txtIsetLED3).Tag;
            sldrGroup[temp].SetText();
        }
        #endregion


        #endregion
        //-----------------------------------------------------------
    }
}