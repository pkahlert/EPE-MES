var _d_s_p2803x___e_pwm_8h =
[
    [ "TBCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_t_b_c_t_l___b_i_t_s", [
      [ "CLKDIV", "_d_s_p2803x___e_pwm_8h.html#aed02f6a3e79286a331f1720cd7317e4b", null ],
      [ "CTRMODE", "_d_s_p2803x___e_pwm_8h.html#a725224096dc89831541ef37ad28dd446", null ],
      [ "FREE_SOFT", "_d_s_p2803x___e_pwm_8h.html#af954874375a6c568736221d424bba615", null ],
      [ "HSPCLKDIV", "_d_s_p2803x___e_pwm_8h.html#aa49e849f8079ae14e86faa869201df7c", null ],
      [ "PHSDIR", "_d_s_p2803x___e_pwm_8h.html#abb613a08912cbf93f40d8db007f62ba3", null ],
      [ "PHSEN", "_d_s_p2803x___e_pwm_8h.html#a96a4da5ef136835e2b22b72ac69f7a8c", null ],
      [ "PRDLD", "_d_s_p2803x___e_pwm_8h.html#a065fbfe287f5b67070779d6168315b98", null ],
      [ "SWFSYNC", "_d_s_p2803x___e_pwm_8h.html#a1d2212fc310d325ea8640851029b87f3", null ],
      [ "SYNCOSEL", "_d_s_p2803x___e_pwm_8h.html#afa440d6bae07f57ad2f2661d47a1d7ab", null ]
    ] ],
    [ "TBCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_t_b_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a795f0d7112e6255bc16b60a475da48c6", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a3711d8f5d94af524e24c1a428d7cbd57", null ]
    ] ],
    [ "TBSTS_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_t_b_s_t_s___b_i_t_s", [
      [ "CTRDIR", "_d_s_p2803x___e_pwm_8h.html#ae1ed80e30fcbe5d6a8e3d9d0cf29b5ae", null ],
      [ "CTRMAX", "_d_s_p2803x___e_pwm_8h.html#acc2c468bdd1013da5c8a8ec143a95656", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a2da0d8461457e5ab1b477bac21961dcc", null ],
      [ "SYNCI", "_d_s_p2803x___e_pwm_8h.html#ac7a61291a04c2082310d8e75cd7beeef", null ]
    ] ],
    [ "TBSTS_REG", "_d_s_p2803x___e_pwm_8h.html#union_t_b_s_t_s___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#aaf971464c815c857aaca768ee7564388", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#ab0c63b7a9adfd63ae0df0fee80174a66", null ]
    ] ],
    [ "CMPCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_c_m_p_c_t_l___b_i_t_s", [
      [ "LOADAMODE", "_d_s_p2803x___e_pwm_8h.html#a851c50402575772ec638c931e265be55", null ],
      [ "LOADBMODE", "_d_s_p2803x___e_pwm_8h.html#ae4e8680b95e911401e2318268c792fff", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#ae0addbec61528418f88a12c699167f2f", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#a66895cb0ae9534fd392151cfdc2913a7", null ],
      [ "rsvd3", "_d_s_p2803x___e_pwm_8h.html#aecb25dc041fd5044acda993764831924", null ],
      [ "SHDWAFULL", "_d_s_p2803x___e_pwm_8h.html#a007be44f7c8438452d0ae4fc5e424930", null ],
      [ "SHDWAMODE", "_d_s_p2803x___e_pwm_8h.html#afe97f77846f4a57d50e7b77170dd12f8", null ],
      [ "SHDWBFULL", "_d_s_p2803x___e_pwm_8h.html#a2a46088e417d228ceded88babad9186d", null ],
      [ "SHDWBMODE", "_d_s_p2803x___e_pwm_8h.html#ab25286ed3730d338163a66f5c5199204", null ]
    ] ],
    [ "CMPCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_c_m_p_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a107c22728b55409f4b388976db7e1544", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a2708576433d3f57ab5038868cb5168ba", null ]
    ] ],
    [ "AQCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_a_q_c_t_l___b_i_t_s", [
      [ "CAD", "_d_s_p2803x___e_pwm_8h.html#af6baa44c4ecdae2507a11ded51734390", null ],
      [ "CAU", "_d_s_p2803x___e_pwm_8h.html#a5037c104c7bdf74df20fafdeab3e2583", null ],
      [ "CBD", "_d_s_p2803x___e_pwm_8h.html#add9d636c9f98e2a27b1fe4084d7f79df", null ],
      [ "CBU", "_d_s_p2803x___e_pwm_8h.html#a9b4625cfb7b62fa9d1227773bfa188ea", null ],
      [ "PRD", "_d_s_p2803x___e_pwm_8h.html#a5196957c15b6868af4e0415c001ca76f", null ],
      [ "rsvd", "_d_s_p2803x___e_pwm_8h.html#a8ac84438d588671b2e7d9f6a48eb4092", null ],
      [ "ZRO", "_d_s_p2803x___e_pwm_8h.html#a364e3885e2683e062df9092186017c2f", null ]
    ] ],
    [ "AQCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_a_q_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#ada5eb92628cb6a3eb32b0918fc7053c0", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#af034f5bceb4148b2aa0933540354c689", null ]
    ] ],
    [ "AQSFRC_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_a_q_s_f_r_c___b_i_t_s", [
      [ "ACTSFA", "_d_s_p2803x___e_pwm_8h.html#a94304a5650936384e1c6d9ef1d502696", null ],
      [ "ACTSFB", "_d_s_p2803x___e_pwm_8h.html#a2325e022063bd6236599bc11b0d54d84", null ],
      [ "OTSFA", "_d_s_p2803x___e_pwm_8h.html#a12d5c4663ef97ea99a719b5c287f8996", null ],
      [ "OTSFB", "_d_s_p2803x___e_pwm_8h.html#addae1cf0fc0a6654ff49cc4311bc74f4", null ],
      [ "RLDCSF", "_d_s_p2803x___e_pwm_8h.html#a02d6835af69c7330aa1d694c88005806", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a9ebf0b80bd7387ea41f97cf94c3e7d49", null ]
    ] ],
    [ "AQSFRC_REG", "_d_s_p2803x___e_pwm_8h.html#union_a_q_s_f_r_c___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a3115406804540f75d6fac45aa5e0f304", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a215496b926dba83fd37860bb58ede498", null ]
    ] ],
    [ "AQCSFRC_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_a_q_c_s_f_r_c___b_i_t_s", [
      [ "CSFA", "_d_s_p2803x___e_pwm_8h.html#a8b6ffc79b09d27c6e83c6b832151bcc4", null ],
      [ "CSFB", "_d_s_p2803x___e_pwm_8h.html#aa24b9e006ae4e4ce2a7167e470cb9e15", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#aa9fe8f62c165ed323c1b94b6836a6689", null ]
    ] ],
    [ "AQCSFRC_REG", "_d_s_p2803x___e_pwm_8h.html#union_a_q_c_s_f_r_c___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a67723d7469342c87613d15fa81f06249", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a6dbdc1ad495403284ffd3bf01fc0f270", null ]
    ] ],
    [ "DBCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_d_b_c_t_l___b_i_t_s", [
      [ "HALFCYCLE", "_d_s_p2803x___e_pwm_8h.html#a2062b8944a5d68b5f0a5ebd7a22bb35f", null ],
      [ "IN_MODE", "_d_s_p2803x___e_pwm_8h.html#a04f7b00aa3605dbe9a2821ffa0e3d783", null ],
      [ "OUT_MODE", "_d_s_p2803x___e_pwm_8h.html#ad7f97d155341f0d6795182f34dd12640", null ],
      [ "POLSEL", "_d_s_p2803x___e_pwm_8h.html#ae2a2680efb137de1b03367e1ce428977", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a1e8e61d0701b48cf115ecf346c366635", null ]
    ] ],
    [ "DBCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_d_b_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#ac738982a5f65e93795c02c02456dd32e", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a24003f017dfbe56d95aabe91886a7cca", null ]
    ] ],
    [ "TZSEL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_t_z_s_e_l___b_i_t_s", [
      [ "CBC1", "_d_s_p2803x___e_pwm_8h.html#a15cc1188e9b27d116d93dc713d6a6f83", null ],
      [ "CBC2", "_d_s_p2803x___e_pwm_8h.html#ae891eff0d90dce2041ea2c516cccf710", null ],
      [ "CBC3", "_d_s_p2803x___e_pwm_8h.html#a40f244deef0c4f5e38f8f2395526b254", null ],
      [ "CBC4", "_d_s_p2803x___e_pwm_8h.html#a0da88d58314647f2c183713baaed1397", null ],
      [ "CBC5", "_d_s_p2803x___e_pwm_8h.html#a8c78381a9d915c79586fcd900ef3bbc3", null ],
      [ "CBC6", "_d_s_p2803x___e_pwm_8h.html#aa9f3ba2f2016ec3472e6455d0de844cb", null ],
      [ "DCAEVT1", "_d_s_p2803x___e_pwm_8h.html#aac081e813915082f0a1ec15e1475c46b", null ],
      [ "DCAEVT2", "_d_s_p2803x___e_pwm_8h.html#aa5304768249c37d72f91ce3029d9640b", null ],
      [ "DCBEVT1", "_d_s_p2803x___e_pwm_8h.html#a954428996afd622cba49feffb2dbe10c", null ],
      [ "DCBEVT2", "_d_s_p2803x___e_pwm_8h.html#a8092ebd98215089f12bf37cfe6b9c7b6", null ],
      [ "OSHT1", "_d_s_p2803x___e_pwm_8h.html#adc7cc5cfa48cebe7eef8771e81f3c80c", null ],
      [ "OSHT2", "_d_s_p2803x___e_pwm_8h.html#ac4ccbe50e855606f4da80e249a98af2c", null ],
      [ "OSHT3", "_d_s_p2803x___e_pwm_8h.html#ac15249434559c42d7c9708945a6088ad", null ],
      [ "OSHT4", "_d_s_p2803x___e_pwm_8h.html#a1b236c6f20bcd2f01bd59c8de68bda3d", null ],
      [ "OSHT5", "_d_s_p2803x___e_pwm_8h.html#afb253f52d56aa31800530797efa6a242", null ],
      [ "OSHT6", "_d_s_p2803x___e_pwm_8h.html#a686769f5303fb01691a197884620c93c", null ]
    ] ],
    [ "TZSEL_REG", "_d_s_p2803x___e_pwm_8h.html#union_t_z_s_e_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a19d6114c4d665b48a08af1341787d6d8", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#aac30c3b8dffbd33b50718880c7d53d68", null ]
    ] ],
    [ "TZDCSEL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_t_z_d_c_s_e_l___b_i_t_s", [
      [ "DCAEVT1", "_d_s_p2803x___e_pwm_8h.html#ab21923249af94fb29b13d98485872da9", null ],
      [ "DCAEVT2", "_d_s_p2803x___e_pwm_8h.html#af1971e35c723c35de8bca56d7779db0e", null ],
      [ "DCBEVT1", "_d_s_p2803x___e_pwm_8h.html#ac809c83eedf38c4abaacf21128c3f47f", null ],
      [ "DCBEVT2", "_d_s_p2803x___e_pwm_8h.html#a7c01d5da77e26a6c7c2102ed05ac8fad", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#af45f7f99049c9ac689e84726d70aba57", null ]
    ] ],
    [ "TZDCSEL_REG", "_d_s_p2803x___e_pwm_8h.html#union_t_z_d_c_s_e_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a10dd0daabc926b64ff25aca161d31380", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a4ac9e84f6f855c27d0691990a4f9992e", null ]
    ] ],
    [ "TZCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_t_z_c_t_l___b_i_t_s", [
      [ "DCAEVT1", "_d_s_p2803x___e_pwm_8h.html#a1c28e845ca815d7fdab1e0900149b6d3", null ],
      [ "DCAEVT2", "_d_s_p2803x___e_pwm_8h.html#aa0b3a7d013c473cdd90951e88e8a30f5", null ],
      [ "DCBEVT1", "_d_s_p2803x___e_pwm_8h.html#a1c1c97f67b575470eefb8d22272b1e85", null ],
      [ "DCBEVT2", "_d_s_p2803x___e_pwm_8h.html#ac5daf82c0adc1d55e2b6d80610a6154a", null ],
      [ "rsvd", "_d_s_p2803x___e_pwm_8h.html#a92b96b19d8e95c951715f6ddfb5780ba", null ],
      [ "TZA", "_d_s_p2803x___e_pwm_8h.html#a7557ecc52712f5bf212cbb1f56132af4", null ],
      [ "TZB", "_d_s_p2803x___e_pwm_8h.html#a04447a5e9e039ca172fe8e6168243cf2", null ]
    ] ],
    [ "TZCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_t_z_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#ad7607a709a969964468ac0c0cbe37c00", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a092a579dd9c8c7a8093db8f52d9f4c56", null ]
    ] ],
    [ "TZEINT_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_t_z_e_i_n_t___b_i_t_s", [
      [ "CBC", "_d_s_p2803x___e_pwm_8h.html#af6d87ad425a263f5e238e04f40c9cc0b", null ],
      [ "DCAEVT1", "_d_s_p2803x___e_pwm_8h.html#a6590d026b664bea00dd48270710104f3", null ],
      [ "DCAEVT2", "_d_s_p2803x___e_pwm_8h.html#a683be245b7e81d3019c4defaa717a2f3", null ],
      [ "DCBEVT1", "_d_s_p2803x___e_pwm_8h.html#ae470136f26bc5516c7ec110c851889e0", null ],
      [ "DCBEVT2", "_d_s_p2803x___e_pwm_8h.html#a76a3da89309f5e25e658cdc6d80211c4", null ],
      [ "OST", "_d_s_p2803x___e_pwm_8h.html#a4926cd6f43fbb51292731e428cd5aedd", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a8b7d089e227e96416125b290bf8c577e", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#aedb9d3ba82619c40020d9972536fbb2d", null ]
    ] ],
    [ "TZEINT_REG", "_d_s_p2803x___e_pwm_8h.html#union_t_z_e_i_n_t___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a7a312a5bc10a31c9f9e536bd32afd09c", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a012d55fc7f01f604d38099c5f40ffd9d", null ]
    ] ],
    [ "TZFLG_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_t_z_f_l_g___b_i_t_s", [
      [ "CBC", "_d_s_p2803x___e_pwm_8h.html#ad6b725c9618183cdf803205bebdc4c2b", null ],
      [ "DCAEVT1", "_d_s_p2803x___e_pwm_8h.html#a7d03f3696a5e12d71845bb381fe7453b", null ],
      [ "DCAEVT2", "_d_s_p2803x___e_pwm_8h.html#a9130583afd16e1a66f0cbcc91070e636", null ],
      [ "DCBEVT1", "_d_s_p2803x___e_pwm_8h.html#a449bfddbdeeafd594ddab9536581b8fe", null ],
      [ "DCBEVT2", "_d_s_p2803x___e_pwm_8h.html#ac348344f5e2092e05aa7b4538e76db24", null ],
      [ "INT", "_d_s_p2803x___e_pwm_8h.html#a30a47948c9f09737b1738836c0675cb8", null ],
      [ "OST", "_d_s_p2803x___e_pwm_8h.html#a1470de850b06afeaad899784e95a75c9", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#ab551b38c80c2eb56f237ecc27053b090", null ]
    ] ],
    [ "TZFLG_REG", "_d_s_p2803x___e_pwm_8h.html#union_t_z_f_l_g___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a9dff2c4e35377deddb81f631a03e26ac", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a29e81c4bfff5247ef4abe545db4897c8", null ]
    ] ],
    [ "TZCLR_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_t_z_c_l_r___b_i_t_s", [
      [ "CBC", "_d_s_p2803x___e_pwm_8h.html#a7e94424e5e2620115e7ed0bf0b15189b", null ],
      [ "DCAEVT1", "_d_s_p2803x___e_pwm_8h.html#a6d87b635291a4036ae1d601a30b13020", null ],
      [ "DCAEVT2", "_d_s_p2803x___e_pwm_8h.html#a232fc61d53cf75233fcaff822cb072af", null ],
      [ "DCBEVT1", "_d_s_p2803x___e_pwm_8h.html#a7226a0580fc9980a3b8090503997d1b7", null ],
      [ "DCBEVT2", "_d_s_p2803x___e_pwm_8h.html#ab2b90d53db709a9d828b76b700ce87b1", null ],
      [ "INT", "_d_s_p2803x___e_pwm_8h.html#a66629d4927224c2e5ba60a8bb8c6398b", null ],
      [ "OST", "_d_s_p2803x___e_pwm_8h.html#ac62fe9e0268c55533748b592b1895aa1", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#a5d5275ffe47f3553720648c9dce9dacf", null ]
    ] ],
    [ "TZCLR_REG", "_d_s_p2803x___e_pwm_8h.html#union_t_z_c_l_r___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#afc7496aa5792f961d0ea287749583d30", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#aebe7ea2b8dc74bcf62d441559a970029", null ]
    ] ],
    [ "TZFRC_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_t_z_f_r_c___b_i_t_s", [
      [ "CBC", "_d_s_p2803x___e_pwm_8h.html#a98e55a1cc97e3fc2f0447b924f1e905a", null ],
      [ "DCAEVT1", "_d_s_p2803x___e_pwm_8h.html#acb32c198ffd8f3197587faa30ae59b89", null ],
      [ "DCAEVT2", "_d_s_p2803x___e_pwm_8h.html#a821e6327c659b6c9120b6b90d060be81", null ],
      [ "DCBEVT1", "_d_s_p2803x___e_pwm_8h.html#a3cda4a78b162636b29a473803b4e2c3d", null ],
      [ "DCBEVT2", "_d_s_p2803x___e_pwm_8h.html#ae1d2ac1a7a5c10fad34262d45df8dcd5", null ],
      [ "OST", "_d_s_p2803x___e_pwm_8h.html#a2826e90b0c2cc347930bf3805519bd10", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#aef9312e1fcf1d83836cb3c081477eadc", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#ac63811b78881cd2ef7ad907d51f15a74", null ]
    ] ],
    [ "TZFRC_REG", "_d_s_p2803x___e_pwm_8h.html#union_t_z_f_r_c___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#ab2e66514a19e53fa53312c1140e1bad5", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#aca2bd644b07f92ceb7ab8b4a21b7ed2e", null ]
    ] ],
    [ "ETSEL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_e_t_s_e_l___b_i_t_s", [
      [ "INTEN", "_d_s_p2803x___e_pwm_8h.html#a69d1edf956ca42ad4cc04f3f84c93459", null ],
      [ "INTSEL", "_d_s_p2803x___e_pwm_8h.html#a68173ce0fb311ca5926051c447b00fac", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a6fa2b8302862329ee6d6f07dae0afcdd", null ],
      [ "SOCAEN", "_d_s_p2803x___e_pwm_8h.html#a7ae7a05e912a4ac2c47789711c705fe8", null ],
      [ "SOCASEL", "_d_s_p2803x___e_pwm_8h.html#a1ece835f2fe541c1281d5ee029478ff3", null ],
      [ "SOCBEN", "_d_s_p2803x___e_pwm_8h.html#ad5afc2b9ad38f8b1f95c67f9597406c1", null ],
      [ "SOCBSEL", "_d_s_p2803x___e_pwm_8h.html#a6616efc33d6cefacf585954ecdf35202", null ]
    ] ],
    [ "ETSEL_REG", "_d_s_p2803x___e_pwm_8h.html#union_e_t_s_e_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a82af3b7514fcf2b77fc70580e5c59b3d", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a60cd535719d537bb4eecd39561b0b90f", null ]
    ] ],
    [ "ETPS_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_e_t_p_s___b_i_t_s", [
      [ "INTCNT", "_d_s_p2803x___e_pwm_8h.html#af1069f0eb329f7019a1ed5cb6e94f019", null ],
      [ "INTPRD", "_d_s_p2803x___e_pwm_8h.html#a99fda2d93192fcf2336c9a672c41af92", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#ac4375d150d419bf2235a9e6616f605ee", null ],
      [ "SOCACNT", "_d_s_p2803x___e_pwm_8h.html#a98b843a9627afc41c5aeea8887cab3e7", null ],
      [ "SOCAPRD", "_d_s_p2803x___e_pwm_8h.html#af674d62b3748023e0d40afdfb03e9542", null ],
      [ "SOCBCNT", "_d_s_p2803x___e_pwm_8h.html#a58e50ab18d578b332587f16acf765d81", null ],
      [ "SOCBPRD", "_d_s_p2803x___e_pwm_8h.html#aae6da719ccf98a207a587d44a0ec19a5", null ]
    ] ],
    [ "ETPS_REG", "_d_s_p2803x___e_pwm_8h.html#union_e_t_p_s___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a22bf245310e24111e1e71439de6951aa", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#ab7c8fb7b79918c074465d9a24d49e24d", null ]
    ] ],
    [ "ETFLG_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_e_t_f_l_g___b_i_t_s", [
      [ "INT", "_d_s_p2803x___e_pwm_8h.html#aa752c6c8e6ec7d6bc03b7911dc5378c1", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#aebc56841c14c0d1f7fac4f397c930da9", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#a621c11cb01aaa555f250930a51e7cf14", null ],
      [ "SOCA", "_d_s_p2803x___e_pwm_8h.html#a45fdebff1773a7f73574963b8da39dc1", null ],
      [ "SOCB", "_d_s_p2803x___e_pwm_8h.html#a6df3e745fc78633079eb9529c2f00b6d", null ]
    ] ],
    [ "ETFLG_REG", "_d_s_p2803x___e_pwm_8h.html#union_e_t_f_l_g___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#af6a261522cbb623e97bf54196459d28d", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a96c6de06986a851a04ea3d3356bde4f6", null ]
    ] ],
    [ "ETCLR_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_e_t_c_l_r___b_i_t_s", [
      [ "INT", "_d_s_p2803x___e_pwm_8h.html#a436e99aac7a04b606cf7e1c90e298a6c", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a582c71a711e4b704d259ab256b9677d0", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#a262c31e7a22f46dab5bfb74f104c9aec", null ],
      [ "SOCA", "_d_s_p2803x___e_pwm_8h.html#a3922cb8e413915cb0eff6138c5fdfe80", null ],
      [ "SOCB", "_d_s_p2803x___e_pwm_8h.html#a025a3c7cd5ed79701addf5fb90990176", null ]
    ] ],
    [ "ETCLR_REG", "_d_s_p2803x___e_pwm_8h.html#union_e_t_c_l_r___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a9d3d4240a799621100cba7c10f69a8d7", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a0c883684f9a77e7df903c4cba451b61f", null ]
    ] ],
    [ "ETFRC_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_e_t_f_r_c___b_i_t_s", [
      [ "INT", "_d_s_p2803x___e_pwm_8h.html#ae1f135106db9a6fdf35739788345d304", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a4e9f74b4a588cc1d6304c53c53a36fe7", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#a06beb0b06a675ceac3abd84354508697", null ],
      [ "SOCA", "_d_s_p2803x___e_pwm_8h.html#a1a07c6ec06e2172948ef67d07b854b09", null ],
      [ "SOCB", "_d_s_p2803x___e_pwm_8h.html#ad6c61eba7afe447dee0f2d50cde20205", null ]
    ] ],
    [ "ETFRC_REG", "_d_s_p2803x___e_pwm_8h.html#union_e_t_f_r_c___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#aa71d9444f9be6372e734c9308e98c51f", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#aee9b186b3c90ad2a6d414e4cc6daedbd", null ]
    ] ],
    [ "PCCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_p_c_c_t_l___b_i_t_s", [
      [ "CHPDUTY", "_d_s_p2803x___e_pwm_8h.html#afe02901833db45444ce3c97305248e8c", null ],
      [ "CHPEN", "_d_s_p2803x___e_pwm_8h.html#a0b4bc7768b79be8f8af5bd9af3bf050a", null ],
      [ "CHPFREQ", "_d_s_p2803x___e_pwm_8h.html#a8bdfb308ef78915633cfb18cd76ed153", null ],
      [ "OSHTWTH", "_d_s_p2803x___e_pwm_8h.html#ae278a0bc2c79ef54ecbc29fca4518851", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a7ea0e817ae5dd68a7d1f1ce0085618d3", null ]
    ] ],
    [ "PCCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_p_c_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a49e651573f3b8bfbff1d46d9262f2186", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#ac8dfca4b64bc9e5f4d8cb8bc621efd33", null ]
    ] ],
    [ "DCTRIPSEL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_d_c_t_r_i_p_s_e_l___b_i_t_s", [
      [ "DCAHCOMPSEL", "_d_s_p2803x___e_pwm_8h.html#af1b4c48cba98f2e7975bb33d25f433c8", null ],
      [ "DCALCOMPSEL", "_d_s_p2803x___e_pwm_8h.html#aeb2835e77396fcde5fb6552423d09432", null ],
      [ "DCBHCOMPSEL", "_d_s_p2803x___e_pwm_8h.html#ab9b0fd5b94c89e94d6f68f703dc39fef", null ],
      [ "DCBLCOMPSEL", "_d_s_p2803x___e_pwm_8h.html#a166067e9ff98b2b44e4b954d2e671a69", null ]
    ] ],
    [ "DCTRIPSEL_REG", "_d_s_p2803x___e_pwm_8h.html#union_d_c_t_r_i_p_s_e_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#ab85eb987700e98688958314c2683fc44", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a52a743eb2f2c979e7f7d85af25774b48", null ]
    ] ],
    [ "DCCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_d_c_c_t_l___b_i_t_s", [
      [ "EVT1FRCSYNCSEL", "_d_s_p2803x___e_pwm_8h.html#a68da03184dae8d5384cd9452ef89ae15", null ],
      [ "EVT1SOCE", "_d_s_p2803x___e_pwm_8h.html#afd6f8bb41a1b99726ab6565a2508c943", null ],
      [ "EVT1SRCSEL", "_d_s_p2803x___e_pwm_8h.html#a4fc0c860eee232ebcbd480f2aae21bb6", null ],
      [ "EVT1SYNCE", "_d_s_p2803x___e_pwm_8h.html#ab887933666e681016e100fcbe3040f32", null ],
      [ "EVT2FRCSYNCSEL", "_d_s_p2803x___e_pwm_8h.html#ad8726591e493a0fba47494e0d4f4199b", null ],
      [ "EVT2SRCSEL", "_d_s_p2803x___e_pwm_8h.html#a70fd976516f7d64999e5c47793e40f09", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a13dd60d8c3b834474fd27a29016c1f40", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#abc4ee9b52fea8bef80927466d039b4a5", null ]
    ] ],
    [ "DCCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_d_c_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a716ff85534f500b7e2635b0eb6000326", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#ad65cfabd22af99cc9056e79aaa771113", null ]
    ] ],
    [ "DCCAPCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_d_c_c_a_p_c_t_l___b_i_t_s", [
      [ "CAPE", "_d_s_p2803x___e_pwm_8h.html#a14dade40c596d2f456c07ce202a57bb5", null ],
      [ "rsvd", "_d_s_p2803x___e_pwm_8h.html#a7b4fe73afe07feeff4dbc1aa8e1e6fcb", null ],
      [ "SHDWMODE", "_d_s_p2803x___e_pwm_8h.html#a04278d55b5680c995b43de193674451b", null ]
    ] ],
    [ "DCCAPCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_d_c_c_a_p_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#ab4a537aac285191cc6e463b1d9c60937", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a101897d5710eabebf09a93ed3d87ae64", null ]
    ] ],
    [ "DCFCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_d_c_f_c_t_l___b_i_t_s", [
      [ "BLANKE", "_d_s_p2803x___e_pwm_8h.html#aa810010c6ffd700726628cee46bd4382", null ],
      [ "BLANKINV", "_d_s_p2803x___e_pwm_8h.html#afc9b749efaefb3928cb749d2691f2c37", null ],
      [ "PULSESEL", "_d_s_p2803x___e_pwm_8h.html#a8dcee7d30a2002740e9c151f59c78814", null ],
      [ "rsvd", "_d_s_p2803x___e_pwm_8h.html#a4caeab0efd789959bc912818d036ca7c", null ],
      [ "SRCSEL", "_d_s_p2803x___e_pwm_8h.html#a46328d438a94289c9d4be5c847b092fb", null ]
    ] ],
    [ "DCFCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_d_c_f_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a25e4f1fce99bd6b349e6debf3ecddb9b", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a6d6bdb7209f7b723a85ee830518fe8dd", null ]
    ] ],
    [ "HRPCTL_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_h_r_p_c_t_l___b_i_t_s", [
      [ "HRPE", "_d_s_p2803x___e_pwm_8h.html#aff9a8ecdb7952d260d806b62ae673935", null ],
      [ "PWMSYNCSEL", "_d_s_p2803x___e_pwm_8h.html#a67297723a1997c949c608038ff7f74aa", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a860819d5a634c01da860f5ac35192433", null ],
      [ "TBPHSHRLOADE", "_d_s_p2803x___e_pwm_8h.html#a77bf33f21d396e0db74ff87fb5fb3f9d", null ]
    ] ],
    [ "HRPCTL_REG", "_d_s_p2803x___e_pwm_8h.html#union_h_r_p_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a688757da98405a11a083ca7ccada13cb", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#adbc67145dd08c2c287b780a2fc847cb3", null ]
    ] ],
    [ "HRCNFG_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_h_r_c_n_f_g___b_i_t_s", [
      [ "AUTOCONV", "_d_s_p2803x___e_pwm_8h.html#a34778e00f439db3c0ce68bfe9d1f5363", null ],
      [ "CTLMODE", "_d_s_p2803x___e_pwm_8h.html#a5ecce07d6bb9f16bfa5b7be85f3582d1", null ],
      [ "EDGMODE", "_d_s_p2803x___e_pwm_8h.html#aafcb04b041a163e53a3f69cc7cfe9985", null ],
      [ "HRLOAD", "_d_s_p2803x___e_pwm_8h.html#a0d3a586f81f42dbc6e0058e589df79d8", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#ae9171039aace5808faba581f1dcd8a8e", null ],
      [ "SELOUTB", "_d_s_p2803x___e_pwm_8h.html#acc840d2de38a2380bf91c098764ba468", null ],
      [ "SWAPAB", "_d_s_p2803x___e_pwm_8h.html#ace8e4655d440fb51c27d1f0459026394", null ]
    ] ],
    [ "HRCNFG_REG", "_d_s_p2803x___e_pwm_8h.html#union_h_r_c_n_f_g___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a7794277ca46525639c0401b1b6668a97", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a74e926c24616efbdec32b12038e81212", null ]
    ] ],
    [ "HRPWR_BITS", "_d_s_p2803x___e_pwm_8h.html#struct_h_r_p_w_r___b_i_t_s", [
      [ "MEPOFF", "_d_s_p2803x___e_pwm_8h.html#aadd1717e603054f96b8201e612fa49d1", null ],
      [ "rsvd1", "_d_s_p2803x___e_pwm_8h.html#a8f79a2532ffe28f6faaf578d8b49bdfa", null ],
      [ "rsvd2", "_d_s_p2803x___e_pwm_8h.html#a658a9e2b42b85e8f0ca10020a843d6a6", null ]
    ] ],
    [ "HRPWR_REG", "_d_s_p2803x___e_pwm_8h.html#union_h_r_p_w_r___r_e_g", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#aca18ef90f428048d83574b2c01d3e429", null ],
      [ "bit", "_d_s_p2803x___e_pwm_8h.html#a9b732a9189a3f32fc44d80104d7a76fd", null ]
    ] ],
    [ "TBPHS_HRPWM_REG", "_d_s_p2803x___e_pwm_8h.html#struct_t_b_p_h_s___h_r_p_w_m___r_e_g", [
      [ "TBPHS", "_d_s_p2803x___e_pwm_8h.html#a28482d2987c5726d3001fb5a863de78a", null ],
      [ "TBPHSHR", "_d_s_p2803x___e_pwm_8h.html#af476ff5e3f9fbffaad0fecfab7f28488", null ]
    ] ],
    [ "TBPHS_HRPWM_GROUP", "_d_s_p2803x___e_pwm_8h.html#union_t_b_p_h_s___h_r_p_w_m___g_r_o_u_p", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a5e2d0438445f3ba4d7eed093f7394181", null ],
      [ "half", "_d_s_p2803x___e_pwm_8h.html#a4695304afa6ccac89d6c62f41d6a359b", null ]
    ] ],
    [ "CMPA_HRPWM_REG", "_d_s_p2803x___e_pwm_8h.html#struct_c_m_p_a___h_r_p_w_m___r_e_g", [
      [ "CMPA", "_d_s_p2803x___e_pwm_8h.html#addf36405fb05f157b30dabf3e7a88c51", null ],
      [ "CMPAHR", "_d_s_p2803x___e_pwm_8h.html#ab0aabc0d6e9e25a559871667882df392", null ]
    ] ],
    [ "CMPA_HRPWM_GROUP", "_d_s_p2803x___e_pwm_8h.html#union_c_m_p_a___h_r_p_w_m___g_r_o_u_p", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a8ed704e5ae82c953760009c57c9d4942", null ],
      [ "half", "_d_s_p2803x___e_pwm_8h.html#a345359ce425c4ea7cb7b5b3b13dfb906", null ]
    ] ],
    [ "TBPRD_HRPWM_REG", "_d_s_p2803x___e_pwm_8h.html#struct_t_b_p_r_d___h_r_p_w_m___r_e_g", [
      [ "TBPRD", "_d_s_p2803x___e_pwm_8h.html#ab3980e08adbfb1985eba9d8af3c76bc7", null ],
      [ "TBPRDHR", "_d_s_p2803x___e_pwm_8h.html#afa83e6629c76e017bdaf627536a68a21", null ]
    ] ],
    [ "TBPRD_HRPWM_GROUP", "_d_s_p2803x___e_pwm_8h.html#union_t_b_p_r_d___h_r_p_w_m___g_r_o_u_p", [
      [ "all", "_d_s_p2803x___e_pwm_8h.html#a1b20f77e1829c6b3fd57152e2f9793d6", null ],
      [ "half", "_d_s_p2803x___e_pwm_8h.html#a3ef0e03064b44169c7c37ace929254a0", null ]
    ] ],
    [ "EPWM_REGS", "_d_s_p2803x___e_pwm_8h.html#struct_e_p_w_m___r_e_g_s", [
      [ "AQCSFRC", "_d_s_p2803x___e_pwm_8h.html#a72396e1c5f1dec68cda2da214766b8af", null ],
      [ "AQCTLA", "_d_s_p2803x___e_pwm_8h.html#ad62b625c7b2752962f3a2e2ab0f65976", null ],
      [ "AQCTLB", "_d_s_p2803x___e_pwm_8h.html#ac38b43b3052965958878810a3b82b192", null ],
      [ "AQSFRC", "_d_s_p2803x___e_pwm_8h.html#aaed317734280c0c7655016d6f4e0ec75", null ],
      [ "CMPA", "_d_s_p2803x___e_pwm_8h.html#adc0debd7084d4bf8955c18c0453a589e", null ],
      [ "CMPAM", "_d_s_p2803x___e_pwm_8h.html#ae5e7b14318d860403c8523066db1260c", null ],
      [ "CMPB", "_d_s_p2803x___e_pwm_8h.html#a38259b83d1f022159dfc124d1c037073", null ],
      [ "CMPCTL", "_d_s_p2803x___e_pwm_8h.html#a87596e57661f549e579285df591cc2fa", null ],
      [ "DBCTL", "_d_s_p2803x___e_pwm_8h.html#a9e10c95155ba8de962224b39f4bf93b6", null ],
      [ "DBFED", "_d_s_p2803x___e_pwm_8h.html#a0b5c959707b9eb0c393dd1cb5b5ec59a", null ],
      [ "DBRED", "_d_s_p2803x___e_pwm_8h.html#ae3625c046423d70b9e00ea782b2d4daf", null ],
      [ "DCACTL", "_d_s_p2803x___e_pwm_8h.html#a870714d0b6f5734d2457799dedc61441", null ],
      [ "DCBCTL", "_d_s_p2803x___e_pwm_8h.html#a342adef60a46d66a1f7b63c5b9dfe398", null ],
      [ "DCCAP", "_d_s_p2803x___e_pwm_8h.html#ac723f074c444fe199d3eb08b12de0ab6", null ],
      [ "DCCAPCTL", "_d_s_p2803x___e_pwm_8h.html#a0dd08ef15f4e10f79b69661cac7ff070", null ],
      [ "DCFCTL", "_d_s_p2803x___e_pwm_8h.html#a6ba2f9860e938cd5f6259251c5291047", null ],
      [ "DCFOFFSET", "_d_s_p2803x___e_pwm_8h.html#ac99596c28d5fc82b474064b2b43a81f4", null ],
      [ "DCFOFFSETCNT", "_d_s_p2803x___e_pwm_8h.html#a56a8bbaf9e6a77494df7cf1c75419f5c", null ],
      [ "DCFWINDOW", "_d_s_p2803x___e_pwm_8h.html#ab759c71a89ed4e713e6917475e205f7f", null ],
      [ "DCFWINDOWCNT", "_d_s_p2803x___e_pwm_8h.html#af2b8cd85b80d39c2025829474f053360", null ],
      [ "DCTRIPSEL", "_d_s_p2803x___e_pwm_8h.html#abd6e334829abb1c1d463cb3fe4120fd1", null ],
      [ "ETCLR", "_d_s_p2803x___e_pwm_8h.html#a7022fbbb508946105ef03222f8f68702", null ],
      [ "ETFLG", "_d_s_p2803x___e_pwm_8h.html#a3dcc373cd436c6be832e6d5a39a4e692", null ],
      [ "ETFRC", "_d_s_p2803x___e_pwm_8h.html#a2bade1e7c724464647f1fff9367da510", null ],
      [ "ETPS", "_d_s_p2803x___e_pwm_8h.html#a843058ba801bd7e4e70c3d108188f38d", null ],
      [ "ETSEL", "_d_s_p2803x___e_pwm_8h.html#a343a26c30e6b348bc564337d2c0c0167", null ],
      [ "HRCNFG", "_d_s_p2803x___e_pwm_8h.html#a47b54ccbf421930459b459554ea7a8bc", null ],
      [ "HRMSTEP", "_d_s_p2803x___e_pwm_8h.html#a1d315c8425dfa1121dbb7da753d049f6", null ],
      [ "HRPCTL", "_d_s_p2803x___e_pwm_8h.html#a81bcfc4627a86d4e26dfc48060e2a855", null ],
      [ "HRPWR", "_d_s_p2803x___e_pwm_8h.html#a1fceddd3663638eadbc736e808245453", null ],
      [ "PCCTL", "_d_s_p2803x___e_pwm_8h.html#a8a4aa48748d9cb44eb93ee9490314f81", null ],
      [ "rsvd3", "_d_s_p2803x___e_pwm_8h.html#a28a3dc27810a8a494796fb0c0f9f0383", null ],
      [ "rsvd4", "_d_s_p2803x___e_pwm_8h.html#a442238f26341f7234324e68eb18995f8", null ],
      [ "rsvd5", "_d_s_p2803x___e_pwm_8h.html#a9484b6b435cc7da42b5c9dc7efd6517f", null ],
      [ "rsvd6", "_d_s_p2803x___e_pwm_8h.html#ad8407a912e5f7f32a40776235468e60e", null ],
      [ "rsvd7", "_d_s_p2803x___e_pwm_8h.html#a39b6508cb09c22aa881ac276412f824c", null ],
      [ "rsvd8", "_d_s_p2803x___e_pwm_8h.html#a2841051889e7abf808b1db9094540def", null ],
      [ "TBCTL", "_d_s_p2803x___e_pwm_8h.html#ae1617d7e6a6b13c684b36758bc4d60c0", null ],
      [ "TBCTR", "_d_s_p2803x___e_pwm_8h.html#a0f0867569ad15a9158e341ab918fa6cf", null ],
      [ "TBPHS", "_d_s_p2803x___e_pwm_8h.html#a7aac82cf7a9320e1e1ee626a16d9f5b3", null ],
      [ "TBPRD", "_d_s_p2803x___e_pwm_8h.html#a6bfe710b9824c6ccf9925344a1db2709", null ],
      [ "TBPRDHR", "_d_s_p2803x___e_pwm_8h.html#a48c346864649b03edfbd8ab20f1dfd52", null ],
      [ "TBPRDM", "_d_s_p2803x___e_pwm_8h.html#a20639b324d9f2386a80b1853ee014a07", null ],
      [ "TBSTS", "_d_s_p2803x___e_pwm_8h.html#ae8e31651fc7f00f129c5c53a6579b7a5", null ],
      [ "TZCLR", "_d_s_p2803x___e_pwm_8h.html#a67e8b75caad0631d3c263a3cfd884a3c", null ],
      [ "TZCTL", "_d_s_p2803x___e_pwm_8h.html#a65fc11f25f4a8e966702dcacb6e81a13", null ],
      [ "TZDCSEL", "_d_s_p2803x___e_pwm_8h.html#a645e3c7c37b46083f29b9195364a5f99", null ],
      [ "TZEINT", "_d_s_p2803x___e_pwm_8h.html#a39cd5641cbb06b92e9647dadfdc60024", null ],
      [ "TZFLG", "_d_s_p2803x___e_pwm_8h.html#af209cbb6b99dbb580cf0fc8787bd18b9", null ],
      [ "TZFRC", "_d_s_p2803x___e_pwm_8h.html#accc1f186ccb71886f5d84c69c7421b35", null ],
      [ "TZSEL", "_d_s_p2803x___e_pwm_8h.html#a8cef159efb9754bf2471b656af814161", null ]
    ] ],
    [ "EPwm1Regs", "_d_s_p2803x___e_pwm_8h.html#aa3b0be383ff9cff1cbb133313ae0392f", null ],
    [ "EPwm2Regs", "_d_s_p2803x___e_pwm_8h.html#a84c8efe6ec79a67becdaa5e8140dfd86", null ],
    [ "EPwm3Regs", "_d_s_p2803x___e_pwm_8h.html#a9346ea78dc9a2c32a2fe2ab3088ee0b4", null ],
    [ "EPwm4Regs", "_d_s_p2803x___e_pwm_8h.html#a7ee89b97ecf04dc8aaf0d2056d3baeff", null ],
    [ "EPwm5Regs", "_d_s_p2803x___e_pwm_8h.html#aeaaba497a26b2753b29feeb2b207c92e", null ],
    [ "EPwm6Regs", "_d_s_p2803x___e_pwm_8h.html#a3f8cada6c30fd54e47509c3af72dfca6", null ],
    [ "EPwm7Regs", "_d_s_p2803x___e_pwm_8h.html#ade41dec16daad1ee415460a8ebfc107a", null ]
];