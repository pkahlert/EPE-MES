var _d_s_p2803x___boot_vars_8h =
[
    [ "EmuBMode", "_d_s_p2803x___boot_vars_8h.html#a56a17ee11cd4199552dbb8ec232e74bd", null ],
    [ "EmuKey", "_d_s_p2803x___boot_vars_8h.html#aa8f431b190b973dbfe20669bf6e6aca5", null ],
    [ "Flash_CallbackPtr", "_d_s_p2803x___boot_vars_8h.html#aabbb76d75f48b92e4955ea40ece775e3", null ],
    [ "Flash_CPUScaleFactor", "_d_s_p2803x___boot_vars_8h.html#ac065218e0d8b40bb6d98f49e00088210", null ]
];