var aci__fe__const_8h =
[
    [ "ACIFE_CONST", "aci__fe__const_8h.html#struct_a_c_i_f_e___c_o_n_s_t", [
      [ "Ib", "aci__fe__const_8h.html#ad4427f9e5f4482633fb45677e7bb4f98", null ],
      [ "K1", "aci__fe__const_8h.html#a872f327eabd431fd9f7aff6e058f1048", null ],
      [ "K2", "aci__fe__const_8h.html#affd32cf2cb054062474a1f832aec8ed7", null ],
      [ "K3", "aci__fe__const_8h.html#a7a1c955d6dd026646fbcb95f2772b754", null ],
      [ "K4", "aci__fe__const_8h.html#ab532449f828b87fcdb7a2354933d30aa", null ],
      [ "K5", "aci__fe__const_8h.html#ad0952c52ca05bb8dbd08d718b26a57b4", null ],
      [ "K6", "aci__fe__const_8h.html#a6190665efb0545ed4ad61158a31dbbeb", null ],
      [ "K7", "aci__fe__const_8h.html#af3e130e69cddebbf10f3f6770f726ab6", null ],
      [ "K8", "aci__fe__const_8h.html#a2f05ef57df28df9a2c38af024e914c73", null ],
      [ "Lm", "aci__fe__const_8h.html#a7a3257f5c000b187c77ab361d34e04d8", null ],
      [ "Lr", "aci__fe__const_8h.html#a3a16fea1d35779e80cc6aea6d5c83386", null ],
      [ "Ls", "aci__fe__const_8h.html#aab108869d1a333cbd38afccda0008b6d", null ],
      [ "Rr", "aci__fe__const_8h.html#ad17ec6d45e8f442488443b58f3e8353a", null ],
      [ "Rs", "aci__fe__const_8h.html#a6fcb9d99cdf2d8f7add89c301f67d10c", null ],
      [ "Tr", "aci__fe__const_8h.html#a384ffde7bc18ed8fd9c0c2c033f03b98", null ],
      [ "Ts", "aci__fe__const_8h.html#a0d87da27998cc09ed054c1632444ac91", null ],
      [ "Vb", "aci__fe__const_8h.html#a83199dbf2fd95a09fd207b4f1a2f632b", null ]
    ] ],
    [ "ACIFE_CONST_DEFAULTS", "aci__fe__const_8h.html#a1b220dbe20111e73f0fcc34a500a38a1", null ],
    [ "ACIFE_CONST_MACRO", "aci__fe__const_8h.html#ac049abc6ca9fadeb4a53ecd4f48c2790", null ]
];