var _d_s_p2803x___comp_8h =
[
    [ "COMPCTL_BITS", "_d_s_p2803x___comp_8h.html#struct_c_o_m_p_c_t_l___b_i_t_s", [
      [ "CMPINV", "_d_s_p2803x___comp_8h.html#ac559b41ea2e1ea5b0f6e33490edabf7a", null ],
      [ "COMPDACEN", "_d_s_p2803x___comp_8h.html#a99fd6f80041bf68783ed722cf368150f", null ],
      [ "COMPSOURCE", "_d_s_p2803x___comp_8h.html#a0bfa1cffbea0cfa79384311412ff85f2", null ],
      [ "QUALSEL", "_d_s_p2803x___comp_8h.html#abd55382f3e202b15cce95cf3a678416e", null ],
      [ "rsvd1", "_d_s_p2803x___comp_8h.html#aa54d5e8ceabdad0186db08c58282a0f0", null ],
      [ "SYNCSEL", "_d_s_p2803x___comp_8h.html#afc34331d26beb79c9b0886d4b794fa4e", null ]
    ] ],
    [ "COMPCTL_REG", "_d_s_p2803x___comp_8h.html#union_c_o_m_p_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___comp_8h.html#afb7178b2360c8b358d17676100787545", null ],
      [ "bit", "_d_s_p2803x___comp_8h.html#a6e4d3c130bf307e8faeb97c3010c20a4", null ]
    ] ],
    [ "COMPSTS_BITS", "_d_s_p2803x___comp_8h.html#struct_c_o_m_p_s_t_s___b_i_t_s", [
      [ "COMPSTS", "_d_s_p2803x___comp_8h.html#a85a7301b0210b7f5304fde286eec94e4", null ],
      [ "rsvd1", "_d_s_p2803x___comp_8h.html#a662bad9da1b1a884fccc6b268d061b2b", null ]
    ] ],
    [ "COMPSTS_REG", "_d_s_p2803x___comp_8h.html#union_c_o_m_p_s_t_s___r_e_g", [
      [ "all", "_d_s_p2803x___comp_8h.html#a89bb158f161cab563baf58d1fcf5d215", null ],
      [ "bit", "_d_s_p2803x___comp_8h.html#adb04273b15858de5804e464ff49a0416", null ]
    ] ],
    [ "DACCTL_BITS", "_d_s_p2803x___comp_8h.html#struct_d_a_c_c_t_l___b_i_t_s", [
      [ "DACSOURCE", "_d_s_p2803x___comp_8h.html#a50a55dd2c1e4d45ef5d8290340dfa351", null ],
      [ "FREE_SOFT", "_d_s_p2803x___comp_8h.html#a9084dd24c315c7d829493ed74b4966dd", null ],
      [ "RAMPSOURCE", "_d_s_p2803x___comp_8h.html#a89f905c51a565479717f4ed90a84a07c", null ],
      [ "rsvd1", "_d_s_p2803x___comp_8h.html#ab69fc243479fe0e8dd780baa135a0816", null ]
    ] ],
    [ "DACCTL_REG", "_d_s_p2803x___comp_8h.html#union_d_a_c_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___comp_8h.html#af3a54ba712aee1225af4cf104f4aff36", null ],
      [ "bit", "_d_s_p2803x___comp_8h.html#a4413e71b883861b929260e9b23f74131", null ]
    ] ],
    [ "DACVAL_BITS", "_d_s_p2803x___comp_8h.html#struct_d_a_c_v_a_l___b_i_t_s", [
      [ "DACVAL", "_d_s_p2803x___comp_8h.html#a91980585fdc48469b5c6646fb9dabd7e", null ],
      [ "rsvd1", "_d_s_p2803x___comp_8h.html#af804b46ad86d4ba7eafef5bbd3acf236", null ]
    ] ],
    [ "DACVAL_REG", "_d_s_p2803x___comp_8h.html#union_d_a_c_v_a_l___r_e_g", [
      [ "all", "_d_s_p2803x___comp_8h.html#ac780c5fde5f2d62a808a3d78b6e22130", null ],
      [ "bit", "_d_s_p2803x___comp_8h.html#a85c77276d335f02b7ff666a2a7252b79", null ]
    ] ],
    [ "COMP_REGS", "_d_s_p2803x___comp_8h.html#struct_c_o_m_p___r_e_g_s", [
      [ "COMPCTL", "_d_s_p2803x___comp_8h.html#a51928d7dac1af5f9a03b7a6619c0c37e", null ],
      [ "COMPSTS", "_d_s_p2803x___comp_8h.html#af9e71c8f7e619976362fb25b924eef59", null ],
      [ "DACCTL", "_d_s_p2803x___comp_8h.html#a55819585d31cfe923e9ff4a85e8df8bb", null ],
      [ "DACVAL", "_d_s_p2803x___comp_8h.html#aa2f010a91ee54b4e6fe7cc4bcaba12f8", null ],
      [ "RAMPDECVAL_ACTIVE", "_d_s_p2803x___comp_8h.html#a02ae6e0d9cdf3cc7072972da8fcf3703", null ],
      [ "RAMPDECVAL_SHDW", "_d_s_p2803x___comp_8h.html#a6deae295191c59e072099ac09bc95cdf", null ],
      [ "RAMPMAXREF_ACTIVE", "_d_s_p2803x___comp_8h.html#a9e1b559b9bc7f40b9f0b66f8de1c2f70", null ],
      [ "RAMPMAXREF_SHDW", "_d_s_p2803x___comp_8h.html#a1b2cc9a5ea4dfcd91d4e49c8a3d9b2cb", null ],
      [ "RAMPSTS", "_d_s_p2803x___comp_8h.html#a113e2957866856fc88038f6310a4111f", null ],
      [ "rsvd1", "_d_s_p2803x___comp_8h.html#a4294717fb78d5f3dcbf112e175a720df", null ],
      [ "rsvd2", "_d_s_p2803x___comp_8h.html#adb345f2153fab4a93f7b0bc20f7b415a", null ],
      [ "rsvd3", "_d_s_p2803x___comp_8h.html#a1982810156a6608cef37da32d40d13fa", null ],
      [ "rsvd4", "_d_s_p2803x___comp_8h.html#aa8f8485063a14ddecbab3026d5769cbb", null ],
      [ "rsvd5", "_d_s_p2803x___comp_8h.html#a43f8e7303cf944a8ed073b5e368bfd93", null ],
      [ "rsvd6", "_d_s_p2803x___comp_8h.html#aacbbd1b7db1e101cc01b5b2eda0ee99e", null ],
      [ "rsvd7", "_d_s_p2803x___comp_8h.html#ab48683021fcc2f56b3974a4bb6bea04e", null ],
      [ "rsvd8", "_d_s_p2803x___comp_8h.html#a101e3fcfd7606479e5b0a75e5c2e3e76", null ],
      [ "rsvd9", "_d_s_p2803x___comp_8h.html#a755b157aa0fd4189918bed3ae5724be8", null ]
    ] ],
    [ "Comp1Regs", "_d_s_p2803x___comp_8h.html#a5b4407ef620024ecbbcb78d147f5c225", null ],
    [ "Comp2Regs", "_d_s_p2803x___comp_8h.html#aae20affb2827af5e57d7a0f2a0b65eaf", null ],
    [ "Comp3Regs", "_d_s_p2803x___comp_8h.html#a3d291b97f34d35aa4d13d53fd2a49af7", null ]
];