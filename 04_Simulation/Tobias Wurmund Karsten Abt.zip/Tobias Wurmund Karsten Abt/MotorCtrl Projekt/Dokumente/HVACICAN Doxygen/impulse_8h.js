var impulse_8h =
[
    [ "IMPULSE", "impulse_8h.html#struct_i_m_p_u_l_s_e", [
      [ "Counter", "impulse_8h.html#af5aac1134ae9899d10e7b0fe8d63ccee", null ],
      [ "Out", "impulse_8h.html#a58d77231513bc3db918539f6dce9b38e", null ],
      [ "Period", "impulse_8h.html#a75b8e35ea78d8ba37fb291f3d8ac8616", null ]
    ] ],
    [ "IMPULSE_DEFAULTS", "impulse_8h.html#ac809565c38bad69cdecf95b30a43befa", null ],
    [ "IMPULSE_MACRO", "impulse_8h.html#a29b919e134d6837f9d6490afa25cdd87", null ]
];