var _d_s_p2803x___cla_8h =
[
    [ "MCTL_BITS", "_d_s_p2803x___cla_8h.html#struct_m_c_t_l___b_i_t_s", [
      [ "HARDRESET", "_d_s_p2803x___cla_8h.html#ad1b138040cbc1fdc2d80c4492cdf3598", null ],
      [ "IACKE", "_d_s_p2803x___cla_8h.html#ae2d5ddb2d494a3e44118dcf7d143e69d", null ],
      [ "rsvd1", "_d_s_p2803x___cla_8h.html#a49a6f629e5ab5fdd0ca673ea78193510", null ],
      [ "SOFTRESET", "_d_s_p2803x___cla_8h.html#a864a0dd365ac94b405b5bceffa2e232e", null ]
    ] ],
    [ "MCTL_REG", "_d_s_p2803x___cla_8h.html#union_m_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#a756d9e12026da309416aa4d44bf3b752", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#ac930c32246fb5607deb91a5fdf878e74", null ]
    ] ],
    [ "MMEMCFG_BITS", "_d_s_p2803x___cla_8h.html#struct_m_m_e_m_c_f_g___b_i_t_s", [
      [ "PROGE", "_d_s_p2803x___cla_8h.html#aac9fe8a79b1ed1d8dfcf667f57b7bd4e", null ],
      [ "RAM0E", "_d_s_p2803x___cla_8h.html#aeb01849478b5dd1cbe5c7fe9b0716e25", null ],
      [ "RAM1E", "_d_s_p2803x___cla_8h.html#ae01977253ef4cd33f901383c83a761e4", null ],
      [ "rsvd1", "_d_s_p2803x___cla_8h.html#a17be643a5a13250e0ed87401af526c1c", null ],
      [ "rsvd2", "_d_s_p2803x___cla_8h.html#a97aeddfe78c4396bc0729f5f44fddd10", null ]
    ] ],
    [ "MMEMCFG_REG", "_d_s_p2803x___cla_8h.html#union_m_m_e_m_c_f_g___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#acc5d7739f428f2c7708002250bbb879d", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#aa3eb1a3ee682eb7723d87c45e8e3ee8c", null ]
    ] ],
    [ "MPISRCSEL1_BITS", "_d_s_p2803x___cla_8h.html#struct_m_p_i_s_r_c_s_e_l1___b_i_t_s", [
      [ "PERINT1SEL", "_d_s_p2803x___cla_8h.html#a416dce27f613a9a3cac1d8530457e93e", null ],
      [ "PERINT2SEL", "_d_s_p2803x___cla_8h.html#aacd14e431ff8890458aa892a18127fb9", null ],
      [ "PERINT3SEL", "_d_s_p2803x___cla_8h.html#ad597a8f0baa79433900ce441435943f2", null ],
      [ "PERINT4SEL", "_d_s_p2803x___cla_8h.html#ace33945b7debb8697c0195f877850faf", null ],
      [ "PERINT5SEL", "_d_s_p2803x___cla_8h.html#a6f19964f557e2ad933f96b76090885be", null ],
      [ "PERINT6SEL", "_d_s_p2803x___cla_8h.html#a97f16b7aaa33307108ad0da1fe991462", null ],
      [ "PERINT7SEL", "_d_s_p2803x___cla_8h.html#a4d36deaf46a18ae6ed969cd52379b259", null ],
      [ "PERINT8SEL", "_d_s_p2803x___cla_8h.html#a30a512f74add66e16185136961affdc8", null ]
    ] ],
    [ "MPISRCSEL1_REG", "_d_s_p2803x___cla_8h.html#union_m_p_i_s_r_c_s_e_l1___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#a26361aac6ebbc4c9462745e4e834c08f", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#a1c0e1cac1809ed3ae7b17a63161df0b5", null ]
    ] ],
    [ "MIFR_BITS", "_d_s_p2803x___cla_8h.html#struct_m_i_f_r___b_i_t_s", [
      [ "INT1", "_d_s_p2803x___cla_8h.html#a569269e0500e3f5c15cb3d02757df948", null ],
      [ "INT2", "_d_s_p2803x___cla_8h.html#a7cfcdd1f80c2d3c5f2f9788c5c02e49f", null ],
      [ "INT3", "_d_s_p2803x___cla_8h.html#aaaf93989b54dbba41bc40a20395128f0", null ],
      [ "INT4", "_d_s_p2803x___cla_8h.html#ab5ee1136ed67f5ca7cd4f9ddbd411379", null ],
      [ "INT5", "_d_s_p2803x___cla_8h.html#a2235355d28fb6328ddb8b4f061a905d9", null ],
      [ "INT6", "_d_s_p2803x___cla_8h.html#af164d8166f87faea9135b6abb7f78224", null ],
      [ "INT7", "_d_s_p2803x___cla_8h.html#aa7f86e1f99c517cb985d74690c43abd5", null ],
      [ "INT8", "_d_s_p2803x___cla_8h.html#a1a97b7fdb6cd62ef69b040c4676e7842", null ],
      [ "rsvd", "_d_s_p2803x___cla_8h.html#af626fe141e35b8e50a387d91220986d7", null ]
    ] ],
    [ "MIFR_REG", "_d_s_p2803x___cla_8h.html#union_m_i_f_r___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#afbc11c3f24fc207af88d57aa7e1cddc7", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#a5a9dbadd6d7cb228cec91490ddae52f0", null ]
    ] ],
    [ "MIOVF_REG", "_d_s_p2803x___cla_8h.html#union_m_i_o_v_f___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#accc59c51cb099b9b340021da9087f1be", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#a96da2c7585dc7113e97a82af27df970c", null ]
    ] ],
    [ "MIFRC_REG", "_d_s_p2803x___cla_8h.html#union_m_i_f_r_c___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#a42134842856400355bbd3ef9dc587aad", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#ade7eb25dcc9ce08886f6758fe88a9191", null ]
    ] ],
    [ "MICLR_REG", "_d_s_p2803x___cla_8h.html#union_m_i_c_l_r___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#ab1e81d483ed4e67efc507ee90613fa7b", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#a507cd642c9e2c697d1f84e6b67aeb9c5", null ]
    ] ],
    [ "MICLROVF_REG", "_d_s_p2803x___cla_8h.html#union_m_i_c_l_r_o_v_f___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#aee863962b795fabca72631a970319dfb", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#a5122b5fb026d4c84f77bcc2db6bc4432", null ]
    ] ],
    [ "MIER_REG", "_d_s_p2803x___cla_8h.html#union_m_i_e_r___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#afbb0a4ac97932c88626e963592ed4971", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#a90df24ae113f3b5e4cca666a315ce45d", null ]
    ] ],
    [ "MIRUN_REG", "_d_s_p2803x___cla_8h.html#union_m_i_r_u_n___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#a20696cc1df2687774fdc149470b76b14", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#a7164fa82ab00a0e29bd5705ae4cdd8e3", null ]
    ] ],
    [ "MSTF_BITS", "_d_s_p2803x___cla_8h.html#struct_m_s_t_f___b_i_t_s", [
      [ "LUF", "_d_s_p2803x___cla_8h.html#ad3e908b01e3344f440b1ca6a3795a971", null ],
      [ "LVF", "_d_s_p2803x___cla_8h.html#ae102ea5ad89dc27f441aadd6bec522f0", null ],
      [ "MEALLOW", "_d_s_p2803x___cla_8h.html#a313b551c8326aebd781963bc638b5424", null ],
      [ "NF", "_d_s_p2803x___cla_8h.html#ac2155bb44590ec8fb1f6b98104e7b77d", null ],
      [ "RNDF32", "_d_s_p2803x___cla_8h.html#ad6f576ebd88205d9bd8ec1ee7663c0c1", null ],
      [ "RPCH", "_d_s_p2803x___cla_8h.html#a9f23179f0968b851ee20bec840286236", null ],
      [ "RPCL", "_d_s_p2803x___cla_8h.html#a4c85b468c1d0f8675a11e8be8acf0120", null ],
      [ "rsvd1", "_d_s_p2803x___cla_8h.html#a4a72542ad5acfdeb953c9dd6571e09f9", null ],
      [ "rsvd2", "_d_s_p2803x___cla_8h.html#ab72d6e18aa2dcf3ed7c36876fd3b7791", null ],
      [ "rsvd3", "_d_s_p2803x___cla_8h.html#a312c4345d114faf5e2731560b7444812", null ],
      [ "rsvd4", "_d_s_p2803x___cla_8h.html#a5e4aecf31b5a9714b71b29e0bfa60fb7", null ],
      [ "TF", "_d_s_p2803x___cla_8h.html#ac3aff379b9036fd263b049e317b471b1", null ],
      [ "ZF", "_d_s_p2803x___cla_8h.html#a0022ccd0a8024ddba97ae65a2b3c2c31", null ]
    ] ],
    [ "MSTF_REG", "_d_s_p2803x___cla_8h.html#union_m_s_t_f___r_e_g", [
      [ "all", "_d_s_p2803x___cla_8h.html#a53126903cc950bd324c790a4a3a41c43", null ],
      [ "bit", "_d_s_p2803x___cla_8h.html#a1a7b4ac999e3356680ccdf7bea2d173e", null ]
    ] ],
    [ "MR_REG", "_d_s_p2803x___cla_8h.html#union_m_r___r_e_g", [
      [ "f32", "_d_s_p2803x___cla_8h.html#a17d4de20c4557d5ace8c1bbba54d55be", null ],
      [ "i32", "_d_s_p2803x___cla_8h.html#a25d719360bc3d25d458bccb025996a2c", null ]
    ] ],
    [ "CLA_REGS", "_d_s_p2803x___cla_8h.html#struct_c_l_a___r_e_g_s", [
      [ "_MAR0", "_d_s_p2803x___cla_8h.html#a87266f3331d3d7a925ba9b453993a630", null ],
      [ "_MAR1", "_d_s_p2803x___cla_8h.html#ab8da9360c792e2e41e4ba6829f933f79", null ],
      [ "_MPC", "_d_s_p2803x___cla_8h.html#a6c578cb3e115fb1c6da98899ce44e719", null ],
      [ "_MR0", "_d_s_p2803x___cla_8h.html#a5dfa4aff688c2322fbcc24ca4f350a0e", null ],
      [ "_MR1", "_d_s_p2803x___cla_8h.html#a66eecb3b48f8b2dd375d2a0cb7a99b9b", null ],
      [ "_MR2", "_d_s_p2803x___cla_8h.html#a91a5256b69dad2f8d8ba8f9cfccdb82d", null ],
      [ "_MR3", "_d_s_p2803x___cla_8h.html#a203e407e1c0e3be46f683ac39a4009d4", null ],
      [ "_MSTF", "_d_s_p2803x___cla_8h.html#af346ad2b35b12589506dd88717a2de28", null ],
      [ "MCTL", "_d_s_p2803x___cla_8h.html#ad6f9e33667709f0dc3c3d40dce7e4605", null ],
      [ "MICLR", "_d_s_p2803x___cla_8h.html#addebc411a35e0ee3cf26f3ce5dd72352", null ],
      [ "MICLROVF", "_d_s_p2803x___cla_8h.html#af50480223c812f90ea380ac43a0aa9ad", null ],
      [ "MIER", "_d_s_p2803x___cla_8h.html#af489cf27255cda4fc3a5ae3d2de159eb", null ],
      [ "MIFR", "_d_s_p2803x___cla_8h.html#ab7d190a2f959cfe0ed47ffba54110a7c", null ],
      [ "MIFRC", "_d_s_p2803x___cla_8h.html#a059985b51c302a5b727ff07832f6a0de", null ],
      [ "MIOVF", "_d_s_p2803x___cla_8h.html#af287506c8fe852e23c8a32f86072e013", null ],
      [ "MIRUN", "_d_s_p2803x___cla_8h.html#a6c4136fb34f2d8a14d7a2deed12b185f", null ],
      [ "MMEMCFG", "_d_s_p2803x___cla_8h.html#a4bd02320aceb6a81fa487b05d3219cb2", null ],
      [ "MPISRCSEL1", "_d_s_p2803x___cla_8h.html#a169c71949a37df5e3d7775f16b207728", null ],
      [ "MVECT1", "_d_s_p2803x___cla_8h.html#a30ca7eb075e5ab30ced697b15332267a", null ],
      [ "MVECT2", "_d_s_p2803x___cla_8h.html#a07f10cf13307ad4e8a0065e62389a22d", null ],
      [ "MVECT3", "_d_s_p2803x___cla_8h.html#a567307febb6c039639f6001be8ef7dea", null ],
      [ "MVECT4", "_d_s_p2803x___cla_8h.html#ad5f2dc9e5f5290faedada3caeefd53e2", null ],
      [ "MVECT5", "_d_s_p2803x___cla_8h.html#ad71c116ce6b32582f4567ed61aeab0c0", null ],
      [ "MVECT6", "_d_s_p2803x___cla_8h.html#ae851929565d964593aa547bca54a4203", null ],
      [ "MVECT7", "_d_s_p2803x___cla_8h.html#ad7e9f7a862151441d126be42d8d819a9", null ],
      [ "MVECT8", "_d_s_p2803x___cla_8h.html#ac614d7aaffcbdce822234cfdcf2cfc28", null ],
      [ "rsvd1", "_d_s_p2803x___cla_8h.html#aeb89188a2ed67859c2283f6e41eaac90", null ],
      [ "rsvd10", "_d_s_p2803x___cla_8h.html#a03e126b24a49a71ef69b644755cf856e", null ],
      [ "rsvd2", "_d_s_p2803x___cla_8h.html#ae45503fb426204a78113e8f7f8cf8af3", null ],
      [ "rsvd3", "_d_s_p2803x___cla_8h.html#a1ab76a39d3b56c3e8414bf64c2da09bf", null ],
      [ "rsvd4", "_d_s_p2803x___cla_8h.html#aeaebd29aea44ccd688b0b7baaeb5b0c9", null ],
      [ "rsvd5", "_d_s_p2803x___cla_8h.html#ab882efa48b65013d9c3eccfa45fd8851", null ],
      [ "rsvd6", "_d_s_p2803x___cla_8h.html#af16cf893d7a80740d89c39ec0975a5ec", null ],
      [ "rsvd7", "_d_s_p2803x___cla_8h.html#a8bb30d90cd83c399027ad912ca450b67", null ],
      [ "rsvd8", "_d_s_p2803x___cla_8h.html#a972971f1ef69cd958ea0306b224fb3a2", null ],
      [ "rsvd9", "_d_s_p2803x___cla_8h.html#ad266963700bb05a401de4a6ebbdd368a", null ]
    ] ],
    [ "Cla1Regs", "_d_s_p2803x___cla_8h.html#a42bf1549870cbc71155bbe0f051f90cc", null ]
];