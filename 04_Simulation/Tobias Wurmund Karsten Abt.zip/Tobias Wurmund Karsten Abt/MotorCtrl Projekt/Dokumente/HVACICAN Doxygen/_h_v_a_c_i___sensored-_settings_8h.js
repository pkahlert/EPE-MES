var _h_v_a_c_i___sensored__settings_8h =
[
    [ "BASE_CURRENT", "_h_v_a_c_i___sensored-_settings_8h.html#afc893d564edbb0df5cf48a16dc590731", null ],
    [ "BASE_FLUX", "_h_v_a_c_i___sensored-_settings_8h.html#ab1fcde9f64afad50449179e920b45c82", null ],
    [ "BASE_FREQ", "_h_v_a_c_i___sensored-_settings_8h.html#a25cc638ebb9c29f5ea0a545454c50d31", null ],
    [ "BASE_TORQUE", "_h_v_a_c_i___sensored-_settings_8h.html#ae69402205d2263a8d056ad6a2fb325bd", null ],
    [ "BASE_VOLTAGE", "_h_v_a_c_i___sensored-_settings_8h.html#ac52cafff2e1561faf679cf74f2e8ca81", null ],
    [ "BUILDLEVEL", "_h_v_a_c_i___sensored-_settings_8h.html#a45dbcff8c235a721b5233a199830b02f", null ],
    [ "FALSE", "_h_v_a_c_i___sensored-_settings_8h.html#aa93f0eb578d23995850d61f7d61c55c1", null ],
    [ "ISR_FREQUENCY", "_h_v_a_c_i___sensored-_settings_8h.html#acf2f82424460c440bca0100c55df3871", null ],
    [ "LEVEL1", "_h_v_a_c_i___sensored-_settings_8h.html#a5e9640caa69c07b36781350d230585dc", null ],
    [ "LEVEL2", "_h_v_a_c_i___sensored-_settings_8h.html#af03882265163ca6bf97fe86f8fac9044", null ],
    [ "LEVEL3", "_h_v_a_c_i___sensored-_settings_8h.html#a4069806736a5968f80274abd9214c9bb", null ],
    [ "LEVEL4", "_h_v_a_c_i___sensored-_settings_8h.html#ab870bbdbfa3927990efc5233a8a33cc8", null ],
    [ "LEVEL5", "_h_v_a_c_i___sensored-_settings_8h.html#a2119af43d75978f7c6dd937d4f29d26c", null ],
    [ "LM", "_h_v_a_c_i___sensored-_settings_8h.html#a4b3e3200940ab78533ae2126430fe840", null ],
    [ "LR", "_h_v_a_c_i___sensored-_settings_8h.html#a3572ba4e929ec4380493fcfbbde0efa2", null ],
    [ "LS", "_h_v_a_c_i___sensored-_settings_8h.html#aeb0ce037090c628feafc65349031b214", null ],
    [ "PI", "_h_v_a_c_i___sensored-_settings_8h.html#a598a3330b3c21701223ee0ca14316eca", null ],
    [ "POLES", "_h_v_a_c_i___sensored-_settings_8h.html#a433e4df5f948e218d6f9e33750b23126", null ],
    [ "RR", "_h_v_a_c_i___sensored-_settings_8h.html#a63979cf6054f403eab1d354e6dcc4ce9", null ],
    [ "RS", "_h_v_a_c_i___sensored-_settings_8h.html#af8903d8eea3868940c60af887473b152", null ],
    [ "TRUE", "_h_v_a_c_i___sensored-_settings_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d", null ]
];