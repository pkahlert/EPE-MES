var _d_s_p2803x___nmi_intrupt_8h =
[
    [ "NMICFG_BITS", "_d_s_p2803x___nmi_intrupt_8h.html#struct_n_m_i_c_f_g___b_i_t_s", [
      [ "CLOCKFAIL", "_d_s_p2803x___nmi_intrupt_8h.html#aafb49c3fdbcef9bf519582b31e712595", null ],
      [ "rsvd1", "_d_s_p2803x___nmi_intrupt_8h.html#a27574fd236bcacaf9dda70dea8bd266c", null ],
      [ "rsvd2", "_d_s_p2803x___nmi_intrupt_8h.html#a3f4f7cdcd7fc672c063313ee9bb62d6e", null ]
    ] ],
    [ "NMICFG_REG", "_d_s_p2803x___nmi_intrupt_8h.html#union_n_m_i_c_f_g___r_e_g", [
      [ "all", "_d_s_p2803x___nmi_intrupt_8h.html#aa513a234c422727e831e0e3a1be35302", null ],
      [ "bit", "_d_s_p2803x___nmi_intrupt_8h.html#a3b10497315aa24d08f493a34f9364c11", null ]
    ] ],
    [ "NMIFLG_BITS", "_d_s_p2803x___nmi_intrupt_8h.html#struct_n_m_i_f_l_g___b_i_t_s", [
      [ "CLOCKFAIL", "_d_s_p2803x___nmi_intrupt_8h.html#ae34230831300ae13a3abeab53674a393", null ],
      [ "NMIINT", "_d_s_p2803x___nmi_intrupt_8h.html#ac3b64b15a3245de9e53a4471d26d447e", null ],
      [ "rsvd1", "_d_s_p2803x___nmi_intrupt_8h.html#ad0afbed70b49a58361b184dac09ab3f9", null ]
    ] ],
    [ "NMIFLG_REG", "_d_s_p2803x___nmi_intrupt_8h.html#union_n_m_i_f_l_g___r_e_g", [
      [ "all", "_d_s_p2803x___nmi_intrupt_8h.html#a5a37df9af0cf3ba3703f0e43680a26b5", null ],
      [ "bit", "_d_s_p2803x___nmi_intrupt_8h.html#a9b14c5a0ba5c113915a287b853dabb4e", null ]
    ] ],
    [ "NMIFLGCLR_BITS", "_d_s_p2803x___nmi_intrupt_8h.html#struct_n_m_i_f_l_g_c_l_r___b_i_t_s", [
      [ "CLOCKFAIL", "_d_s_p2803x___nmi_intrupt_8h.html#abbe2409cca0508781b6b246a442b7e7d", null ],
      [ "NMIINT", "_d_s_p2803x___nmi_intrupt_8h.html#adeb624aff785288c4452c2508e0cae93", null ],
      [ "rsvd1", "_d_s_p2803x___nmi_intrupt_8h.html#a98d224c67b0c7897ef563ff9738568c9", null ]
    ] ],
    [ "NMIFLGCLR_REG", "_d_s_p2803x___nmi_intrupt_8h.html#union_n_m_i_f_l_g_c_l_r___r_e_g", [
      [ "all", "_d_s_p2803x___nmi_intrupt_8h.html#ad02327b1a34e34ec9969b0896c69ac47", null ],
      [ "bit", "_d_s_p2803x___nmi_intrupt_8h.html#a5f31f341a28f119e509283af1a00ccfe", null ]
    ] ],
    [ "NMIFLGFRC_BITS", "_d_s_p2803x___nmi_intrupt_8h.html#struct_n_m_i_f_l_g_f_r_c___b_i_t_s", [
      [ "CLOCKFAIL", "_d_s_p2803x___nmi_intrupt_8h.html#a7d1db00569fa2d9427e05d907eda3ca4", null ],
      [ "rsvd1", "_d_s_p2803x___nmi_intrupt_8h.html#aa4c27ea53a687a26d13db319e09826a7", null ],
      [ "rsvd2", "_d_s_p2803x___nmi_intrupt_8h.html#a39b7d433c7d9622b133c94cbe446e1c3", null ]
    ] ],
    [ "NMIFLGFRC_REG", "_d_s_p2803x___nmi_intrupt_8h.html#union_n_m_i_f_l_g_f_r_c___r_e_g", [
      [ "all", "_d_s_p2803x___nmi_intrupt_8h.html#a7a67b9241dffa5d304138613ac653c45", null ],
      [ "bit", "_d_s_p2803x___nmi_intrupt_8h.html#afb935e00a0c5c1c8284e06f446ad0320", null ]
    ] ],
    [ "NMIINTRUPT_REGS", "_d_s_p2803x___nmi_intrupt_8h.html#struct_n_m_i_i_n_t_r_u_p_t___r_e_g_s", [
      [ "NMICFG", "_d_s_p2803x___nmi_intrupt_8h.html#abc9dd0c04cd11d276c8c9704d326481c", null ],
      [ "NMIFLG", "_d_s_p2803x___nmi_intrupt_8h.html#a0581b6d0a86b55145b75265b66993a5d", null ],
      [ "NMIFLGCLR", "_d_s_p2803x___nmi_intrupt_8h.html#a6aaa3b3eff10e3cc005c4aac3cb6126d", null ],
      [ "NMIFLGFRC", "_d_s_p2803x___nmi_intrupt_8h.html#a40f27cb78615b0885622b6161848a39e", null ],
      [ "NMIWDCNT", "_d_s_p2803x___nmi_intrupt_8h.html#ae68c5138113c8c1fec07725434d2fb58", null ],
      [ "NMIWDPRD", "_d_s_p2803x___nmi_intrupt_8h.html#ac8e6de963f00665b578522d420f8a603", null ],
      [ "rsvd1", "_d_s_p2803x___nmi_intrupt_8h.html#afbc82d491a2dd50a169be00eee2af484", null ]
    ] ],
    [ "NmiIntruptRegs", "_d_s_p2803x___nmi_intrupt_8h.html#a7fb5c2dd1ed47667d38e61390494f007", null ]
];