var rmp2cntl_8h =
[
    [ "RMP2", "rmp2cntl_8h.html#struct_r_m_p2", [
      [ "DesiredInput", "rmp2cntl_8h.html#aa594feea0aff3f6d3f57fe803b7251b7", null ],
      [ "Out", "rmp2cntl_8h.html#aff68f361a980942d0e868320b3cea925", null ],
      [ "Ramp2Delay", "rmp2cntl_8h.html#a252340d7d86a9c06d9b800d5baa14fd3", null ],
      [ "Ramp2DelayCount", "rmp2cntl_8h.html#a71d19376a67a2e84b721f43674e8dc3d", null ],
      [ "Ramp2Max", "rmp2cntl_8h.html#a1d9d6f7fdcdda4a10943a592158ff060", null ],
      [ "Ramp2Min", "rmp2cntl_8h.html#a4816ebf2c120b1dd184880fa18e66127", null ]
    ] ],
    [ "RC2_MACRO", "rmp2cntl_8h.html#a800a0695a0e51c72b130ccc3a7177556", null ],
    [ "RMP2_DEFAULTS", "rmp2cntl_8h.html#a1a7153e348026b1e72580bce56b4e453", null ]
];