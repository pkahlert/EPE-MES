var aci__se__const_8h =
[
    [ "ACISE_CONST", "aci__se__const_8h.html#struct_a_c_i_s_e___c_o_n_s_t", [
      [ "fb", "aci__se__const_8h.html#ac4a09398356237c6519d0070be95a3a3", null ],
      [ "fc", "aci__se__const_8h.html#a48ae805840fbbe9d1bc079a4a2567f31", null ],
      [ "K1", "aci__se__const_8h.html#a6f207b986de8ab1a09d41c2368c2f260", null ],
      [ "K2", "aci__se__const_8h.html#a4163caa5e1d3ffc92674f4537885fbeb", null ],
      [ "K3", "aci__se__const_8h.html#ad3b01530c81392b122a379b50c7eeb3c", null ],
      [ "K4", "aci__se__const_8h.html#a23f488ceeaf3d4931f15bfb67cde042a", null ],
      [ "Lr", "aci__se__const_8h.html#ac6e31ac5e000d5f1fd9641949a50822a", null ],
      [ "Rr", "aci__se__const_8h.html#a13989cb4b62d84d6c0b73c284a8d79d8", null ],
      [ "Tc", "aci__se__const_8h.html#a8ffc0e6324189d5c5085122e338d2407", null ],
      [ "Tr", "aci__se__const_8h.html#aef2d05555e5708add0e6c4f5b074f00c", null ],
      [ "Ts", "aci__se__const_8h.html#a00403aa7b31178c53c55293a930e529e", null ],
      [ "Wb", "aci__se__const_8h.html#a751a234405dffdbafff51f84a5c6ee62", null ]
    ] ],
    [ "ACISE_CONST_DEFAULTS", "aci__se__const_8h.html#af21829de18c2c738fc2dc3c547b2eabe", null ],
    [ "ACISE_CONST_MACRO", "aci__se__const_8h.html#a9ae2bb82cf8feb05b5b3ba8b2a3f92cd", null ],
    [ "PI", "aci__se__const_8h.html#a598a3330b3c21701223ee0ca14316eca", null ]
];