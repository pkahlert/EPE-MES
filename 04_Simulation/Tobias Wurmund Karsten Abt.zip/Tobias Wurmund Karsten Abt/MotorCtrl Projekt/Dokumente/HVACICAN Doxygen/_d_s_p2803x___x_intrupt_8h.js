var _d_s_p2803x___x_intrupt_8h =
[
    [ "XINTCR_BITS", "_d_s_p2803x___x_intrupt_8h.html#struct_x_i_n_t_c_r___b_i_t_s", [
      [ "ENABLE", "_d_s_p2803x___x_intrupt_8h.html#a1e4efc3d35bf309773352bb2f2094e97", null ],
      [ "POLARITY", "_d_s_p2803x___x_intrupt_8h.html#a0b683dacb511ed51c22ddaafa0dd12ee", null ],
      [ "rsvd1", "_d_s_p2803x___x_intrupt_8h.html#a85870488d60516a6bd242b5e80971a6d", null ],
      [ "rsvd2", "_d_s_p2803x___x_intrupt_8h.html#a0373fa06b091a2850a355563eb567f93", null ]
    ] ],
    [ "XINTCR_REG", "_d_s_p2803x___x_intrupt_8h.html#union_x_i_n_t_c_r___r_e_g", [
      [ "all", "_d_s_p2803x___x_intrupt_8h.html#a99628de7ce0ada67ae89ca8d545f84bb", null ],
      [ "bit", "_d_s_p2803x___x_intrupt_8h.html#a2cf66cd7b64e9205c5e06e437d53b564", null ]
    ] ],
    [ "XINTRUPT_REGS", "_d_s_p2803x___x_intrupt_8h.html#struct_x_i_n_t_r_u_p_t___r_e_g_s", [
      [ "rsvd", "_d_s_p2803x___x_intrupt_8h.html#a980ebe4044d4d16c08e3eff79983942b", null ],
      [ "rsvd1", "_d_s_p2803x___x_intrupt_8h.html#aa65cd0f970d9541fbacef47889b3e640", null ],
      [ "XINT1CR", "_d_s_p2803x___x_intrupt_8h.html#aa85211e0c7071a04f109a8b2a59cd6b9", null ],
      [ "XINT1CTR", "_d_s_p2803x___x_intrupt_8h.html#acf45853f0b1c1f802bc9405d86ce07e5", null ],
      [ "XINT2CR", "_d_s_p2803x___x_intrupt_8h.html#a5c10f5f790ca40b9a1b9e8e27f2a146e", null ],
      [ "XINT2CTR", "_d_s_p2803x___x_intrupt_8h.html#a14019907a432e09a5198689197499b5c", null ],
      [ "XINT3CR", "_d_s_p2803x___x_intrupt_8h.html#a1cd55e0692caadd19dee0d091748afa4", null ],
      [ "XINT3CTR", "_d_s_p2803x___x_intrupt_8h.html#a33f8a5159a92848c16110b53c0255a91", null ]
    ] ],
    [ "XIntruptRegs", "_d_s_p2803x___x_intrupt_8h.html#a42668d2361079c80249c164ea157d46e", null ]
];