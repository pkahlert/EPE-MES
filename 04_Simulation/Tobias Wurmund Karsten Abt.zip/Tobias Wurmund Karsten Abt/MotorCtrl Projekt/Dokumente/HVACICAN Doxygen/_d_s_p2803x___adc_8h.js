var _d_s_p2803x___adc_8h =
[
    [ "ADCCTL1_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_c_t_l1___b_i_t_s", [
      [ "ADCBGPWD", "_d_s_p2803x___adc_8h.html#ad3d21622c8beaf1e262373af8e199037", null ],
      [ "ADCBSY", "_d_s_p2803x___adc_8h.html#a1f7a2092c947b66ac815551aecd24f97", null ],
      [ "ADCBSYCHN", "_d_s_p2803x___adc_8h.html#a54987bee85b8390358031b779d6880f9", null ],
      [ "ADCENABLE", "_d_s_p2803x___adc_8h.html#a234d751262ac01a676cf2f081f7d4e69", null ],
      [ "ADCPWDN", "_d_s_p2803x___adc_8h.html#aac97be22fbfd9b8b01067f984ca6bbde", null ],
      [ "ADCREFPWD", "_d_s_p2803x___adc_8h.html#a113c598d6cfcc22157506892481d357d", null ],
      [ "ADCREFSEL", "_d_s_p2803x___adc_8h.html#a7f3d1e5e454dc27e080a7ff825f5b890", null ],
      [ "INTPULSEPOS", "_d_s_p2803x___adc_8h.html#acc3c68bce54fcececbd0e87a340a3895", null ],
      [ "RESET", "_d_s_p2803x___adc_8h.html#adc33018aca7899230a3e5dc79e99a4a9", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#a13ff0ab8c0527617facff78b3089cbad", null ],
      [ "TEMPCONV", "_d_s_p2803x___adc_8h.html#a3fb56694a515b9069fa35d0cfab5c459", null ],
      [ "VREFLOCONV", "_d_s_p2803x___adc_8h.html#a09b1cd763957b7403a2a10552aef9680", null ]
    ] ],
    [ "ADCCTL1_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_c_t_l1___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#ab7e9120e007a07d8ee2ecf6d682dc2f0", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#ad181110c9e07faae8a3334923171ed01", null ]
    ] ],
    [ "ADCCTL2_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_c_t_l2___b_i_t_s", [
      [ "ADCNONOVERLAP", "_d_s_p2803x___adc_8h.html#a98cf95512403db0eeacc15c5fc0d7bc5", null ],
      [ "CLKDIV2EN", "_d_s_p2803x___adc_8h.html#a12c044805ad1ae898aab5c3f32bbcd54", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#a1ca7630b1d859ea9b1ce2a9d171550f8", null ]
    ] ],
    [ "ADCCTL2_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_c_t_l2___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#a1ed6241dd0ee6b9743480b13d3fe1eaf", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a68f57059e642c282110acddb0a2a4413", null ]
    ] ],
    [ "ADCINT_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_i_n_t___b_i_t_s", [
      [ "ADCINT1", "_d_s_p2803x___adc_8h.html#a45b6fb1b55a74d6cba9e9c95c208efcd", null ],
      [ "ADCINT2", "_d_s_p2803x___adc_8h.html#a557a07c03cd73fbe4a538b3e118a2607", null ],
      [ "ADCINT3", "_d_s_p2803x___adc_8h.html#a49b67259062f00f4a63ad80e86a08e6b", null ],
      [ "ADCINT4", "_d_s_p2803x___adc_8h.html#ac5123f72dc738926d14cd304b2042b9b", null ],
      [ "ADCINT5", "_d_s_p2803x___adc_8h.html#aa6a636d1603fc2dda5d66df8eb23610a", null ],
      [ "ADCINT6", "_d_s_p2803x___adc_8h.html#afef9ccfd3941a58c071b86afdb63f629", null ],
      [ "ADCINT7", "_d_s_p2803x___adc_8h.html#a61a396e88b443468df197bfa8f26db32", null ],
      [ "ADCINT8", "_d_s_p2803x___adc_8h.html#a2185e561d175d7a42aee4e35eebf1b8b", null ],
      [ "ADCINT9", "_d_s_p2803x___adc_8h.html#a48432b16df3c6409cbe7c8fb10a4461a", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#abfcf4a53b120dfb4cd5f18db7c98d93f", null ]
    ] ],
    [ "ADCINT_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_i_n_t___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#af0774181c84e1337fef0bc8946bd2a1e", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#ab6fa4b93d72a82ada83a650880e9b144", null ]
    ] ],
    [ "INTSEL1N2_BITS", "_d_s_p2803x___adc_8h.html#struct_i_n_t_s_e_l1_n2___b_i_t_s", [
      [ "INT1CONT", "_d_s_p2803x___adc_8h.html#af0b261eca8f98ee372be755e95130df5", null ],
      [ "INT1E", "_d_s_p2803x___adc_8h.html#ab17f6f6abae5fb3fabe0bdb12f40c5e5", null ],
      [ "INT1SEL", "_d_s_p2803x___adc_8h.html#af9b0c4e4200739a6672a513b20880dfe", null ],
      [ "INT2CONT", "_d_s_p2803x___adc_8h.html#a62cd10643914eabc3cbb9674d446449a", null ],
      [ "INT2E", "_d_s_p2803x___adc_8h.html#a660c6deaef33c44e1c50817fd90545c8", null ],
      [ "INT2SEL", "_d_s_p2803x___adc_8h.html#a2da8308845667a77f49e18d3c839df4d", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#ac7d81e5634448fa4ba9730751ddf70d3", null ],
      [ "rsvd2", "_d_s_p2803x___adc_8h.html#a72bf9e660c55ad8aa7f12eb8248d3b7d", null ]
    ] ],
    [ "INTSEL1N2_REG", "_d_s_p2803x___adc_8h.html#union_i_n_t_s_e_l1_n2___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#afcc61f36e8fe1abe9d8506274426f648", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a96d51c3cd49329873815e213ce7c45a4", null ]
    ] ],
    [ "INTSEL3N4_BITS", "_d_s_p2803x___adc_8h.html#struct_i_n_t_s_e_l3_n4___b_i_t_s", [
      [ "INT3CONT", "_d_s_p2803x___adc_8h.html#ab72abdcb0f4baf6aeccdd851cfd2aade", null ],
      [ "INT3E", "_d_s_p2803x___adc_8h.html#a3df9b57fd643fda4bca3a1f7c5917d04", null ],
      [ "INT3SEL", "_d_s_p2803x___adc_8h.html#a5b655214cd26aeca163019538ae19f62", null ],
      [ "INT4CONT", "_d_s_p2803x___adc_8h.html#aba65360c244438ec4ebfe5e5861cda09", null ],
      [ "INT4E", "_d_s_p2803x___adc_8h.html#acae79f22621461a3220febe777de8952", null ],
      [ "INT4SEL", "_d_s_p2803x___adc_8h.html#a32a937d0f2828c093dc20c55ff3ed331", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#aa3bbe31ec3158165b79020092ae5d9bc", null ],
      [ "rsvd2", "_d_s_p2803x___adc_8h.html#a1abc9c06aaf7fe5ca641ee7287841f12", null ]
    ] ],
    [ "INTSEL3N4_REG", "_d_s_p2803x___adc_8h.html#union_i_n_t_s_e_l3_n4___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#a5462d493246f5f2e06d49f133da55514", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a30060419c9e181d4e1ba026b88d0bb32", null ]
    ] ],
    [ "INTSEL5N6_BITS", "_d_s_p2803x___adc_8h.html#struct_i_n_t_s_e_l5_n6___b_i_t_s", [
      [ "INT5CONT", "_d_s_p2803x___adc_8h.html#a0ea76b61bf355e693d73a246c9e74776", null ],
      [ "INT5E", "_d_s_p2803x___adc_8h.html#ae0f98f89f31c9e006557e27097c6c063", null ],
      [ "INT5SEL", "_d_s_p2803x___adc_8h.html#afc704c0a347d5fa321abebb6242d2a2b", null ],
      [ "INT6CONT", "_d_s_p2803x___adc_8h.html#a63cb57edf6feaff24292c3d52ebece49", null ],
      [ "INT6E", "_d_s_p2803x___adc_8h.html#ab8f24581040754363a93605cb58ca488", null ],
      [ "INT6SEL", "_d_s_p2803x___adc_8h.html#a2ad48543db3ce6f4a70d6a17dc0090ff", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#ac425ff09f74ece843c0577c1475e509f", null ],
      [ "rsvd2", "_d_s_p2803x___adc_8h.html#acef0ebc5ab7989a1428d180ccf927e7f", null ]
    ] ],
    [ "INTSEL5N6_REG", "_d_s_p2803x___adc_8h.html#union_i_n_t_s_e_l5_n6___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#aa4495e6a0f57e78389b357d72dde3525", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a010a49a63bee56a7fe3fb3149b1c324d", null ]
    ] ],
    [ "INTSEL7N8_BITS", "_d_s_p2803x___adc_8h.html#struct_i_n_t_s_e_l7_n8___b_i_t_s", [
      [ "INT7CONT", "_d_s_p2803x___adc_8h.html#a06c4c67ef957e6e2dac97f39475a0257", null ],
      [ "INT7E", "_d_s_p2803x___adc_8h.html#af9f5073e4619d3322fc71e1def9d4946", null ],
      [ "INT7SEL", "_d_s_p2803x___adc_8h.html#a7670c2943183a48a1764f9af48700d75", null ],
      [ "INT8CONT", "_d_s_p2803x___adc_8h.html#a116260fc5fd7c32b1cf23f574975b008", null ],
      [ "INT8E", "_d_s_p2803x___adc_8h.html#acf83fa89cd5b401dc79d7c5255e2f0ef", null ],
      [ "INT8SEL", "_d_s_p2803x___adc_8h.html#ae8e4baf8b0fe117c8b8eefb08f4d30b1", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#ad98e4b770eeef51c66f5275f366413fe", null ],
      [ "rsvd2", "_d_s_p2803x___adc_8h.html#ac0cbf377ac0d9ba3b8fd2dbaf03018ac", null ]
    ] ],
    [ "INTSEL7N8_REG", "_d_s_p2803x___adc_8h.html#union_i_n_t_s_e_l7_n8___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#a0b66b4c6302fddee81cf0f280914fdbc", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#ac1b28328f60f749b86c7ee990492ee45", null ]
    ] ],
    [ "INTSEL9N10_BITS", "_d_s_p2803x___adc_8h.html#struct_i_n_t_s_e_l9_n10___b_i_t_s", [
      [ "INT10CONT", "_d_s_p2803x___adc_8h.html#a85dc1eb80843b1f1a41d7b86761689c5", null ],
      [ "INT10E", "_d_s_p2803x___adc_8h.html#abd2add767b59eff89779632d550d2b26", null ],
      [ "INT10SEL", "_d_s_p2803x___adc_8h.html#a2c37afa375f993504cb58773a5420d05", null ],
      [ "INT9CONT", "_d_s_p2803x___adc_8h.html#a137a07a00f099b4f2bfb7b1bc0a24302", null ],
      [ "INT9E", "_d_s_p2803x___adc_8h.html#a2ff937acba88086787957b2a8c3f47ff", null ],
      [ "INT9SEL", "_d_s_p2803x___adc_8h.html#a0a8c5730a37ce0f09fc36bec125f5696", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#a609c69a10f72f8f80e3e59b49c966143", null ],
      [ "rsvd2", "_d_s_p2803x___adc_8h.html#a775d7e211281c7647891965cd11f981d", null ]
    ] ],
    [ "INTSEL9N10_REG", "_d_s_p2803x___adc_8h.html#union_i_n_t_s_e_l9_n10___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#a09fe28eb91a089555d6e9977296ca99f", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#af066efa7745ad7cb7d514b27c62f0b88", null ]
    ] ],
    [ "SOCPRICTL_BITS", "_d_s_p2803x___adc_8h.html#struct_s_o_c_p_r_i_c_t_l___b_i_t_s", [
      [ "ONESHOT", "_d_s_p2803x___adc_8h.html#a3a54b5b8f7ed2af8defeb1b2e366f427", null ],
      [ "RRPOINTER", "_d_s_p2803x___adc_8h.html#aee1f03cf18b5b77cf8eb3556cbdf7f95", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#a03e09797b51f808bf82e3fdc52645d33", null ],
      [ "SOCPRIORITY", "_d_s_p2803x___adc_8h.html#a5d929fc108307ada10a56a35a5da618b", null ]
    ] ],
    [ "SOCPRICTL_REG", "_d_s_p2803x___adc_8h.html#union_s_o_c_p_r_i_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#aa1b92d4aca0bcc4f6ad2bd11079351e6", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a867a74ab8c4f126df9cc85a6dbdc5922", null ]
    ] ],
    [ "ADCSAMPLEMODE_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_s_a_m_p_l_e_m_o_d_e___b_i_t_s", [
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#a9cd20fcb534f3ee7ad00296c1f4e99ef", null ],
      [ "SIMULEN0", "_d_s_p2803x___adc_8h.html#a6a469e50161275bf634926c6c37ebf59", null ],
      [ "SIMULEN10", "_d_s_p2803x___adc_8h.html#a3fad190c859fdd2f7ba810cece6b4e58", null ],
      [ "SIMULEN12", "_d_s_p2803x___adc_8h.html#a0975a2cf9becce023c302cca05f3a78e", null ],
      [ "SIMULEN14", "_d_s_p2803x___adc_8h.html#a44a9d5e1af1cbab7676d4614a28b3865", null ],
      [ "SIMULEN2", "_d_s_p2803x___adc_8h.html#ab650f1a0343b7b195bd879bf711461e8", null ],
      [ "SIMULEN4", "_d_s_p2803x___adc_8h.html#a37ba3ec8f261f9beff58fa3ad021451d", null ],
      [ "SIMULEN6", "_d_s_p2803x___adc_8h.html#a4af1a925ecd03553159152ede7a6468f", null ],
      [ "SIMULEN8", "_d_s_p2803x___adc_8h.html#a05179a0569b94fcddaf98f7f0ee19048", null ]
    ] ],
    [ "ADCSAMPLEMODE_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_s_a_m_p_l_e_m_o_d_e___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#a79fdaf70eefd5d123807b8e5074a5da8", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#abfd509af231c3dc60dbb638c138064bb", null ]
    ] ],
    [ "ADCINTSOCSEL1_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_i_n_t_s_o_c_s_e_l1___b_i_t_s", [
      [ "SOC0", "_d_s_p2803x___adc_8h.html#a03566d327e40cd99400fa282f2140f33", null ],
      [ "SOC1", "_d_s_p2803x___adc_8h.html#ad6aec86cda14e6fe06445214dc62a676", null ],
      [ "SOC2", "_d_s_p2803x___adc_8h.html#a8fbba9e297bb643b72d3389f95e99fd0", null ],
      [ "SOC3", "_d_s_p2803x___adc_8h.html#a6b048ace1614b53033989e07fc7d8d46", null ],
      [ "SOC4", "_d_s_p2803x___adc_8h.html#ad87f8a8c930ddf90c630fd5311993753", null ],
      [ "SOC5", "_d_s_p2803x___adc_8h.html#ac6d8c8072ff3542bcbc8b7e3e95dfb8e", null ],
      [ "SOC6", "_d_s_p2803x___adc_8h.html#a7474835d01d7f702b754532740858599", null ],
      [ "SOC7", "_d_s_p2803x___adc_8h.html#a224233e4751c8a1af1f282e5beaf493f", null ]
    ] ],
    [ "ADCINTSOCSEL1_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_i_n_t_s_o_c_s_e_l1___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#a219365acf24b080e9b9e39380d159a47", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a119d5904ae30414ed7d0075fd43f7a06", null ]
    ] ],
    [ "ADCINTSOCSEL2_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_i_n_t_s_o_c_s_e_l2___b_i_t_s", [
      [ "SOC10", "_d_s_p2803x___adc_8h.html#a4b68f4caa5bec80d96097eb9be9ec3da", null ],
      [ "SOC11", "_d_s_p2803x___adc_8h.html#abf2ecaff550733549bce2d645b3d1241", null ],
      [ "SOC12", "_d_s_p2803x___adc_8h.html#a8ce4e5cac5aa183dcb913c40aa827dda", null ],
      [ "SOC13", "_d_s_p2803x___adc_8h.html#ad44e8ea4d8bc555c85d0782165607b48", null ],
      [ "SOC14", "_d_s_p2803x___adc_8h.html#a8276c54eba3cd014abe5d591cadcff2f", null ],
      [ "SOC15", "_d_s_p2803x___adc_8h.html#a96c8323f36fcb7e05a815eaa12dd2f4b", null ],
      [ "SOC8", "_d_s_p2803x___adc_8h.html#a8f6158c65d4ac36e167ae0914a7e03f1", null ],
      [ "SOC9", "_d_s_p2803x___adc_8h.html#ae271c1fec0d159887fcc652cb719f73d", null ]
    ] ],
    [ "ADCINTSOCSEL2_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_i_n_t_s_o_c_s_e_l2___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#aaa28dc1795b80ad18169a279b6de7657", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a4a981f67c8314729cfafb415bfa7c646", null ]
    ] ],
    [ "ADCSOC_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_s_o_c___b_i_t_s", [
      [ "SOC0", "_d_s_p2803x___adc_8h.html#a39b3902f54e28e79465b6b78eea4dd8e", null ],
      [ "SOC1", "_d_s_p2803x___adc_8h.html#afa23e9e3adb4d4c3a61928ebcb66caca", null ],
      [ "SOC10", "_d_s_p2803x___adc_8h.html#a224033e5f9a3df68cb59ba4f5d5f35ad", null ],
      [ "SOC11", "_d_s_p2803x___adc_8h.html#affe500f5f1b2028a9673ecb31914b1e5", null ],
      [ "SOC12", "_d_s_p2803x___adc_8h.html#a91479593e3a046792f704a3e69e5149b", null ],
      [ "SOC13", "_d_s_p2803x___adc_8h.html#a9f1668eaea63cf8675025a389d9f495d", null ],
      [ "SOC14", "_d_s_p2803x___adc_8h.html#a4852348767331bd7a079b3e76bfff717", null ],
      [ "SOC15", "_d_s_p2803x___adc_8h.html#aa9b23e6da1a4c086d8429b6a8973fd84", null ],
      [ "SOC2", "_d_s_p2803x___adc_8h.html#adc31bb7906bc621563746f56d137619b", null ],
      [ "SOC3", "_d_s_p2803x___adc_8h.html#a454189abc387275353c366c13cbbb548", null ],
      [ "SOC4", "_d_s_p2803x___adc_8h.html#a1dcad4c660c9bd69d650c0e93e5e1a40", null ],
      [ "SOC5", "_d_s_p2803x___adc_8h.html#a4fd7e7502d1a0a8a2eeae39655b8a17b", null ],
      [ "SOC6", "_d_s_p2803x___adc_8h.html#af212892d018103fc4ede16ddb935e9d1", null ],
      [ "SOC7", "_d_s_p2803x___adc_8h.html#a975b435836430b642d7a9e47b7b6b7d2", null ],
      [ "SOC8", "_d_s_p2803x___adc_8h.html#a566f6a65a39e27af58a8688681eeec06", null ],
      [ "SOC9", "_d_s_p2803x___adc_8h.html#a39aef9bea94f31f23fae269f2c9c2249", null ]
    ] ],
    [ "ADCSOC_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_s_o_c___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#ac40ffd9f3d6cd333610032e4fd82c424", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a7df0632fd708136dabf7d54c33174848", null ]
    ] ],
    [ "ADCSOCxCTL_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_s_o_cx_c_t_l___b_i_t_s", [
      [ "ACQPS", "_d_s_p2803x___adc_8h.html#a3bd08d4b16898a8e16111984d347538b", null ],
      [ "CHSEL", "_d_s_p2803x___adc_8h.html#adff28c51407c8c55865fc314288481a9", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#af76d51f60e0641170bee65378553eb69", null ],
      [ "TRIGSEL", "_d_s_p2803x___adc_8h.html#ae7d8d90c2070d007f575346320658efe", null ]
    ] ],
    [ "ADCSOCxCTL_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_s_o_cx_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#a1ac839a39c2670626dd1d97193fed15b", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a291326a406c512b7600ffc0bc6e81a37", null ]
    ] ],
    [ "ADCREFTRIM_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_r_e_f_t_r_i_m___b_i_t_s", [
      [ "BG_COARSE_TRIM", "_d_s_p2803x___adc_8h.html#a3205c7d2a48e16727fec558549b8f638", null ],
      [ "BG_FINE_TRIM", "_d_s_p2803x___adc_8h.html#ad8a9ad5b5fa8061e19a1ad0f083787fd", null ],
      [ "EXTREF_FINE_TRIM", "_d_s_p2803x___adc_8h.html#aa9e1470db6a725bac00b2c32e85bf720", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#a7b01bbd5a27a51ee5b2b0b0ae5826066", null ]
    ] ],
    [ "ADCREFTRIM_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_r_e_f_t_r_i_m___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#af49eb988323f3d2f93c33903ac326f9d", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#aa8ae49cf47d25bf1e4171b8e53f072db", null ]
    ] ],
    [ "ADCOFFTRIM_BITS", "_d_s_p2803x___adc_8h.html#struct_a_d_c_o_f_f_t_r_i_m___b_i_t_s", [
      [ "OFFTRIM", "_d_s_p2803x___adc_8h.html#a82882612f7985f754732a3ae98d5e646", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#ab0345669cb0764ee41ba705b1ddaf8bf", null ]
    ] ],
    [ "ADCOFFTRIM_REG", "_d_s_p2803x___adc_8h.html#union_a_d_c_o_f_f_t_r_i_m___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#ae8b09f6807d5f0bc7a41a0dc797f894e", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a7dac1b351eb7aa366e12f1ef3ab2ec6d", null ]
    ] ],
    [ "COMPHYSTCTL_BITS", "_d_s_p2803x___adc_8h.html#struct_c_o_m_p_h_y_s_t_c_t_l___b_i_t_s", [
      [ "COMP1_HYST_DISABLE", "_d_s_p2803x___adc_8h.html#abd38d33922a4f34515705b67cd10a705", null ],
      [ "COMP2_HYST_DISABLE", "_d_s_p2803x___adc_8h.html#a4a6e21e9d6418d36e4ec2097ee6b85d0", null ],
      [ "COMP3_HYST_DISABLE", "_d_s_p2803x___adc_8h.html#a2ac04f5b14067ed7d989e51a29e567d1", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#a1e9035def095b72dab1d00eb56e8d25b", null ],
      [ "rsvd2", "_d_s_p2803x___adc_8h.html#a25839a6be3c1ace7c3701f85dc8d9ded", null ],
      [ "rsvd3", "_d_s_p2803x___adc_8h.html#a2d122aa51f79b34815a69ef167fa3908", null ],
      [ "rsvd4", "_d_s_p2803x___adc_8h.html#a41a014042c8455885d7de45751d43bee", null ]
    ] ],
    [ "COMPHYSTCTL_REG", "_d_s_p2803x___adc_8h.html#union_c_o_m_p_h_y_s_t_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___adc_8h.html#a9eda7fba8ea00d27e34ea71cd9ffa1cd", null ],
      [ "bit", "_d_s_p2803x___adc_8h.html#a9a7fd2265090178767e3647b3444f329", null ]
    ] ],
    [ "ADC_REGS", "_d_s_p2803x___adc_8h.html#struct_a_d_c___r_e_g_s", [
      [ "ADCCTL1", "_d_s_p2803x___adc_8h.html#a7af1ed3d181e6196cc51e8c1a846679d", null ],
      [ "ADCCTL2", "_d_s_p2803x___adc_8h.html#ac9eac0df3428240e51106d7d6a49275a", null ],
      [ "ADCINTFLG", "_d_s_p2803x___adc_8h.html#a049ee2c4793c15907f8291d7a0305eb1", null ],
      [ "ADCINTFLGCLR", "_d_s_p2803x___adc_8h.html#a22df63f6bacce18ec9b152957ee0f3b9", null ],
      [ "ADCINTOVF", "_d_s_p2803x___adc_8h.html#a1c21d293b86bb60043399935be5596b6", null ],
      [ "ADCINTOVFCLR", "_d_s_p2803x___adc_8h.html#ac8f94ee62308a1595278ff70e893f2d4", null ],
      [ "ADCINTSOCSEL1", "_d_s_p2803x___adc_8h.html#a88412076b8482b7e92b5ef8922e21770", null ],
      [ "ADCINTSOCSEL2", "_d_s_p2803x___adc_8h.html#acbd148d1db784bda4734ed7abe66f9ad", null ],
      [ "ADCOFFTRIM", "_d_s_p2803x___adc_8h.html#ae8952dd63358d428fdd3bde422df99b2", null ],
      [ "ADCREFTRIM", "_d_s_p2803x___adc_8h.html#ad65e9c12e57ff64cc416abb5f2882f60", null ],
      [ "ADCSAMPLEMODE", "_d_s_p2803x___adc_8h.html#afd6bcedcb0d757a4d6ec5c89b33d9e00", null ],
      [ "ADCSOC0CTL", "_d_s_p2803x___adc_8h.html#a7babffda0af708bb987f931b5a44fb0d", null ],
      [ "ADCSOC10CTL", "_d_s_p2803x___adc_8h.html#a3c0382ee2ab4a28842ad9151fa537e1b", null ],
      [ "ADCSOC11CTL", "_d_s_p2803x___adc_8h.html#aeb172bab968bfc115c20d4b4dce2e8e3", null ],
      [ "ADCSOC12CTL", "_d_s_p2803x___adc_8h.html#ae9e5e9a33bb94e7e68cdab59b2b1ae8f", null ],
      [ "ADCSOC13CTL", "_d_s_p2803x___adc_8h.html#af5696341053de7f3f2515c6222349b3d", null ],
      [ "ADCSOC14CTL", "_d_s_p2803x___adc_8h.html#a6d041c7fde92b6bb10fff36892f6ce64", null ],
      [ "ADCSOC15CTL", "_d_s_p2803x___adc_8h.html#a43793da04433b3578f9414e9ee256b33", null ],
      [ "ADCSOC1CTL", "_d_s_p2803x___adc_8h.html#a9225079c32c026816153f3a445c40b70", null ],
      [ "ADCSOC2CTL", "_d_s_p2803x___adc_8h.html#a91905330ccdba34740cd7fd95cc0e75b", null ],
      [ "ADCSOC3CTL", "_d_s_p2803x___adc_8h.html#a03dfa6bc68ad322d9442aed1f26ce508", null ],
      [ "ADCSOC4CTL", "_d_s_p2803x___adc_8h.html#a5f2acc064671dee1f81356bf84fa14d2", null ],
      [ "ADCSOC5CTL", "_d_s_p2803x___adc_8h.html#ae15af8aa161824854ad5fa7f53329ded", null ],
      [ "ADCSOC6CTL", "_d_s_p2803x___adc_8h.html#ad2299503f229a0d55764530506704596", null ],
      [ "ADCSOC7CTL", "_d_s_p2803x___adc_8h.html#aa311111fe24c403a822dde41e0a5addf", null ],
      [ "ADCSOC8CTL", "_d_s_p2803x___adc_8h.html#a3add1b1c30027d28e352e6147f288297", null ],
      [ "ADCSOC9CTL", "_d_s_p2803x___adc_8h.html#ad9d5aabd8e41ac4713b235d5b7e83407", null ],
      [ "ADCSOCFLG1", "_d_s_p2803x___adc_8h.html#ad56ef1815a195dcc286c80d9b6dcd42c", null ],
      [ "ADCSOCFRC1", "_d_s_p2803x___adc_8h.html#aa7ee2a3b07441fc3e9938150fe6f0225", null ],
      [ "ADCSOCOVF1", "_d_s_p2803x___adc_8h.html#a017d5c383f16f811c951539fa1cd972c", null ],
      [ "ADCSOCOVFCLR1", "_d_s_p2803x___adc_8h.html#a7dc89689f08395ee14f1ec8a68e22064", null ],
      [ "COMPHYSTCTL", "_d_s_p2803x___adc_8h.html#afe141de50b4996623bdbb020e91a36d4", null ],
      [ "INTSEL1N2", "_d_s_p2803x___adc_8h.html#ad5a92454fd0ac7fda516fa200e190a4b", null ],
      [ "INTSEL3N4", "_d_s_p2803x___adc_8h.html#abd4236b16ff04568e7ff44762290e735", null ],
      [ "INTSEL5N6", "_d_s_p2803x___adc_8h.html#ace1a2b077910293a373dc2db72a7683b", null ],
      [ "INTSEL7N8", "_d_s_p2803x___adc_8h.html#ac600e4626f1a089754bcc7f2658f8f47", null ],
      [ "INTSEL9N10", "_d_s_p2803x___adc_8h.html#ac92275d15ea2a6f8bb0f2119613f3209", null ],
      [ "rsvd1", "_d_s_p2803x___adc_8h.html#a40e50b6b40073e54308ca157314139ed", null ],
      [ "rsvd10", "_d_s_p2803x___adc_8h.html#a898223d346d1c1d05d73191550b3a281", null ],
      [ "rsvd11", "_d_s_p2803x___adc_8h.html#a82bcf052a84c0953db2ea1012a0a58e1", null ],
      [ "rsvd12", "_d_s_p2803x___adc_8h.html#aa94043a10459a1bd8cdef13d87cefce0", null ],
      [ "rsvd2", "_d_s_p2803x___adc_8h.html#a45833f1412c36b59d7de251722fef9a8", null ],
      [ "rsvd3", "_d_s_p2803x___adc_8h.html#a8efb0ab1aa967a7167c7105113fd8881", null ],
      [ "rsvd4", "_d_s_p2803x___adc_8h.html#aeef4a9775ecb61f85ef968934e17783a", null ],
      [ "rsvd5", "_d_s_p2803x___adc_8h.html#a2592bcfde907ba34c466a453a56c498d", null ],
      [ "rsvd6", "_d_s_p2803x___adc_8h.html#a3cf5cbab43ffb9e822360c762f50452f", null ],
      [ "rsvd7", "_d_s_p2803x___adc_8h.html#a8f616efd7568552eaff974f7f5c6f2f4", null ],
      [ "rsvd8", "_d_s_p2803x___adc_8h.html#a6d4a4cf7fb69e550dedd21a8d1d48ed0", null ],
      [ "rsvd9", "_d_s_p2803x___adc_8h.html#af35bc7d90c2944d9ee918d39557bf662", null ],
      [ "SOCPRICTL", "_d_s_p2803x___adc_8h.html#a6a106ddd45b23417638ca1a485a6196d", null ]
    ] ],
    [ "ADC_RESULT_REGS", "_d_s_p2803x___adc_8h.html#struct_a_d_c___r_e_s_u_l_t___r_e_g_s", [
      [ "ADCRESULT0", "_d_s_p2803x___adc_8h.html#ac1289d7f452751f984e83c280041c861", null ],
      [ "ADCRESULT1", "_d_s_p2803x___adc_8h.html#af7433ccd4fd199d71777e8f43f6143c9", null ],
      [ "ADCRESULT10", "_d_s_p2803x___adc_8h.html#a42620bc2acb5a8636755a67e661932ee", null ],
      [ "ADCRESULT11", "_d_s_p2803x___adc_8h.html#ab0dfa947c08f8cc101b5ba40f9767593", null ],
      [ "ADCRESULT12", "_d_s_p2803x___adc_8h.html#a7dd1c5d84dc8b359f49c90ce81cd08bf", null ],
      [ "ADCRESULT13", "_d_s_p2803x___adc_8h.html#a03f2b3a10a1f9fef7343f77b3593aec7", null ],
      [ "ADCRESULT14", "_d_s_p2803x___adc_8h.html#a22f60b0807224219cbe124834743d81b", null ],
      [ "ADCRESULT15", "_d_s_p2803x___adc_8h.html#a9a634257e158e11b1634ef6967c48963", null ],
      [ "ADCRESULT2", "_d_s_p2803x___adc_8h.html#a5a06874a9487347f945f411eb94f7c85", null ],
      [ "ADCRESULT3", "_d_s_p2803x___adc_8h.html#ac186c1be3b15236faf296ec63e43ab48", null ],
      [ "ADCRESULT4", "_d_s_p2803x___adc_8h.html#adc1fe955c5bdb9bde06b8b792b96a106", null ],
      [ "ADCRESULT5", "_d_s_p2803x___adc_8h.html#accd83b2063ce7a4fd512f3f574228442", null ],
      [ "ADCRESULT6", "_d_s_p2803x___adc_8h.html#ab978a6ab4ed6a308776851ecdeb80fb1", null ],
      [ "ADCRESULT7", "_d_s_p2803x___adc_8h.html#a69e75f556f1b4a78f3cd547943e2f682", null ],
      [ "ADCRESULT8", "_d_s_p2803x___adc_8h.html#a97d78bd1b322b0ed4f9b2ca528c13232", null ],
      [ "ADCRESULT9", "_d_s_p2803x___adc_8h.html#ab56f00806d01880f62d85e499b104cef", null ],
      [ "rsvd", "_d_s_p2803x___adc_8h.html#a86c4861121de70cd9fa920fa73f7c1ae", null ]
    ] ],
    [ "AdcRegs", "_d_s_p2803x___adc_8h.html#a3c4604be23caa330da37227db2eca828", null ],
    [ "AdcResult", "_d_s_p2803x___adc_8h.html#abadff64810e24e12dbd7d6b7e0455213", null ]
];