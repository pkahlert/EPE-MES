var _d_s_p2803x___e_qep_8h =
[
    [ "QDECCTL_BITS", "_d_s_p2803x___e_qep_8h.html#struct_q_d_e_c_c_t_l___b_i_t_s", [
      [ "IGATE", "_d_s_p2803x___e_qep_8h.html#ac0990cb75f902af701cb3ee14dbce622", null ],
      [ "QAP", "_d_s_p2803x___e_qep_8h.html#a8afbe26800042c0875f18c59a046a866", null ],
      [ "QBP", "_d_s_p2803x___e_qep_8h.html#a1994b2d25235e7b50837d76706ac73a7", null ],
      [ "QIP", "_d_s_p2803x___e_qep_8h.html#a9eb0feb288441e49f7656687a00814d8", null ],
      [ "QSP", "_d_s_p2803x___e_qep_8h.html#a799c720eaf17f45b24f1c44d5be1a783", null ],
      [ "QSRC", "_d_s_p2803x___e_qep_8h.html#ad5190ac78a47c65d33d9fbd5dd6815fe", null ],
      [ "rsvd1", "_d_s_p2803x___e_qep_8h.html#afd73bd12adcf4b18d584885a1fb7c2e7", null ],
      [ "SOEN", "_d_s_p2803x___e_qep_8h.html#afd175aa2a3f870744f2d39799722534f", null ],
      [ "SPSEL", "_d_s_p2803x___e_qep_8h.html#a9938cddc3c8102a2c8dc4073ab5ce99e", null ],
      [ "SWAP", "_d_s_p2803x___e_qep_8h.html#afbee23e2adcbb23eb9737bab27009079", null ],
      [ "XCR", "_d_s_p2803x___e_qep_8h.html#a967c7f00af9183a5a04fe7e656dfe07e", null ]
    ] ],
    [ "QDECCTL_REG", "_d_s_p2803x___e_qep_8h.html#union_q_d_e_c_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_qep_8h.html#a1cf019b1c2ebcd2fefb3318ef3e9d398", null ],
      [ "bit", "_d_s_p2803x___e_qep_8h.html#abd7ade2840cc1d39f702d8ab2491a7c2", null ]
    ] ],
    [ "QEPCTL_BITS", "_d_s_p2803x___e_qep_8h.html#struct_q_e_p_c_t_l___b_i_t_s", [
      [ "FREE_SOFT", "_d_s_p2803x___e_qep_8h.html#a592101ad3689f169a2fd3023d20e0f96", null ],
      [ "IEI", "_d_s_p2803x___e_qep_8h.html#a554f1ae1b6ef404c583d3cddc4e59fbe", null ],
      [ "IEL", "_d_s_p2803x___e_qep_8h.html#af3d87a40bd36a26cbd03f6d3de7d3cf0", null ],
      [ "PCRM", "_d_s_p2803x___e_qep_8h.html#a309cfb6c8b45e751cb49cc6d3391ee71", null ],
      [ "QCLM", "_d_s_p2803x___e_qep_8h.html#ab04419f91d4bdd4700eeb25e8556de5f", null ],
      [ "QPEN", "_d_s_p2803x___e_qep_8h.html#abe9207cf42c4d938d95e8ef0c7782912", null ],
      [ "SEI", "_d_s_p2803x___e_qep_8h.html#a3fa1eb9ddf089005185f581df74eca50", null ],
      [ "SEL", "_d_s_p2803x___e_qep_8h.html#af0f956fc7a575257376b287ffc181e79", null ],
      [ "SWI", "_d_s_p2803x___e_qep_8h.html#ad7499cc1231003b100155a83bfc4c920", null ],
      [ "UTE", "_d_s_p2803x___e_qep_8h.html#a69a58c7012dfb810361ecadfc215b2b4", null ],
      [ "WDE", "_d_s_p2803x___e_qep_8h.html#a847775b55c5d81d05dcd1de1bca52c09", null ]
    ] ],
    [ "QEPCTL_REG", "_d_s_p2803x___e_qep_8h.html#union_q_e_p_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_qep_8h.html#a2c2a811fb57bf290ab5e85aa75816cad", null ],
      [ "bit", "_d_s_p2803x___e_qep_8h.html#a26d1f71620f5c17eebe83821c8f8110d", null ]
    ] ],
    [ "QCAPCTL_BITS", "_d_s_p2803x___e_qep_8h.html#struct_q_c_a_p_c_t_l___b_i_t_s", [
      [ "CCPS", "_d_s_p2803x___e_qep_8h.html#a75b6467faee15df6489e78ce9ecbecdf", null ],
      [ "CEN", "_d_s_p2803x___e_qep_8h.html#a6bb69fea54c791802690eb23c1fe1e8c", null ],
      [ "rsvd1", "_d_s_p2803x___e_qep_8h.html#a2123297ac09dbbc73071d4752108e876", null ],
      [ "UPPS", "_d_s_p2803x___e_qep_8h.html#ad78cd88f44cbda76e1774f3742ea8679", null ]
    ] ],
    [ "QCAPCTL_REG", "_d_s_p2803x___e_qep_8h.html#union_q_c_a_p_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_qep_8h.html#ab86b36d7457295c501dfb915190b62a9", null ],
      [ "bit", "_d_s_p2803x___e_qep_8h.html#a3b1e807bdc0d92b7cd54d2ab50586f67", null ]
    ] ],
    [ "QPOSCTL_BITS", "_d_s_p2803x___e_qep_8h.html#struct_q_p_o_s_c_t_l___b_i_t_s", [
      [ "PCE", "_d_s_p2803x___e_qep_8h.html#a9dd7129b8d00a00c1b0c90c013fd5ab6", null ],
      [ "PCLOAD", "_d_s_p2803x___e_qep_8h.html#a25257724e310db61a8a086a6e47186a2", null ],
      [ "PCPOL", "_d_s_p2803x___e_qep_8h.html#ae42571e0b4c0a85f8edd03dd42f7b74c", null ],
      [ "PCSHDW", "_d_s_p2803x___e_qep_8h.html#ad926082d34bc3065f9f344336b1c8084", null ],
      [ "PCSPW", "_d_s_p2803x___e_qep_8h.html#ac4eb2edac6f95bb0f9229d6b5929749f", null ]
    ] ],
    [ "QPOSCTL_REG", "_d_s_p2803x___e_qep_8h.html#union_q_p_o_s_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___e_qep_8h.html#a011718d4ebee0a53854b0d72f9da5315", null ],
      [ "bit", "_d_s_p2803x___e_qep_8h.html#ad968dde866010de4aedad589d26742cd", null ]
    ] ],
    [ "QEINT_BITS", "_d_s_p2803x___e_qep_8h.html#struct_q_e_i_n_t___b_i_t_s", [
      [ "IEL", "_d_s_p2803x___e_qep_8h.html#aaa68335ac4fd789e6cd3f3b65f8c664a", null ],
      [ "PCE", "_d_s_p2803x___e_qep_8h.html#a5db62f424c4fde37d59384958ffe227e", null ],
      [ "PCM", "_d_s_p2803x___e_qep_8h.html#a01e22f32cc1085eb10a0b6f7926338a7", null ],
      [ "PCO", "_d_s_p2803x___e_qep_8h.html#a7eebcf9be73ca6f8f5b2e94b18b67eae", null ],
      [ "PCR", "_d_s_p2803x___e_qep_8h.html#a348de8d77918aa290d14a2f919668fd5", null ],
      [ "PCU", "_d_s_p2803x___e_qep_8h.html#a91bb412ee07bc4721cda1b575f8ced04", null ],
      [ "QDC", "_d_s_p2803x___e_qep_8h.html#a3a85f2c9aa910e621c320db39525e9ce", null ],
      [ "QPE", "_d_s_p2803x___e_qep_8h.html#aecdf89c186b2ab4deb1d7cfa082f0931", null ],
      [ "rsvd1", "_d_s_p2803x___e_qep_8h.html#abe715b63fbc4566a0c29a163bede0173", null ],
      [ "rsvd2", "_d_s_p2803x___e_qep_8h.html#a2ed45aa9578d43d3cb8227bb2632a935", null ],
      [ "SEL", "_d_s_p2803x___e_qep_8h.html#a54d146af53fecb82e3ec7e910e81f6f3", null ],
      [ "UTO", "_d_s_p2803x___e_qep_8h.html#aa0a1f958f8887863c17bc28e7522e991", null ],
      [ "WTO", "_d_s_p2803x___e_qep_8h.html#a01c31e270088664ce3f3faa43990538a", null ]
    ] ],
    [ "QEINT_REG", "_d_s_p2803x___e_qep_8h.html#union_q_e_i_n_t___r_e_g", [
      [ "all", "_d_s_p2803x___e_qep_8h.html#aebfe0b2c5c587a3f862c1fd6ea547e41", null ],
      [ "bit", "_d_s_p2803x___e_qep_8h.html#a30eb5612365569ee69477cf24599233f", null ]
    ] ],
    [ "QFLG_BITS", "_d_s_p2803x___e_qep_8h.html#struct_q_f_l_g___b_i_t_s", [
      [ "IEL", "_d_s_p2803x___e_qep_8h.html#ab2ef832b5f997c5e571a6fc501551d8c", null ],
      [ "INT", "_d_s_p2803x___e_qep_8h.html#ad44b23620986326fa931182e223ce3ee", null ],
      [ "PCE", "_d_s_p2803x___e_qep_8h.html#abbeb34f3b3be33cafc6d3c8a715bb554", null ],
      [ "PCM", "_d_s_p2803x___e_qep_8h.html#ad8ccd7585da9f6f0438a35baba79603c", null ],
      [ "PCO", "_d_s_p2803x___e_qep_8h.html#a7f2c178dfc78a9ee7c653c67ecc26042", null ],
      [ "PCR", "_d_s_p2803x___e_qep_8h.html#a2b4faa60ebd3d949e3763ad550f90f07", null ],
      [ "PCU", "_d_s_p2803x___e_qep_8h.html#a0c966623292b28ee54753c42be3246ba", null ],
      [ "PHE", "_d_s_p2803x___e_qep_8h.html#a81f8a9ab1cd76741554a74acc6e7069f", null ],
      [ "QDC", "_d_s_p2803x___e_qep_8h.html#a5fc6f9e01268e98261be1728e3c7da68", null ],
      [ "rsvd2", "_d_s_p2803x___e_qep_8h.html#a1e1f172ba3fa329a8095c4fd209cf5f4", null ],
      [ "SEL", "_d_s_p2803x___e_qep_8h.html#aaf892d64e7f88bef637a8957c0420af3", null ],
      [ "UTO", "_d_s_p2803x___e_qep_8h.html#a3e9f20ef95fa40f16985a509802e1e3e", null ],
      [ "WTO", "_d_s_p2803x___e_qep_8h.html#aa06da50af17439bae3518a8c2bd9fee4", null ]
    ] ],
    [ "QFLG_REG", "_d_s_p2803x___e_qep_8h.html#union_q_f_l_g___r_e_g", [
      [ "all", "_d_s_p2803x___e_qep_8h.html#a17320dcb8b42603a5b335835be8f85bc", null ],
      [ "bit", "_d_s_p2803x___e_qep_8h.html#aeff176af7ffea14fb680b0f402c5ad77", null ]
    ] ],
    [ "QFRC_BITS", "_d_s_p2803x___e_qep_8h.html#struct_q_f_r_c___b_i_t_s", [
      [ "IEL", "_d_s_p2803x___e_qep_8h.html#a3f146c847284e8212e5903cb37de3bc3", null ],
      [ "PCE", "_d_s_p2803x___e_qep_8h.html#ab18b19ae9cc0cc3d5f839bd1199980de", null ],
      [ "PCM", "_d_s_p2803x___e_qep_8h.html#a1d0151ae93671fd6f8d4d36de9a19662", null ],
      [ "PCO", "_d_s_p2803x___e_qep_8h.html#ae5816dfcac21f90a07fc3bfd183d3330", null ],
      [ "PCR", "_d_s_p2803x___e_qep_8h.html#aaf7753d52aceb9333b7384b31e6d3ae0", null ],
      [ "PCU", "_d_s_p2803x___e_qep_8h.html#a948d7bfe9d807e5e3572d51be18e2307", null ],
      [ "PHE", "_d_s_p2803x___e_qep_8h.html#ad742b11308e5dca749252b67097b1eae", null ],
      [ "QDC", "_d_s_p2803x___e_qep_8h.html#a27552e60bdadacab9af831693d0df1f1", null ],
      [ "reserved", "_d_s_p2803x___e_qep_8h.html#a75c7da7a9ada18bd3f79e230a32d67c5", null ],
      [ "rsvd2", "_d_s_p2803x___e_qep_8h.html#a184f247f6da0b5442e7924c9c2d1e8f1", null ],
      [ "SEL", "_d_s_p2803x___e_qep_8h.html#a636968e699596011e991def743195843", null ],
      [ "UTO", "_d_s_p2803x___e_qep_8h.html#af4e1fa8397256b95cb031bf4d4010ea9", null ],
      [ "WTO", "_d_s_p2803x___e_qep_8h.html#ac1aab146457e3667a4d16850c56103b2", null ]
    ] ],
    [ "QFRC_REG", "_d_s_p2803x___e_qep_8h.html#union_q_f_r_c___r_e_g", [
      [ "all", "_d_s_p2803x___e_qep_8h.html#a808d70687b25a2ef2ac1909f7a7e2dad", null ],
      [ "bit", "_d_s_p2803x___e_qep_8h.html#a44ba13887583e70d5671a3179021dea2", null ]
    ] ],
    [ "QEPSTS_BITS", "_d_s_p2803x___e_qep_8h.html#struct_q_e_p_s_t_s___b_i_t_s", [
      [ "CDEF", "_d_s_p2803x___e_qep_8h.html#a184a49426085e7c11df143ec49e50031", null ],
      [ "COEF", "_d_s_p2803x___e_qep_8h.html#a32d22cf271ede895da4e7354ab933b41", null ],
      [ "FIDF", "_d_s_p2803x___e_qep_8h.html#a8465a2eafbeefd200c211b2576ad74b9", null ],
      [ "FIMF", "_d_s_p2803x___e_qep_8h.html#a6edd91f36c705a88ca5fd7ba59912de8", null ],
      [ "PCEF", "_d_s_p2803x___e_qep_8h.html#a88c6d2960f4a2abd796907553a4a9df7", null ],
      [ "QDF", "_d_s_p2803x___e_qep_8h.html#a623d6a4592f51d93a8f58f76ddf8f041", null ],
      [ "QDLF", "_d_s_p2803x___e_qep_8h.html#aad27f808c4e21d5bb9bf7054702090be", null ],
      [ "rsvd1", "_d_s_p2803x___e_qep_8h.html#a67721f711d89ea7fce60b09b795835e5", null ],
      [ "UPEVNT", "_d_s_p2803x___e_qep_8h.html#a70a730f0ccf3e87297a407d4eaf92abb", null ]
    ] ],
    [ "QEPSTS_REG", "_d_s_p2803x___e_qep_8h.html#union_q_e_p_s_t_s___r_e_g", [
      [ "all", "_d_s_p2803x___e_qep_8h.html#a41f62e294031446e3746f26ddd0aa3b2", null ],
      [ "bit", "_d_s_p2803x___e_qep_8h.html#a48d1af0018d5c776d8ab56f1a46e8793", null ]
    ] ],
    [ "EQEP_REGS", "_d_s_p2803x___e_qep_8h.html#struct_e_q_e_p___r_e_g_s", [
      [ "QCAPCTL", "_d_s_p2803x___e_qep_8h.html#a9d4b27278a621aad04be4039f59b0612", null ],
      [ "QCLR", "_d_s_p2803x___e_qep_8h.html#a7114f2e5d0a7d2be1bd4b6ed8aea9988", null ],
      [ "QCPRD", "_d_s_p2803x___e_qep_8h.html#a5efb145522ba6915a07b7b8e6a40714a", null ],
      [ "QCPRDLAT", "_d_s_p2803x___e_qep_8h.html#a09a27a8ca2cdacda92dcf682dbf65faf", null ],
      [ "QCTMR", "_d_s_p2803x___e_qep_8h.html#ae506343d05ced9e18eabf26c3cc35eb5", null ],
      [ "QCTMRLAT", "_d_s_p2803x___e_qep_8h.html#ab0bf278f6774d2c6e321e84afbd9ac42", null ],
      [ "QDECCTL", "_d_s_p2803x___e_qep_8h.html#aa7af3d618f15f2638bede48909caeea3", null ],
      [ "QEINT", "_d_s_p2803x___e_qep_8h.html#a4b44e230c8b171ee5ca4d6812068137c", null ],
      [ "QEPCTL", "_d_s_p2803x___e_qep_8h.html#a1103cb04613f4e933cb854b59363e3a2", null ],
      [ "QEPSTS", "_d_s_p2803x___e_qep_8h.html#a96b7e8ee9d3db7034910e558e9f3292c", null ],
      [ "QFLG", "_d_s_p2803x___e_qep_8h.html#a291708821e523a51635059e7f59873dc", null ],
      [ "QFRC", "_d_s_p2803x___e_qep_8h.html#a1884411644bbac741ff0939811d0f8ba", null ],
      [ "QPOSCMP", "_d_s_p2803x___e_qep_8h.html#a2f75adff5448cdb43f8a3fdbb9f3e0ba", null ],
      [ "QPOSCNT", "_d_s_p2803x___e_qep_8h.html#a620c5451be1851a810fd0b32cf61ba2f", null ],
      [ "QPOSCTL", "_d_s_p2803x___e_qep_8h.html#affb91c511aa51dc9978b1efda3b26d2f", null ],
      [ "QPOSILAT", "_d_s_p2803x___e_qep_8h.html#ac2fc3bd5c1d31dccc1526b52fbe69af8", null ],
      [ "QPOSINIT", "_d_s_p2803x___e_qep_8h.html#aa9ade24dd4438724b26b705bbd2c95c2", null ],
      [ "QPOSLAT", "_d_s_p2803x___e_qep_8h.html#a7bbe293c2e851c385ddcdd179ffa8a32", null ],
      [ "QPOSMAX", "_d_s_p2803x___e_qep_8h.html#aa50f40583385cd121aba6aa8859714de", null ],
      [ "QPOSSLAT", "_d_s_p2803x___e_qep_8h.html#a269e00259a286732b3ed95d87611d52f", null ],
      [ "QUPRD", "_d_s_p2803x___e_qep_8h.html#a421e22312802be8823425cd62aca4a4b", null ],
      [ "QUTMR", "_d_s_p2803x___e_qep_8h.html#ab15a2d350b0c536913fac8dabba0a107", null ],
      [ "QWDPRD", "_d_s_p2803x___e_qep_8h.html#a8bd38f968477a12dc788c9cc37b1e2d5", null ],
      [ "QWDTMR", "_d_s_p2803x___e_qep_8h.html#a313d77931944d22637cbabaf38964e39", null ],
      [ "rsvd1", "_d_s_p2803x___e_qep_8h.html#a3a86a2aa28b8a1a9815a7b1aa0941051", null ]
    ] ],
    [ "EQep1Regs", "_d_s_p2803x___e_qep_8h.html#a7c3e18bd2186937f5d25845a00069126", null ]
];