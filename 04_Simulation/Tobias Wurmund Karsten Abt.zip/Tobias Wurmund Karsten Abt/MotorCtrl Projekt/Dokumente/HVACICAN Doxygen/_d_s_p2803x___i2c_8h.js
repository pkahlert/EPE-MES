var _d_s_p2803x___i2c_8h =
[
    [ "I2CISRC_BITS", "_d_s_p2803x___i2c_8h.html#struct_i2_c_i_s_r_c___b_i_t_s", [
      [ "INTCODE", "_d_s_p2803x___i2c_8h.html#a42de2c1224d9b2bacd959ad788ba50bc", null ],
      [ "rsvd1", "_d_s_p2803x___i2c_8h.html#adbf4bb738ba1e104d07a4b63ed2da821", null ]
    ] ],
    [ "I2CISRC_REG", "_d_s_p2803x___i2c_8h.html#union_i2_c_i_s_r_c___r_e_g", [
      [ "all", "_d_s_p2803x___i2c_8h.html#a1a4e787f8f31300f9bf1be1b2880d20a", null ],
      [ "bit", "_d_s_p2803x___i2c_8h.html#af4176827ca166b52668b93aee06bbfcc", null ]
    ] ],
    [ "I2CIER_BITS", "_d_s_p2803x___i2c_8h.html#struct_i2_c_i_e_r___b_i_t_s", [
      [ "AAS", "_d_s_p2803x___i2c_8h.html#a17af651ee272f9c89edf51418fdb387f", null ],
      [ "ARBL", "_d_s_p2803x___i2c_8h.html#ad2662239e960372a770c6ab64daa832f", null ],
      [ "ARDY", "_d_s_p2803x___i2c_8h.html#a53884050226bcd70c2c2898afad903ba", null ],
      [ "NACK", "_d_s_p2803x___i2c_8h.html#afbace54d084b73b4852794c2a47dff89", null ],
      [ "RRDY", "_d_s_p2803x___i2c_8h.html#a362c4a72ba104ac1251e2a66c7a6e18e", null ],
      [ "rsvd", "_d_s_p2803x___i2c_8h.html#a232176eed3b43139da52140a3107345a", null ],
      [ "SCD", "_d_s_p2803x___i2c_8h.html#aaccd32a49a4fc8b5ffc7d871b623240d", null ],
      [ "XRDY", "_d_s_p2803x___i2c_8h.html#a21ae35a5bdb1cc156fc9ad9377e89082", null ]
    ] ],
    [ "I2CIER_REG", "_d_s_p2803x___i2c_8h.html#union_i2_c_i_e_r___r_e_g", [
      [ "all", "_d_s_p2803x___i2c_8h.html#a5c85d2a6397cd14939f7f55dc31dd461", null ],
      [ "bit", "_d_s_p2803x___i2c_8h.html#a436b7b2b57ee50f0954539af5c44d109", null ]
    ] ],
    [ "I2CSTR_BITS", "_d_s_p2803x___i2c_8h.html#struct_i2_c_s_t_r___b_i_t_s", [
      [ "AAS", "_d_s_p2803x___i2c_8h.html#a45b432d7da469e485e328c5040f40dda", null ],
      [ "AD0", "_d_s_p2803x___i2c_8h.html#a3a4dfae78c9e35d9ceac0daf32aaddae", null ],
      [ "ARBL", "_d_s_p2803x___i2c_8h.html#a532ba17217d7a7cf772684c166582a58", null ],
      [ "ARDY", "_d_s_p2803x___i2c_8h.html#a17507e7cb38ed76bfe60ec834805782f", null ],
      [ "BB", "_d_s_p2803x___i2c_8h.html#ac2d84bb7bb0281ca789620e5870f5926", null ],
      [ "NACK", "_d_s_p2803x___i2c_8h.html#aaaffa0caac187237bc320bd90f30a4bf", null ],
      [ "NACKSNT", "_d_s_p2803x___i2c_8h.html#ac5bd811bf405ffad7260b39967de5586", null ],
      [ "RRDY", "_d_s_p2803x___i2c_8h.html#a67f909355e94f211334df80ce7032a5e", null ],
      [ "RSFULL", "_d_s_p2803x___i2c_8h.html#a5fe45f4da0221304ddc2d5b67d99702b", null ],
      [ "rsvd1", "_d_s_p2803x___i2c_8h.html#ac58fb6602977fa71091a105964fe7e6b", null ],
      [ "rsvd2", "_d_s_p2803x___i2c_8h.html#a734c88025df18e7ce1051a13a9b18813", null ],
      [ "SCD", "_d_s_p2803x___i2c_8h.html#a00d0541ce7b3c446100e7adfc49bf29f", null ],
      [ "SDIR", "_d_s_p2803x___i2c_8h.html#add76c8dbfe1e8040a9d3222d45e2715e", null ],
      [ "XRDY", "_d_s_p2803x___i2c_8h.html#a9aba77dabb5660ab8f6b7f31da075749", null ],
      [ "XSMT", "_d_s_p2803x___i2c_8h.html#ae112827427b81bd35f8d180bd94f32c8", null ]
    ] ],
    [ "I2CSTR_REG", "_d_s_p2803x___i2c_8h.html#union_i2_c_s_t_r___r_e_g", [
      [ "all", "_d_s_p2803x___i2c_8h.html#accdc636f5f8a855d9b6beb3308c39127", null ],
      [ "bit", "_d_s_p2803x___i2c_8h.html#aa939f092edf01a27e251fa8db3dc27ce", null ]
    ] ],
    [ "I2CMDR_BITS", "_d_s_p2803x___i2c_8h.html#struct_i2_c_m_d_r___b_i_t_s", [
      [ "BC", "_d_s_p2803x___i2c_8h.html#a005c24db7747ea44ee2da76aa5958e4b", null ],
      [ "DLB", "_d_s_p2803x___i2c_8h.html#a171781eed0b9afce6216f0266f4296d9", null ],
      [ "FDF", "_d_s_p2803x___i2c_8h.html#a7de6595878a572f43019b790716b05ab", null ],
      [ "FREE", "_d_s_p2803x___i2c_8h.html#ab1acd800dfd6b72ba2ed7e9ea20698c5", null ],
      [ "IRS", "_d_s_p2803x___i2c_8h.html#a006d052b30adab1d4160829cdd27f4a6", null ],
      [ "MST", "_d_s_p2803x___i2c_8h.html#ac57f30d6f19c2fa6c0660e3900b065a8", null ],
      [ "NACKMOD", "_d_s_p2803x___i2c_8h.html#ae306bed748642cde2482e23ae57d0d70", null ],
      [ "RM", "_d_s_p2803x___i2c_8h.html#a3aebcf47a07e317be173f1b407dbb425", null ],
      [ "rsvd1", "_d_s_p2803x___i2c_8h.html#a39c7a9b1c505bbfb8a37d72e7fb43ceb", null ],
      [ "STB", "_d_s_p2803x___i2c_8h.html#a1bc7ab9492603fb701276d3289d1cbe4", null ],
      [ "STP", "_d_s_p2803x___i2c_8h.html#aeea5016b61fb54077daa68406f7342e9", null ],
      [ "STT", "_d_s_p2803x___i2c_8h.html#aa31032cc97070b4406a2d5c851998338", null ],
      [ "TRX", "_d_s_p2803x___i2c_8h.html#af2b3476fe6b04a481e6d5af6f620f549", null ],
      [ "XA", "_d_s_p2803x___i2c_8h.html#ac560243766d253956acde7c62ec8a12e", null ]
    ] ],
    [ "I2CMDR_REG", "_d_s_p2803x___i2c_8h.html#union_i2_c_m_d_r___r_e_g", [
      [ "all", "_d_s_p2803x___i2c_8h.html#a37dda719f5bdf5409dd15e0ae06240f5", null ],
      [ "bit", "_d_s_p2803x___i2c_8h.html#a4f5ada5ab9c47169996959944095f621", null ]
    ] ],
    [ "I2CEMDR_BITS", "_d_s_p2803x___i2c_8h.html#struct_i2_c_e_m_d_r___b_i_t_s", [
      [ "BCM", "_d_s_p2803x___i2c_8h.html#aebd250c5011e2a707e99aa3416451302", null ],
      [ "rsvd1", "_d_s_p2803x___i2c_8h.html#af1f5886993492dd8e79ab357a116964c", null ]
    ] ],
    [ "I2CEMDR_REG", "_d_s_p2803x___i2c_8h.html#union_i2_c_e_m_d_r___r_e_g", [
      [ "all", "_d_s_p2803x___i2c_8h.html#a28183ec190cbef9884e95e0b00bb3e9a", null ],
      [ "bit", "_d_s_p2803x___i2c_8h.html#a4a6e0a46cbb9241ae799dc77dcc75aad", null ]
    ] ],
    [ "I2CPSC_BITS", "_d_s_p2803x___i2c_8h.html#struct_i2_c_p_s_c___b_i_t_s", [
      [ "IPSC", "_d_s_p2803x___i2c_8h.html#a1061a011ec6906c0ce70921f01ddbc12", null ],
      [ "rsvd1", "_d_s_p2803x___i2c_8h.html#a0d75d7cfd0c7f4043490b48d4c91eb89", null ]
    ] ],
    [ "I2CPSC_REG", "_d_s_p2803x___i2c_8h.html#union_i2_c_p_s_c___r_e_g", [
      [ "all", "_d_s_p2803x___i2c_8h.html#a3abae0eb15f2a2964eccaea90fed2d11", null ],
      [ "bit", "_d_s_p2803x___i2c_8h.html#ac007d57365b350efc370393c27841370", null ]
    ] ],
    [ "I2CFFTX_BITS", "_d_s_p2803x___i2c_8h.html#struct_i2_c_f_f_t_x___b_i_t_s", [
      [ "I2CFFEN", "_d_s_p2803x___i2c_8h.html#a8cebf27a41e8ee59fd13252946b52e1e", null ],
      [ "rsvd1", "_d_s_p2803x___i2c_8h.html#a947b3e4aaa1264cedf56ac5941c454e2", null ],
      [ "TXFFIENA", "_d_s_p2803x___i2c_8h.html#a2d8da2df7de70a24d0e94a889a07a7f9", null ],
      [ "TXFFIL", "_d_s_p2803x___i2c_8h.html#aa0a00aae83c4af9209f91c9c00f25154", null ],
      [ "TXFFINT", "_d_s_p2803x___i2c_8h.html#a3b0620fc5d20d63019d6ec87e090c3df", null ],
      [ "TXFFINTCLR", "_d_s_p2803x___i2c_8h.html#ad3323bce272911606d49ac45a94c8180", null ],
      [ "TXFFRST", "_d_s_p2803x___i2c_8h.html#a13f0b963e09d17eb9187e11a850e50ca", null ],
      [ "TXFFST", "_d_s_p2803x___i2c_8h.html#a9164d0f846b070f67b2db6d3da7a7c08", null ]
    ] ],
    [ "I2CFFTX_REG", "_d_s_p2803x___i2c_8h.html#union_i2_c_f_f_t_x___r_e_g", [
      [ "all", "_d_s_p2803x___i2c_8h.html#a449c30c3a4f919be72ce243603f89a98", null ],
      [ "bit", "_d_s_p2803x___i2c_8h.html#aa11c825e3133999b1865da0d53e7c888", null ]
    ] ],
    [ "I2CFFRX_BITS", "_d_s_p2803x___i2c_8h.html#struct_i2_c_f_f_r_x___b_i_t_s", [
      [ "rsvd1", "_d_s_p2803x___i2c_8h.html#a6858858e83e9538a5a00ad90cca30c36", null ],
      [ "RXFFIENA", "_d_s_p2803x___i2c_8h.html#a2ce786826a8f31a983b88d8957f1e4c8", null ],
      [ "RXFFIL", "_d_s_p2803x___i2c_8h.html#ad73808f17ee330a345fb084a9ba69c13", null ],
      [ "RXFFINT", "_d_s_p2803x___i2c_8h.html#ada0448b1093602277403fcd62cfdf480", null ],
      [ "RXFFINTCLR", "_d_s_p2803x___i2c_8h.html#a47c1b464d6ad7dd456440e78e602ca80", null ],
      [ "RXFFRST", "_d_s_p2803x___i2c_8h.html#a91d3c2135e600a2b64d92618c5074eb5", null ],
      [ "RXFFST", "_d_s_p2803x___i2c_8h.html#a6de671f4e79e7b979a2eb5957ff76f55", null ]
    ] ],
    [ "I2CFFRX_REG", "_d_s_p2803x___i2c_8h.html#union_i2_c_f_f_r_x___r_e_g", [
      [ "all", "_d_s_p2803x___i2c_8h.html#afc3121b4a10a73784105f54bdb0e7c16", null ],
      [ "bit", "_d_s_p2803x___i2c_8h.html#ad75fdf8650a6c6271afde543338414a5", null ]
    ] ],
    [ "I2C_REGS", "_d_s_p2803x___i2c_8h.html#struct_i2_c___r_e_g_s", [
      [ "I2CCLKH", "_d_s_p2803x___i2c_8h.html#ac0196dccce8ca9b880cd05b5d7a45cd3", null ],
      [ "I2CCLKL", "_d_s_p2803x___i2c_8h.html#a8c144771bfe69298b5e7f6dd167263b5", null ],
      [ "I2CCNT", "_d_s_p2803x___i2c_8h.html#ac472e5f85f435d8542609db043ffaae4", null ],
      [ "I2CDRR", "_d_s_p2803x___i2c_8h.html#a79ef2f770bb58c8608e2aa396e9d0318", null ],
      [ "I2CDXR", "_d_s_p2803x___i2c_8h.html#a35d80b30895e2ef84c22b31525fc0fde", null ],
      [ "I2CEMDR", "_d_s_p2803x___i2c_8h.html#a310af971665412225866a1339a3c8e68", null ],
      [ "I2CFFRX", "_d_s_p2803x___i2c_8h.html#a42da692b5086399e905af9be393a573c", null ],
      [ "I2CFFTX", "_d_s_p2803x___i2c_8h.html#a7c0c6d1fc9e253982cd34474ff0365bd", null ],
      [ "I2CIER", "_d_s_p2803x___i2c_8h.html#a476dc6105298595529fe2ac2ce94ba60", null ],
      [ "I2CISRC", "_d_s_p2803x___i2c_8h.html#a0f57d9034567b71cd6ee82512ced3ae4", null ],
      [ "I2CMDR", "_d_s_p2803x___i2c_8h.html#a5aecafbae128f79217bd3ccee6fc9b63", null ],
      [ "I2COAR", "_d_s_p2803x___i2c_8h.html#a0c60cb849264d3d8c932511715d55f1d", null ],
      [ "I2CPSC", "_d_s_p2803x___i2c_8h.html#a557e1617b1357bbaa7645d6c7489ce04", null ],
      [ "I2CSAR", "_d_s_p2803x___i2c_8h.html#a4c491e1e0ad10efad5ee6b8cf80f6660", null ],
      [ "I2CSTR", "_d_s_p2803x___i2c_8h.html#a478b82d4d7d8b07ffa5b82cae7f60c1a", null ],
      [ "rsvd2", "_d_s_p2803x___i2c_8h.html#ab3e4a800c7b96a9c722fcd85accafd74", null ]
    ] ],
    [ "I2caRegs", "_d_s_p2803x___i2c_8h.html#a286b3fa79c555a59150c38288a5181e0", null ]
];