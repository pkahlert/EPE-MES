var cur__mod_8h =
[
    [ "CURMOD", "cur__mod_8h.html#struct_c_u_r_m_o_d", [
      [ "IDs", "cur__mod_8h.html#abb0434729ba0a4bec883dcece1f4d303", null ],
      [ "IMDs", "cur__mod_8h.html#a7be7acb2017e28ccaf6ac280e2f802fe", null ],
      [ "IQs", "cur__mod_8h.html#aa07f52d4a575a1f0be419b87463156fa", null ],
      [ "K", "cur__mod_8h.html#adb36239a72412cf7888fe16cca97d608", null ],
      [ "Kr", "cur__mod_8h.html#a9fc1eeadc94c1921957f98d43ee9e48c", null ],
      [ "Kt", "cur__mod_8h.html#aee9a87635bf39321c2662be607ab9e57", null ],
      [ "Theta", "cur__mod_8h.html#a009eecb5e71c1e09df330e81cbad555c", null ],
      [ "We", "cur__mod_8h.html#a20f7b48eb6c17596e7dd7c5b7ebfce8b", null ],
      [ "Wr", "cur__mod_8h.html#a51bfcd6f53e78494aa2a4b77d19e96f4", null ],
      [ "Wslip", "cur__mod_8h.html#a0400ac76e961608cb131fa56f2cfe14c", null ]
    ] ],
    [ "CUR_MOD_MACRO", "cur__mod_8h.html#aa0f5e62ea3a33fc28bf8657b5cf240d8", null ],
    [ "CURMOD_DEFAULTS", "cur__mod_8h.html#aa59fd017f356f1f3fc54ef538e313fdb", null ]
];