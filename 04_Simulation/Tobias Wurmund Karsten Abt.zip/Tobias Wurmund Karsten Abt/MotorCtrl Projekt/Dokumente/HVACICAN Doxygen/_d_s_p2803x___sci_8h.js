var _d_s_p2803x___sci_8h =
[
    [ "SCICCR_BITS", "_d_s_p2803x___sci_8h.html#struct_s_c_i_c_c_r___b_i_t_s", [
      [ "ADDRIDLE_MODE", "_d_s_p2803x___sci_8h.html#a1ee5537d604142dc799fdb16024e4df2", null ],
      [ "LOOPBKENA", "_d_s_p2803x___sci_8h.html#a5b688e83f694986da71fc070f6368791", null ],
      [ "PARITY", "_d_s_p2803x___sci_8h.html#a502877d03d795735c57f390aa7c94ebe", null ],
      [ "PARITYENA", "_d_s_p2803x___sci_8h.html#ad4fc726d0f0ddc99e917ffe95a14b356", null ],
      [ "rsvd1", "_d_s_p2803x___sci_8h.html#a275dcf6ed62e2493422fea302f0346c4", null ],
      [ "SCICHAR", "_d_s_p2803x___sci_8h.html#a5905dc933eca9a6642fec892cd535c13", null ],
      [ "STOPBITS", "_d_s_p2803x___sci_8h.html#ac25e8cbd01da3fd64d1c2848c6706020", null ]
    ] ],
    [ "SCICCR_REG", "_d_s_p2803x___sci_8h.html#union_s_c_i_c_c_r___r_e_g", [
      [ "all", "_d_s_p2803x___sci_8h.html#a50cde7056cb5efec178b0ab523194b93", null ],
      [ "bit", "_d_s_p2803x___sci_8h.html#ace4f4ba6e7a13f1a9db20e6605a786bd", null ]
    ] ],
    [ "SCICTL1_BITS", "_d_s_p2803x___sci_8h.html#struct_s_c_i_c_t_l1___b_i_t_s", [
      [ "rsvd", "_d_s_p2803x___sci_8h.html#a77dd158aa2881ac1d462c1c7fd2e74af", null ],
      [ "rsvd1", "_d_s_p2803x___sci_8h.html#ab1d37fda1bfdb4bacb07228b21f27499", null ],
      [ "RXENA", "_d_s_p2803x___sci_8h.html#a13bf886b1b621f0e9ae312a24d849c76", null ],
      [ "RXERRINTENA", "_d_s_p2803x___sci_8h.html#aef11fe82746f6d9e72517a24a5463ec0", null ],
      [ "SLEEP", "_d_s_p2803x___sci_8h.html#ad43cc24495aa5d6a373b78bcb400781a", null ],
      [ "SWRESET", "_d_s_p2803x___sci_8h.html#a8e8db58883800d100a7b2a8377067445", null ],
      [ "TXENA", "_d_s_p2803x___sci_8h.html#a033c62efc7475bb7e662bce4be705cd7", null ],
      [ "TXWAKE", "_d_s_p2803x___sci_8h.html#af3b1d1ace1efe6a5f380d3e6635b1148", null ]
    ] ],
    [ "SCICTL1_REG", "_d_s_p2803x___sci_8h.html#union_s_c_i_c_t_l1___r_e_g", [
      [ "all", "_d_s_p2803x___sci_8h.html#a10d67e17c0e836cd554f6b8b0691717f", null ],
      [ "bit", "_d_s_p2803x___sci_8h.html#a67bbff8cb4b51339444a7e9f04a78ea2", null ]
    ] ],
    [ "SCICTL2_BITS", "_d_s_p2803x___sci_8h.html#struct_s_c_i_c_t_l2___b_i_t_s", [
      [ "rsvd", "_d_s_p2803x___sci_8h.html#a1cf83e4a3f981e2271cba4b3b203f14c", null ],
      [ "rsvd1", "_d_s_p2803x___sci_8h.html#a238c5945b0b08c11431d0e3579df9f29", null ],
      [ "RXBKINTENA", "_d_s_p2803x___sci_8h.html#afb52fadf6a85fb81ec45feb5462c6f2c", null ],
      [ "TXEMPTY", "_d_s_p2803x___sci_8h.html#ac0f9bcf6d34edf35024dd37e9b5a07cc", null ],
      [ "TXINTENA", "_d_s_p2803x___sci_8h.html#af8fa2544ee6ef6724d617ff68a5a32fa", null ],
      [ "TXRDY", "_d_s_p2803x___sci_8h.html#a1422489e431e53a8cfbc45e1ef31c882", null ]
    ] ],
    [ "SCICTL2_REG", "_d_s_p2803x___sci_8h.html#union_s_c_i_c_t_l2___r_e_g", [
      [ "all", "_d_s_p2803x___sci_8h.html#a3a7b11e1404c3ce015bfbcfe282a8c51", null ],
      [ "bit", "_d_s_p2803x___sci_8h.html#afe3da813662a0c730f4be6822dfa09e9", null ]
    ] ],
    [ "SCIRXST_BITS", "_d_s_p2803x___sci_8h.html#struct_s_c_i_r_x_s_t___b_i_t_s", [
      [ "BRKDT", "_d_s_p2803x___sci_8h.html#ab3f2cd112a18adfd3242f5cb550fea60", null ],
      [ "FE", "_d_s_p2803x___sci_8h.html#aced19690707a651351d981abb21bf510", null ],
      [ "OE", "_d_s_p2803x___sci_8h.html#aff0f70440e0c71c2de5fc2c937f11b83", null ],
      [ "PE", "_d_s_p2803x___sci_8h.html#a073eb89f2348c361ea8411127510f6ee", null ],
      [ "rsvd", "_d_s_p2803x___sci_8h.html#a94e41dd6ba5e5be3d63c52db6e9a5fa5", null ],
      [ "rsvd1", "_d_s_p2803x___sci_8h.html#a4bc0c4451bfa6ef974fbf9565e11f4b6", null ],
      [ "RXERROR", "_d_s_p2803x___sci_8h.html#a2bd58567c90a377aa8f7261f7fe35275", null ],
      [ "RXRDY", "_d_s_p2803x___sci_8h.html#a8a137e6a747464d144dc0a6a39f42143", null ],
      [ "RXWAKE", "_d_s_p2803x___sci_8h.html#a924f49b75a354701a7b1aa0914b727dd", null ]
    ] ],
    [ "SCIRXST_REG", "_d_s_p2803x___sci_8h.html#union_s_c_i_r_x_s_t___r_e_g", [
      [ "all", "_d_s_p2803x___sci_8h.html#ad062a1410be1a74863f62fbf56416a0a", null ],
      [ "bit", "_d_s_p2803x___sci_8h.html#ac508c405e6a03c4408d263ac38dec492", null ]
    ] ],
    [ "SCIRXBUF_BITS", "_d_s_p2803x___sci_8h.html#struct_s_c_i_r_x_b_u_f___b_i_t_s", [
      [ "rsvd", "_d_s_p2803x___sci_8h.html#a134834a896673cca9281cb0534d024ac", null ],
      [ "RXDT", "_d_s_p2803x___sci_8h.html#ad2631cf7cb2d2416642c781944964633", null ],
      [ "SCIFFFE", "_d_s_p2803x___sci_8h.html#af6a12445c5713a479b1d78e5e7389814", null ],
      [ "SCIFFPE", "_d_s_p2803x___sci_8h.html#aa759f441f29b63c2f16820c5823a2b41", null ]
    ] ],
    [ "SCIRXBUF_REG", "_d_s_p2803x___sci_8h.html#union_s_c_i_r_x_b_u_f___r_e_g", [
      [ "all", "_d_s_p2803x___sci_8h.html#a826b7f9937aa686977fc1196a6ea12a1", null ],
      [ "bit", "_d_s_p2803x___sci_8h.html#ac138f9553b89709d5c3357d91cb76fa7", null ]
    ] ],
    [ "SCIPRI_BITS", "_d_s_p2803x___sci_8h.html#struct_s_c_i_p_r_i___b_i_t_s", [
      [ "FREE", "_d_s_p2803x___sci_8h.html#ac5e342523375f1fc1086a9bd7f61ad48", null ],
      [ "rsvd", "_d_s_p2803x___sci_8h.html#a9f2d1bf2eb826466f5d7cb54363ec80b", null ],
      [ "rsvd1", "_d_s_p2803x___sci_8h.html#a935e596af893352ddad6dfaa86edc37c", null ],
      [ "SOFT", "_d_s_p2803x___sci_8h.html#a5c1ce51b9351b53aaad1820b05bfac78", null ]
    ] ],
    [ "SCIPRI_REG", "_d_s_p2803x___sci_8h.html#union_s_c_i_p_r_i___r_e_g", [
      [ "all", "_d_s_p2803x___sci_8h.html#ae92693e512779682a5c9ce21ca033d06", null ],
      [ "bit", "_d_s_p2803x___sci_8h.html#abf08bad99c6da8059f652b7fbe8063e4", null ]
    ] ],
    [ "SCIFFTX_BITS", "_d_s_p2803x___sci_8h.html#struct_s_c_i_f_f_t_x___b_i_t_s", [
      [ "SCIFFENA", "_d_s_p2803x___sci_8h.html#aa222d51751c0ca83a39fd75de09f45b5", null ],
      [ "SCIRST", "_d_s_p2803x___sci_8h.html#a92ed676cd52a93dee1baeca8d12a7282", null ],
      [ "TXFFIENA", "_d_s_p2803x___sci_8h.html#a75d59a05ddc31554684e69ffd7bb1a8a", null ],
      [ "TXFFIL", "_d_s_p2803x___sci_8h.html#a55f8a91cab6f1afd110415beb355d4ab", null ],
      [ "TXFFINT", "_d_s_p2803x___sci_8h.html#a3c595743b8d4c7227f780ea61780f75f", null ],
      [ "TXFFINTCLR", "_d_s_p2803x___sci_8h.html#af2466704b9d20ca19c3c53c8999380fc", null ],
      [ "TXFFST", "_d_s_p2803x___sci_8h.html#a87de1dbdea0ea037e52471bc82537a4d", null ],
      [ "TXFIFOXRESET", "_d_s_p2803x___sci_8h.html#af03d54ce2400814bd1d9916f44ad9e6c", null ]
    ] ],
    [ "SCIFFTX_REG", "_d_s_p2803x___sci_8h.html#union_s_c_i_f_f_t_x___r_e_g", [
      [ "all", "_d_s_p2803x___sci_8h.html#aa502914ae7b85bb69e48335b06694aae", null ],
      [ "bit", "_d_s_p2803x___sci_8h.html#aa6e3413a407862cdf89298e9eccb7ed9", null ]
    ] ],
    [ "SCIFFRX_BITS", "_d_s_p2803x___sci_8h.html#struct_s_c_i_f_f_r_x___b_i_t_s", [
      [ "RXFFIENA", "_d_s_p2803x___sci_8h.html#ae38e80f9a664244eb6ad93296edc8b0f", null ],
      [ "RXFFIL", "_d_s_p2803x___sci_8h.html#aa60e481ac2ef54f12fb4f7a9bc593a31", null ],
      [ "RXFFINT", "_d_s_p2803x___sci_8h.html#aa97a9fb1430f936f8653de0f73a31cb5", null ],
      [ "RXFFINTCLR", "_d_s_p2803x___sci_8h.html#a8e99a9cfd20fd40b5580bfc22a2b17a4", null ],
      [ "RXFFOVF", "_d_s_p2803x___sci_8h.html#aae121f19b02db2864a6d2b56deea5041", null ],
      [ "RXFFOVRCLR", "_d_s_p2803x___sci_8h.html#affe11c779bce6ee64d76075a8a9f6a79", null ],
      [ "RXFFST", "_d_s_p2803x___sci_8h.html#a93b059775a44a47fffc957d51483504f", null ],
      [ "RXFIFORESET", "_d_s_p2803x___sci_8h.html#a7d1d1dbf7c40ada7de65f9a06f8f3f51", null ]
    ] ],
    [ "SCIFFRX_REG", "_d_s_p2803x___sci_8h.html#union_s_c_i_f_f_r_x___r_e_g", [
      [ "all", "_d_s_p2803x___sci_8h.html#adf2dd00b328fea5e4cf785fc452edcbf", null ],
      [ "bit", "_d_s_p2803x___sci_8h.html#a1ad0fa52694365601b2334ddad6d1b2e", null ]
    ] ],
    [ "SCIFFCT_BITS", "_d_s_p2803x___sci_8h.html#struct_s_c_i_f_f_c_t___b_i_t_s", [
      [ "ABD", "_d_s_p2803x___sci_8h.html#a23c1a8b8108f23c2f2a5840cb2d0ea53", null ],
      [ "ABDCLR", "_d_s_p2803x___sci_8h.html#a610f4b8b72baf4dc1846fb06dede3b2c", null ],
      [ "CDC", "_d_s_p2803x___sci_8h.html#ae1972f624fbddcf5e1fe8be0b4161ef9", null ],
      [ "FFTXDLY", "_d_s_p2803x___sci_8h.html#adcb0aa7cb2ac44f1aaaf9fd93c18523d", null ],
      [ "rsvd", "_d_s_p2803x___sci_8h.html#a91647d829e81f817d8e1b4464772483f", null ]
    ] ],
    [ "SCIFFCT_REG", "_d_s_p2803x___sci_8h.html#union_s_c_i_f_f_c_t___r_e_g", [
      [ "all", "_d_s_p2803x___sci_8h.html#a360f6ab6bc205c99e2d97eefc2c191cc", null ],
      [ "bit", "_d_s_p2803x___sci_8h.html#a5d6019f4fd4b79743fc70bd67f938d58", null ]
    ] ],
    [ "SCI_REGS", "_d_s_p2803x___sci_8h.html#struct_s_c_i___r_e_g_s", [
      [ "rsvd1", "_d_s_p2803x___sci_8h.html#a3bf86ce470473e0229ea0ce6fdb59526", null ],
      [ "rsvd2", "_d_s_p2803x___sci_8h.html#a60904f5f14eaeec9260b9361452ab37d", null ],
      [ "rsvd3", "_d_s_p2803x___sci_8h.html#abac0120a449878bec0347a7833715e4c", null ],
      [ "SCICCR", "_d_s_p2803x___sci_8h.html#a04b57420d9dc62d4c35e3e2696ae3e69", null ],
      [ "SCICTL1", "_d_s_p2803x___sci_8h.html#a0508ccf2f96b6c037e871c468ce482a6", null ],
      [ "SCICTL2", "_d_s_p2803x___sci_8h.html#a6f48ff2c3d3daa6ce0e9bb20f21c3511", null ],
      [ "SCIFFCT", "_d_s_p2803x___sci_8h.html#ace91fa8ec0feb3956cf2da152a9a9e98", null ],
      [ "SCIFFRX", "_d_s_p2803x___sci_8h.html#a04926a820c9486f52c09f3d90d9d76f2", null ],
      [ "SCIFFTX", "_d_s_p2803x___sci_8h.html#a257a51c8ae0fdcb770687842f0092e5e", null ],
      [ "SCIHBAUD", "_d_s_p2803x___sci_8h.html#a52203d53359508a3bd26bdece3281269", null ],
      [ "SCILBAUD", "_d_s_p2803x___sci_8h.html#ad044f4e55fc52cd387a42ecc9fa6db60", null ],
      [ "SCIPRI", "_d_s_p2803x___sci_8h.html#a5691c96c52204e22f1397717184e1762", null ],
      [ "SCIRXBUF", "_d_s_p2803x___sci_8h.html#a1a5ac923fd73b377afab87292089ed5d", null ],
      [ "SCIRXEMU", "_d_s_p2803x___sci_8h.html#ad9c5c8dd182d7a3899e4e496c709ebfc", null ],
      [ "SCIRXST", "_d_s_p2803x___sci_8h.html#a1e4af82f9810bbdfa98a24399167499f", null ],
      [ "SCITXBUF", "_d_s_p2803x___sci_8h.html#a1830faf4f46a7ac90a15fdde0b809175", null ]
    ] ],
    [ "SciaRegs", "_d_s_p2803x___sci_8h.html#a40b58fa93193481b7abc921c40148603", null ]
];