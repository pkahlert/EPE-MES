var rampgen_8h =
[
    [ "RAMPGEN", "rampgen_8h.html#struct_r_a_m_p_g_e_n", [
      [ "Angle", "rampgen_8h.html#ad431d4f2ecee29183df1f97c47adf468", null ],
      [ "Freq", "rampgen_8h.html#aa715736dfa433206425fa6baf1e73c1d", null ],
      [ "Gain", "rampgen_8h.html#a2e6215751479c3cd63c40dd46a7e67c3", null ],
      [ "Offset", "rampgen_8h.html#a5f3884a369e80178e45fc8e5eeec0a60", null ],
      [ "Out", "rampgen_8h.html#ad0c7875c40a37c45192f12b77979abe6", null ],
      [ "StepAngleMax", "rampgen_8h.html#a475ad858d1a6a388f3c13650de25ee4a", null ]
    ] ],
    [ "RAMPGEN_DEFAULTS", "rampgen_8h.html#aea16e8d0941842519654314cbcb642e1", null ],
    [ "RG_MACRO", "rampgen_8h.html#ac3bff55a213845ec6699b019923231f9", null ],
    [ "if", "rampgen_8h.html#aabbfb2fd31e06a4d8524b916834c98a1", null ],
    [ "if", "rampgen_8h.html#a0dddb683eef20abb9dc8c7f8cde50b9b", null ],
    [ "Out", "rampgen_8h.html#a736e87ee3d5b0ce2d1584e7ab65440bc", null ]
];