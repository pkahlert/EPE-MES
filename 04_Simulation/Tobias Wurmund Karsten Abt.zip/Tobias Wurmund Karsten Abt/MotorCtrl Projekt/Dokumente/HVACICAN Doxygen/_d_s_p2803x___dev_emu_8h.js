var _d_s_p2803x___dev_emu_8h =
[
    [ "DEVICECNF_BITS", "_d_s_p2803x___dev_emu_8h.html#struct_d_e_v_i_c_e_c_n_f___b_i_t_s", [
      [ "ENPROT", "_d_s_p2803x___dev_emu_8h.html#a2f50c10f77afeb0cf2db8191b085a7ff", null ],
      [ "PINOUTSELPUD", "_d_s_p2803x___dev_emu_8h.html#a4b0dc13567dfb3d19480e79007c2d470", null ],
      [ "PINOUTSELSTS", "_d_s_p2803x___dev_emu_8h.html#a1ee783d64cc1f521477126ec4568288c", null ],
      [ "rsvd1", "_d_s_p2803x___dev_emu_8h.html#ae8cef22ca41902e78fc1c91daf13d038", null ],
      [ "rsvd2", "_d_s_p2803x___dev_emu_8h.html#a6b6eee8a0524790d8c7cd261635eb8a3", null ],
      [ "rsvd3", "_d_s_p2803x___dev_emu_8h.html#a16b53bdecc8c80d4598b82594bda9e16", null ],
      [ "rsvd4", "_d_s_p2803x___dev_emu_8h.html#a428d8e39930d521963256ce62b99ebf5", null ],
      [ "rsvd5", "_d_s_p2803x___dev_emu_8h.html#a82b1403a3f13b7b436d5c44162675380", null ],
      [ "rsvd6", "_d_s_p2803x___dev_emu_8h.html#a3c1be2b3c09702cd4cd791212eb1de97", null ],
      [ "TRSTn", "_d_s_p2803x___dev_emu_8h.html#a93d0ef37194bbe5b2aa633ae6ecd15cb", null ],
      [ "VMAPS", "_d_s_p2803x___dev_emu_8h.html#a14af9e21e021a1b3aef54add60dfe524", null ],
      [ "XRSn", "_d_s_p2803x___dev_emu_8h.html#a538fb89b1cd0fddbb9a5e3e2b0699a21", null ]
    ] ],
    [ "DEVICECNF_REG", "_d_s_p2803x___dev_emu_8h.html#union_d_e_v_i_c_e_c_n_f___r_e_g", [
      [ "all", "_d_s_p2803x___dev_emu_8h.html#acc04b119f54ccbaedc4e712bbec732b3", null ],
      [ "bit", "_d_s_p2803x___dev_emu_8h.html#a903d04047b135357d6349d10de0faf89", null ]
    ] ],
    [ "CLASSID_BITS", "_d_s_p2803x___dev_emu_8h.html#struct_c_l_a_s_s_i_d___b_i_t_s", [
      [ "CLASSNO", "_d_s_p2803x___dev_emu_8h.html#a670b6a7265cf7c6fc73b34b10238f44a", null ],
      [ "PARTTYPE", "_d_s_p2803x___dev_emu_8h.html#a247e66d573cba33b18a80365f31f0d33", null ]
    ] ],
    [ "CLASSID_REG", "_d_s_p2803x___dev_emu_8h.html#union_c_l_a_s_s_i_d___r_e_g", [
      [ "all", "_d_s_p2803x___dev_emu_8h.html#aeacdc65d1b605acc308ef342700b6e73", null ],
      [ "bit", "_d_s_p2803x___dev_emu_8h.html#a7eec29a68b26d93dc778896c6b9ec770", null ]
    ] ],
    [ "DEV_EMU_REGS", "_d_s_p2803x___dev_emu_8h.html#struct_d_e_v___e_m_u___r_e_g_s", [
      [ "CLASSID", "_d_s_p2803x___dev_emu_8h.html#add72da3c7f106a7e43ca2dfeb6dedaa0", null ],
      [ "DEVICECNF", "_d_s_p2803x___dev_emu_8h.html#a1272c5ac872de25b46ab509646cf11cc", null ],
      [ "REVID", "_d_s_p2803x___dev_emu_8h.html#ab3b9758bbe253258d9544e41fb43a4a8", null ]
    ] ],
    [ "PARTID_BITS", "_d_s_p2803x___dev_emu_8h.html#struct_p_a_r_t_i_d___b_i_t_s", [
      [ "PARTNO", "_d_s_p2803x___dev_emu_8h.html#aa85a2e08202f6b7ceb915f11cf1afd6b", null ],
      [ "PARTTYPE", "_d_s_p2803x___dev_emu_8h.html#ab5a5d03b6a744544fde167d56ac539e2", null ]
    ] ],
    [ "PARTID_REG", "_d_s_p2803x___dev_emu_8h.html#union_p_a_r_t_i_d___r_e_g", [
      [ "all", "_d_s_p2803x___dev_emu_8h.html#abb8db0d07a4e605bbf7371465b3d00a8", null ],
      [ "bit", "_d_s_p2803x___dev_emu_8h.html#ac0732748fb6314820c25e008cf228a31", null ]
    ] ],
    [ "PARTID_REGS", "_d_s_p2803x___dev_emu_8h.html#struct_p_a_r_t_i_d___r_e_g_s", [
      [ "PARTID", "_d_s_p2803x___dev_emu_8h.html#a853a13509e25954cd904039ec17aea15", null ]
    ] ],
    [ "DevEmuRegs", "_d_s_p2803x___dev_emu_8h.html#a310cda0d4b9daed5ca1c141dc27e414a", null ],
    [ "PartIdRegs", "_d_s_p2803x___dev_emu_8h.html#a21511cfff867b6b8e948214603efcec2", null ]
];