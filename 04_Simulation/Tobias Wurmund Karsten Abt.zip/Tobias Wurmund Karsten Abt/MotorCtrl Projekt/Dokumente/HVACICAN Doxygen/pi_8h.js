var pi_8h =
[
    [ "PI_CONTROLLER", "pi_8h.html#struct_p_i___c_o_n_t_r_o_l_l_e_r", [
      [ "Fbk", "pi_8h.html#ab5bc9f1f6b1a5a800da3709b114df50b", null ],
      [ "i1", "pi_8h.html#a4a586811490da68fcf66b1d51069a334", null ],
      [ "Ki", "pi_8h.html#a1a2f30936583f3a26eaf5e00dd86c693", null ],
      [ "Kp", "pi_8h.html#a6734e4f2c06f0d6e2c395394ce6f5a08", null ],
      [ "Out", "pi_8h.html#aca101fdfc6fc1f0a84d78136f3759279", null ],
      [ "Ref", "pi_8h.html#aa9624ce8f133ff7cf5c320384df3562f", null ],
      [ "ui", "pi_8h.html#af99c034f47e0d34e97501ae81d02cc72", null ],
      [ "Umax", "pi_8h.html#a898dee41b3bd0589dadfe34019945603", null ],
      [ "Umin", "pi_8h.html#a3e6adf52de61222c4cc675ba54a46966", null ],
      [ "up", "pi_8h.html#aba73a6f34c032ac9ce73fa6c67d9b8c8", null ],
      [ "v1", "pi_8h.html#a5ffb0414ee97a7be2efb7df0d9d63ff0", null ],
      [ "w1", "pi_8h.html#a7770fdc22d99f513d26a7af45779b137", null ]
    ] ],
    [ "PI_CONTROLLER_DEFAULTS", "pi_8h.html#a207adf24dfe596984409ce4042103787", null ],
    [ "PI_MACRO", "pi_8h.html#a120043008c33417ff7bc850341738b13", null ]
];