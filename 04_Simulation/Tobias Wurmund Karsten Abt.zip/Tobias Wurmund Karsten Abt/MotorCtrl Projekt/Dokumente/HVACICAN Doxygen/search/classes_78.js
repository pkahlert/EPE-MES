var searchData=
[
  ['xclk_5fbits',['XCLK_BITS',['../_d_s_p2803x___sys_ctrl_8h.html#struct_x_c_l_k___b_i_t_s',1,'']]],
  ['xclk_5freg',['XCLK_REG',['../_d_s_p2803x___sys_ctrl_8h.html#union_x_c_l_k___r_e_g',1,'']]],
  ['xintcr_5fbits',['XINTCR_BITS',['../_d_s_p2803x___x_intrupt_8h.html#struct_x_i_n_t_c_r___b_i_t_s',1,'']]],
  ['xintcr_5freg',['XINTCR_REG',['../_d_s_p2803x___x_intrupt_8h.html#union_x_i_n_t_c_r___r_e_g',1,'']]],
  ['xintrupt_5fregs',['XINTRUPT_REGS',['../_d_s_p2803x___x_intrupt_8h.html#struct_x_i_n_t_r_u_p_t___r_e_g_s',1,'']]]
];
