var searchData=
[
  ['vhz_5fprof_5fmacro',['VHZ_PROF_MACRO',['../vhzprof_8h.html#a05d5ebafd715dc58756d09d02bd653fc',1,'vhzprof.h']]],
  ['vhzprof_5fdefaults',['VHZPROF_DEFAULTS',['../vhzprof_8h.html#ac841e1e7770d9684c3449b10c50347da',1,'vhzprof.h']]]
];
