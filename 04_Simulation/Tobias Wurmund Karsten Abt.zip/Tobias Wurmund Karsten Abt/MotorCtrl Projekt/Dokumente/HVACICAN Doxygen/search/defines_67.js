var searchData=
[
  ['global_5fq',['GLOBAL_Q',['../_i_qmath_lib_8h.html#aac4f967e7a5f28202e11c0b1d2c33adf',1,'IQmathLib.h']]]
];
