var searchData=
[
  ['borcfg_5fbits',['BORCFG_BITS',['../_d_s_p2803x___sys_ctrl_8h.html#struct_b_o_r_c_f_g___b_i_t_s',1,'']]],
  ['borcfg_5freg',['BORCFG_REG',['../_d_s_p2803x___sys_ctrl_8h.html#union_b_o_r_c_f_g___r_e_g',1,'']]],
  ['brsr_5fbits',['BRSR_BITS',['../_d_s_p2803x___lin_8h.html#struct_b_r_s_r___b_i_t_s',1,'']]],
  ['brsr_5freg',['BRSR_REG',['../_d_s_p2803x___lin_8h.html#union_b_r_s_r___r_e_g',1,'']]]
];
