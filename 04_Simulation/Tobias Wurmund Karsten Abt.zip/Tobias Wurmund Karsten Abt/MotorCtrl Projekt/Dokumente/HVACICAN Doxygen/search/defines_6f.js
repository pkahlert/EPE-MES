var searchData=
[
  ['one_5fthird',['ONE_THIRD',['../volt__calc_8h.html#a15511e218df6cdf9548c316d01c7180c',1,'volt_calc.h']]]
];
