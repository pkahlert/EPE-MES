var com__trig_8h =
[
    [ "CMTN", "com__trig_8h.html#struct_c_m_t_n", [
      [ "CmtnDelay", "com__trig_8h.html#aa10b4fc6071eca981ce48f3e02b968ca", null ],
      [ "CmtnDelayCounter", "com__trig_8h.html#af2acba1d8215ada24a7a1aa6de65a3b9", null ],
      [ "CmtnPointer", "com__trig_8h.html#a8588c21d854bc52a8c65d5b5f57701cd", null ],
      [ "CmtnTrig", "com__trig_8h.html#a9125e83f2112fcb899711e1f5a3bbb36", null ],
      [ "DebugBemf", "com__trig_8h.html#a4d569f5457537a80b0fd78ee1b1f7567", null ],
      [ "Delay30DoneFlag", "com__trig_8h.html#a34a36cc94106bb79d6fa071cc35ef99d", null ],
      [ "DelayTaskPointer", "com__trig_8h.html#a9504ecf3c5f0693f6daf7813488b1e90", null ],
      [ "GPR1_COM_TRIG", "com__trig_8h.html#a6d7a9ac5cb35bf5b1c2f8947eb49c139", null ],
      [ "Neutral", "com__trig_8h.html#a994b3c22bbb5fb3399d8e4203cd07c0d", null ],
      [ "NewTimeStamp", "com__trig_8h.html#a491b22f7efb98da59926cc38a8f4f275", null ],
      [ "NoiseWindowCounter", "com__trig_8h.html#acc5ca50104e2ec161e2c7f09e3319ce4", null ],
      [ "NoiseWindowMax", "com__trig_8h.html#a203f285f7a97f2ec7073f1cfdf10de43", null ],
      [ "NWDelayThres", "com__trig_8h.html#a0047db101c1f8c08614b501ca1a5aeac", null ],
      [ "NWDelta", "com__trig_8h.html#a4bd33332fb9c0fd07ae6f1262a369677", null ],
      [ "OldTimeStamp", "com__trig_8h.html#a340e3b779bec9a57f46618a95e3edbb1", null ],
      [ "RevPeriod", "com__trig_8h.html#a60589f5b82d54e8823bd701e4ba09f71", null ],
      [ "Tmp", "com__trig_8h.html#a0e6a94104dd3c99ac4ea518042ab4ad7", null ],
      [ "Va", "com__trig_8h.html#abd410086166441c90330c68d66048910", null ],
      [ "Vb", "com__trig_8h.html#a8d9ab515b1ce8d0bcd6fe224a0692141", null ],
      [ "Vc", "com__trig_8h.html#aebf8d80e604f2fe0d932d2169e809ae3", null ],
      [ "VirtualTimer", "com__trig_8h.html#a6f76dcce1c8dd3ce5e4684de361bbf52", null ],
      [ "ZcTrig", "com__trig_8h.html#a42951f2eb5f7c2d6849d9d4e814be957", null ]
    ] ],
    [ "CMTN_DEFAULTS", "com__trig_8h.html#a71f6efae429adc7ea8bc4e543793afe7", null ],
    [ "CMTN_TRIG_MACRO", "com__trig_8h.html#a25c194c81fc80d47584aeb610cd6bc50", null ],
    [ "DELAY_30DEG_MACRO", "com__trig_8h.html#a0c0a28d08bce02442ea3531fc8dde199", null ],
    [ "NOISE_WINDOW_CNT_MACRO", "com__trig_8h.html#ac5c94799783235e3d50f02c06f64e04e", null ]
];