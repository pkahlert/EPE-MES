var cur__const_8h =
[
    [ "CURMOD_CONST", "cur__const_8h.html#struct_c_u_r_m_o_d___c_o_n_s_t", [
      [ "fb", "cur__const_8h.html#abfb9d35e628c68f16231f108b02eca8e", null ],
      [ "K", "cur__const_8h.html#a41363abc16099ffa39861558580f3e29", null ],
      [ "Kr", "cur__const_8h.html#a6bd5c91101dd4f44b860163c999744f9", null ],
      [ "Kt", "cur__const_8h.html#ab81814a55692f20e28bdd33d133cfd31", null ],
      [ "Lr", "cur__const_8h.html#a7013698545d064b211501c2347f80061", null ],
      [ "Rr", "cur__const_8h.html#a326b6889f6ee5b0c630a4419156f5925", null ],
      [ "Tr", "cur__const_8h.html#a6dbf9476ae6dcd6afbfc0a93a5820d0d", null ],
      [ "Ts", "cur__const_8h.html#ad4fa1c294bb6698b3c82869c4193987c", null ]
    ] ],
    [ "CUR_CONST_MACRO", "cur__const_8h.html#ad7073a0a06d1e613bb2dc0738f782fbd", null ],
    [ "CURMOD_CONST_DEFAULTS", "cur__const_8h.html#a6a3b6a874b4a58258eca4495ae1bc737", null ],
    [ "PI", "cur__const_8h.html#a598a3330b3c21701223ee0ca14316eca", null ]
];