var _d_s_p2803x___h_r_cap_8h =
[
    [ "HCCTL_BITS", "_d_s_p2803x___h_r_cap_8h.html#struct_h_c_c_t_l___b_i_t_s", [
      [ "FALLINTE", "_d_s_p2803x___h_r_cap_8h.html#aa4f1ba116fd21e85e9f3c1c3dd65bceb", null ],
      [ "HCCAPCLKSEL", "_d_s_p2803x___h_r_cap_8h.html#a057e20ba0ff82a563805ce7394335b2f", null ],
      [ "OVFINTE", "_d_s_p2803x___h_r_cap_8h.html#afb2b259064a307bc60adc2af02b55ac8", null ],
      [ "RISEINTE", "_d_s_p2803x___h_r_cap_8h.html#a52be8dbafb37fd7d876d95629f0b6fd1", null ],
      [ "rsvd1", "_d_s_p2803x___h_r_cap_8h.html#a6894ee6f018357c0cf7000100cb99c26", null ],
      [ "rsvd2", "_d_s_p2803x___h_r_cap_8h.html#a37c2b239bf14803b5a2cc0839ab53df5", null ],
      [ "SOFTRESET", "_d_s_p2803x___h_r_cap_8h.html#a94cc6dd93a5d843fac928c0098ec38f1", null ]
    ] ],
    [ "HCCTL_REG", "_d_s_p2803x___h_r_cap_8h.html#union_h_c_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___h_r_cap_8h.html#a850e9a618d50316f73cc582fd1938957", null ],
      [ "bit", "_d_s_p2803x___h_r_cap_8h.html#ac3e82289a28515b0a0e85f70c530914a", null ]
    ] ],
    [ "HCIFR_BITS", "_d_s_p2803x___h_r_cap_8h.html#struct_h_c_i_f_r___b_i_t_s", [
      [ "COUNTEROVF", "_d_s_p2803x___h_r_cap_8h.html#a20e0debcd580d5c2a8e065a0a3d9b2db", null ],
      [ "FALL", "_d_s_p2803x___h_r_cap_8h.html#a603a49cf8f12e1fddecd83e39edcc2d3", null ],
      [ "INT", "_d_s_p2803x___h_r_cap_8h.html#acbcdc620055010c73ab9247af0e413a7", null ],
      [ "RISE", "_d_s_p2803x___h_r_cap_8h.html#a5ecee803138e4491bd75af95d5643127", null ],
      [ "RISEOVF", "_d_s_p2803x___h_r_cap_8h.html#a9363be568ddd871676ce15c99b69703b", null ],
      [ "rsvd1", "_d_s_p2803x___h_r_cap_8h.html#a9575e9c7e1341b62d9b411da451494f7", null ]
    ] ],
    [ "HCIFR_REG", "_d_s_p2803x___h_r_cap_8h.html#union_h_c_i_f_r___r_e_g", [
      [ "all", "_d_s_p2803x___h_r_cap_8h.html#aabc3d69a84b6fbba51e9e32894deafa3", null ],
      [ "bit", "_d_s_p2803x___h_r_cap_8h.html#aca1a4368ed866ee72022b936ba8feeb7", null ]
    ] ],
    [ "HCICLR_BITS", "_d_s_p2803x___h_r_cap_8h.html#struct_h_c_i_c_l_r___b_i_t_s", [
      [ "COUNTEROVF", "_d_s_p2803x___h_r_cap_8h.html#a523833601b0289415f86756ec0812da5", null ],
      [ "FALL", "_d_s_p2803x___h_r_cap_8h.html#a560b778a8f40954a72bc52023816520d", null ],
      [ "INT", "_d_s_p2803x___h_r_cap_8h.html#aebe4baf06920dd2287cb8dc5c7f9f007", null ],
      [ "RISE", "_d_s_p2803x___h_r_cap_8h.html#a7f12d34a468513b70de0295fcffcd56c", null ],
      [ "RISEOVF", "_d_s_p2803x___h_r_cap_8h.html#a9784fe04e543022e1967ddad290840e7", null ],
      [ "rsvd1", "_d_s_p2803x___h_r_cap_8h.html#a7ff3d4cf8c72f6e67eba231404805059", null ]
    ] ],
    [ "HCICLR_REG", "_d_s_p2803x___h_r_cap_8h.html#union_h_c_i_c_l_r___r_e_g", [
      [ "all", "_d_s_p2803x___h_r_cap_8h.html#aa8c51740a028f50ee19d2ea56e92b795", null ],
      [ "bit", "_d_s_p2803x___h_r_cap_8h.html#aa07e5e58589611345c23c053e38ee21a", null ]
    ] ],
    [ "HCIFRC_BITS", "_d_s_p2803x___h_r_cap_8h.html#struct_h_c_i_f_r_c___b_i_t_s", [
      [ "COUNTEROVF", "_d_s_p2803x___h_r_cap_8h.html#ab31b0424ddd35e48fa9f4424917bb504", null ],
      [ "FALL", "_d_s_p2803x___h_r_cap_8h.html#a3e0421ea24271c4e2fa1b911cc1ce164", null ],
      [ "RISE", "_d_s_p2803x___h_r_cap_8h.html#af5823662e298dc28765f5516680170aa", null ],
      [ "RISEOVF", "_d_s_p2803x___h_r_cap_8h.html#aa239b5abf80e2c407e52f1c110d8b29e", null ],
      [ "rsvd1", "_d_s_p2803x___h_r_cap_8h.html#a85da9b233be414d6ec539c70b65b205f", null ],
      [ "rsvd2", "_d_s_p2803x___h_r_cap_8h.html#a9a63fd34c3fe235b264675c4997abe5d", null ]
    ] ],
    [ "HCIFRC_REG", "_d_s_p2803x___h_r_cap_8h.html#union_h_c_i_f_r_c___r_e_g", [
      [ "all", "_d_s_p2803x___h_r_cap_8h.html#addb26ded92fafe605c59b122b961ee7f", null ],
      [ "bit", "_d_s_p2803x___h_r_cap_8h.html#a2206476b005f9187c4d90622bb3bc8fc", null ]
    ] ],
    [ "HRCAP_REGS", "_d_s_p2803x___h_r_cap_8h.html#struct_h_r_c_a_p___r_e_g_s", [
      [ "HCCAPCNTFALL0", "_d_s_p2803x___h_r_cap_8h.html#aa54b6a18fe490c88662ecd5f253ab5c3", null ],
      [ "HCCAPCNTFALL1", "_d_s_p2803x___h_r_cap_8h.html#ac64c2e3fca5bba67a0e55488b623bdf8", null ],
      [ "HCCAPCNTRISE0", "_d_s_p2803x___h_r_cap_8h.html#a4fa64bc6d4a6e6d58327b4bd5d86dc80", null ],
      [ "HCCAPCNTRISE1", "_d_s_p2803x___h_r_cap_8h.html#a8e052a39105f89bd6589ae9a7f6d3625", null ],
      [ "HCCOUNTER", "_d_s_p2803x___h_r_cap_8h.html#a1fcbcffd32e0850cff54dd5ec367e83e", null ],
      [ "HCCTL", "_d_s_p2803x___h_r_cap_8h.html#a90da04bba964407ebd5be24690f07ec8", null ],
      [ "HCICLR", "_d_s_p2803x___h_r_cap_8h.html#a219fb21ffc7e5f2c067552f260cff264", null ],
      [ "HCIFR", "_d_s_p2803x___h_r_cap_8h.html#a0d5ffdd546fee6829a784f07609f1187", null ],
      [ "HCIFRC", "_d_s_p2803x___h_r_cap_8h.html#a5b0b77344745e7cc08c88d8fbd593cc1", null ],
      [ "rsvd1", "_d_s_p2803x___h_r_cap_8h.html#aeefa529d051dae0e5d5fd6cd2f0580d5", null ],
      [ "rsvd10", "_d_s_p2803x___h_r_cap_8h.html#a10561e03ebfb8240b4ee24a58860759c", null ],
      [ "rsvd11", "_d_s_p2803x___h_r_cap_8h.html#a418e658214a84358e40859b132e4f26b", null ],
      [ "rsvd12", "_d_s_p2803x___h_r_cap_8h.html#a76e324d41ebc88d4612ac838e91043d5", null ],
      [ "rsvd2", "_d_s_p2803x___h_r_cap_8h.html#a1d0d13cd9fa4834bf66dd348cf98680a", null ],
      [ "rsvd3", "_d_s_p2803x___h_r_cap_8h.html#a746ed9ebee0d9ea06a3dc16f3d22e7b9", null ],
      [ "rsvd4", "_d_s_p2803x___h_r_cap_8h.html#a463b0959c0c4a83abc0e6f72ee747022", null ],
      [ "rsvd5", "_d_s_p2803x___h_r_cap_8h.html#af41c9770a2f59a5de194228ad55afde9", null ],
      [ "rsvd6", "_d_s_p2803x___h_r_cap_8h.html#ad89d2525f836b76ceb864b58b1e131e8", null ],
      [ "rsvd7", "_d_s_p2803x___h_r_cap_8h.html#a7775491ad81a08888e4b10f9db7f11ce", null ],
      [ "rsvd8", "_d_s_p2803x___h_r_cap_8h.html#a65682fb63bb3a2086ed7fe25126bcbf5", null ],
      [ "rsvd9", "_d_s_p2803x___h_r_cap_8h.html#a2d6219fce97bfee4c53a402261e63cbf", null ]
    ] ],
    [ "HRCap1Regs", "_d_s_p2803x___h_r_cap_8h.html#a19bc0105740688e5ffa8b025b47c7823", null ],
    [ "HRCap2Regs", "_d_s_p2803x___h_r_cap_8h.html#a0d8150c82c41b0756fae4580b3c30422", null ]
];