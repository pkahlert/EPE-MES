var clarke_8h =
[
    [ "CLARKE", "clarke_8h.html#struct_c_l_a_r_k_e", [
      [ "Alpha", "clarke_8h.html#a582e9fa5f3b8cd961c853c045882f3f7", null ],
      [ "As", "clarke_8h.html#a3b8af51ee90e66abb1f0e5f38e316d34", null ],
      [ "Beta", "clarke_8h.html#aa4631cbf89e363f274a5964f9198412c", null ],
      [ "Bs", "clarke_8h.html#a9dbade033dd6357561e430a6eacde2da", null ],
      [ "Cs", "clarke_8h.html#aaf8b23aea7cec4b5fcd897fd39adb461", null ]
    ] ],
    [ "CLARKE_DEFAULTS", "clarke_8h.html#a29e5e5a58c6502e6a8d2d507e4569781", null ],
    [ "CLARKE_MACRO", "clarke_8h.html#a88599cb7d3848b677ae7b1fd86020f5f", null ]
];