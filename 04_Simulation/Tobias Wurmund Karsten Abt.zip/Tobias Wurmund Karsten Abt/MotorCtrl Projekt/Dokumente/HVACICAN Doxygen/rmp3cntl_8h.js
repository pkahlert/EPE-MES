var rmp3cntl_8h =
[
    [ "RMP3", "rmp3cntl_8h.html#struct_r_m_p3", [
      [ "DesiredInput", "rmp3cntl_8h.html#a27e203b055dc842cebc095978d185fc4", null ],
      [ "Out", "rmp3cntl_8h.html#a11ebbffb0a6535526e1ae95056a58ef6", null ],
      [ "Ramp3Delay", "rmp3cntl_8h.html#ab61740dcbc6673dab7d21c6ff949b9dd", null ],
      [ "Ramp3DelayCount", "rmp3cntl_8h.html#acea8035d9b8a41eec7239afda37bc4d7", null ],
      [ "Ramp3DoneFlag", "rmp3cntl_8h.html#a98fae8694a5a7d578ee5417de23f0088", null ],
      [ "Ramp3Min", "rmp3cntl_8h.html#acd715c866d8a415072c174064fca06cc", null ]
    ] ],
    [ "RC3_MACRO", "rmp3cntl_8h.html#a1e269ce287dfcc509e0207f7eaafc531", null ],
    [ "RMP3_DEFAULTS", "rmp3cntl_8h.html#a6aa57a452abc1aa68397d8540e7faa48", null ]
];