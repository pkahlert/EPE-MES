var _d_s_p2803x___lin_8h =
[
    [ "SCIGCR0_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_g_c_r0___b_i_t_s", [
      [ "RESET", "_d_s_p2803x___lin_8h.html#a4850b43e0234ab6d6474c8f692af2a67", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a71540aef4a57002ef50ce455166e1313", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#a372c59b9bf88b35ce4e9f3b3bbd05673", null ]
    ] ],
    [ "SCIGCR0_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_g_c_r0___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a9a62c9fbe7da38cded9e48574e1a171e", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a5c6aa8feecf4fd42da7982e540e586bb", null ]
    ] ],
    [ "SCIGCR1_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_g_c_r1___b_i_t_s", [
      [ "ADAPT", "_d_s_p2803x___lin_8h.html#add72d971093f82796bcd189a680803cc", null ],
      [ "CLK_MASTER", "_d_s_p2803x___lin_8h.html#a922de22c7bdb55ceaabf6579cf71ed93", null ],
      [ "COMMMODE", "_d_s_p2803x___lin_8h.html#a63da0c56ecf8dc2ac4c709d745bdfb60", null ],
      [ "CONT", "_d_s_p2803x___lin_8h.html#ab2b4c220b40e14262587271f8a525656", null ],
      [ "CTYPE", "_d_s_p2803x___lin_8h.html#aa8659276bdf15f476ad97f23abe7caca", null ],
      [ "HGENCTRL", "_d_s_p2803x___lin_8h.html#a0fcd76498e16eca6b5a85cb08d5b73f0", null ],
      [ "LINMODE", "_d_s_p2803x___lin_8h.html#a4a6f5d3ca043b8bb69c0a1249454f12e", null ],
      [ "LOOPBACK", "_d_s_p2803x___lin_8h.html#a10182e3af12076e45ccdec5f51f2c166", null ],
      [ "MBUFMODE", "_d_s_p2803x___lin_8h.html#a4668a48ba9c5f6e933a227bb68c6d361", null ],
      [ "PARITY", "_d_s_p2803x___lin_8h.html#a9477717b5d9ca79d5dee7bf650ea952a", null ],
      [ "PARITYENA", "_d_s_p2803x___lin_8h.html#ad74a657c4ed2b6ed6472f29366029757", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#a05de1578b84c883e298c71385cfa601e", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#ab30ec67b05420c10e4f76ad0043bf521", null ],
      [ "rsvd4", "_d_s_p2803x___lin_8h.html#a4548b23c579e0c8bb95d3dd8cf5cdd68", null ],
      [ "RXENA", "_d_s_p2803x___lin_8h.html#a1c138be722110f46f642dbd18e82e937", null ],
      [ "SLEEP", "_d_s_p2803x___lin_8h.html#aa4d2f8a2b3c6bc058f2dc0692007b0bd", null ],
      [ "STOP", "_d_s_p2803x___lin_8h.html#ac777c58ed604f56b5894f41f98baf0af", null ],
      [ "STOPEXTFRAME", "_d_s_p2803x___lin_8h.html#aec0a8f04f77617b44a31f7eac593af6b", null ],
      [ "SWnRST", "_d_s_p2803x___lin_8h.html#af3ffedd522bf6581ecbae7f1617f4348", null ],
      [ "TIMINGMODE", "_d_s_p2803x___lin_8h.html#ac5c71d08c88cddc9cce06a107169cbb6", null ],
      [ "TXENA", "_d_s_p2803x___lin_8h.html#a41aa98a2fa821dbca5a61ff1259413a5", null ]
    ] ],
    [ "SCIGCR1_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_g_c_r1___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a51250ba597ecbbf51913f517583a786f", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a00ef4b81aa478a54289619dee9d01f46", null ]
    ] ],
    [ "SCIGCR2_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_g_c_r2___b_i_t_s", [
      [ "CC", "_d_s_p2803x___lin_8h.html#a3686388326c0f0f6955de400df964542", null ],
      [ "GENWU", "_d_s_p2803x___lin_8h.html#a1ba3c360d80ca4d433664cfa99a3ca98", null ],
      [ "POWERDOWN", "_d_s_p2803x___lin_8h.html#a6d68736e7751a2498b95aa19c0154ee6", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a6645b2cad1a91ce01ef571ab748ac112", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#afe3d8c1f6f3d5a4aa285f8c5e8a8b067", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#a10521129af7a122de3663938d74034d9", null ],
      [ "SC", "_d_s_p2803x___lin_8h.html#afb0cc015696c71fd1fe71ee53152795e", null ]
    ] ],
    [ "SCIGCR2_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_g_c_r2___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#aa8618a7ed99a75f216b65647d0bd83d8", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a3e0340e00db365309f4207324b62791b", null ]
    ] ],
    [ "SCISETINT_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_s_e_t_i_n_t___b_i_t_s", [
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#accaa96aa32791fe21409b814d95e09d1", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#afdc1f94be4711bac036b83bd3c0ddb28", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#a2d0978c146d53cbb1eb20c029677a931", null ],
      [ "rsvd4", "_d_s_p2803x___lin_8h.html#aa40927755db31729440cc5ee59a21f73", null ],
      [ "rsvd5", "_d_s_p2803x___lin_8h.html#a66514e2cea945ccd0fcac5b195b19773", null ],
      [ "rsvd6", "_d_s_p2803x___lin_8h.html#a283b109ede8daefaf809be53a23b0ddc", null ],
      [ "rsvd7", "_d_s_p2803x___lin_8h.html#abd5a377d65344aacfcfe510f55e1fa96", null ],
      [ "SETBEINT", "_d_s_p2803x___lin_8h.html#a452dd82e6576e65935258cd6afd6607a", null ],
      [ "SETBRKDTINT", "_d_s_p2803x___lin_8h.html#ad917b6b82beb6febb10c560e475c2509", null ],
      [ "SETCEINT", "_d_s_p2803x___lin_8h.html#a711f567c980014bb31ce0c570af4dd5c", null ],
      [ "SETFEINT", "_d_s_p2803x___lin_8h.html#a72dcbebc4a6c027d7ee64923ff1b97e3", null ],
      [ "SETIDINT", "_d_s_p2803x___lin_8h.html#aa07adad948297974192c306e16bc4cc9", null ],
      [ "SETISFEINT", "_d_s_p2803x___lin_8h.html#ae13a4b137e3f992cf82e4e6c718119bb", null ],
      [ "SETNREINT", "_d_s_p2803x___lin_8h.html#a61dcefc3180982d47527a5cfa80c0eaa", null ],
      [ "SETOEINT", "_d_s_p2803x___lin_8h.html#af5adaa42baac30cb0252023d936768ac", null ],
      [ "SETPBEINT", "_d_s_p2803x___lin_8h.html#a6a2b24b4af7165586ad52b247909b0f6", null ],
      [ "SETPEINT", "_d_s_p2803x___lin_8h.html#ae27b28b7c0d61cad8a2c1c200735fd59", null ],
      [ "SETRXINT", "_d_s_p2803x___lin_8h.html#a015554b3f174b47a81da45737f2769b7", null ],
      [ "SETTIMEOUTINT", "_d_s_p2803x___lin_8h.html#a34023c5d9201b7d7603d9e76dce63930", null ],
      [ "SETTOA3WUSINT", "_d_s_p2803x___lin_8h.html#aab887864b09e286561dac6d5d1bca68f", null ],
      [ "SETTOAWUSINT", "_d_s_p2803x___lin_8h.html#a6b4cf70ee61c110d1443aa991bf42e7e", null ],
      [ "SETTXINT", "_d_s_p2803x___lin_8h.html#a9a25a364f5e79c527422423d083a609b", null ],
      [ "SETWAKEUPINT", "_d_s_p2803x___lin_8h.html#a23edf2f969674ee8233ace3b70c03297", null ]
    ] ],
    [ "SCISETINT_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_s_e_t_i_n_t___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a05369e4e3be7c8dce945fc415a8e40f5", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a4cbc50480f4ef49a14f5a4afe288ac6b", null ]
    ] ],
    [ "SCICLEARINT_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_c_l_e_a_r_i_n_t___b_i_t_s", [
      [ "CLRBEINT", "_d_s_p2803x___lin_8h.html#afb48886fdc420ae13624109106c25001", null ],
      [ "CLRBRKDTINT", "_d_s_p2803x___lin_8h.html#af837b7daf1b5c183e3a2dbc79c9797c4", null ],
      [ "CLRCEINT", "_d_s_p2803x___lin_8h.html#a225388b07c4cce18e7448219e748aa29", null ],
      [ "CLRFEINT", "_d_s_p2803x___lin_8h.html#a8d35cea03cad54f184b4319eb7ba0a25", null ],
      [ "CLRIDINT", "_d_s_p2803x___lin_8h.html#afd7a374e1ed8dfcb9f9077bc5d8e91bf", null ],
      [ "CLRISFEINT", "_d_s_p2803x___lin_8h.html#a1b3bca75df02b6b3b0024afc481746fc", null ],
      [ "CLRNREINT", "_d_s_p2803x___lin_8h.html#ac822c3c0d2c5ad89061cdc25785f3be3", null ],
      [ "CLROEINT", "_d_s_p2803x___lin_8h.html#abe52505786b967b7ab16c858ff93fa57", null ],
      [ "CLRPBEINT", "_d_s_p2803x___lin_8h.html#a9db343fa2e0471ca513200d63cc62fd6", null ],
      [ "CLRPEINT", "_d_s_p2803x___lin_8h.html#a7b2e7c4b4a534d03f63f4e1cfc03f797", null ],
      [ "CLRRXINT", "_d_s_p2803x___lin_8h.html#a5f1a1c19a611a14ef4981e903529a61c", null ],
      [ "CLRTIMEOUTINT", "_d_s_p2803x___lin_8h.html#a17e4581bd5bc0c29b36effc8d111c99a", null ],
      [ "CLRTOA3WUSINT", "_d_s_p2803x___lin_8h.html#ad7f713009341baf8a044916fbe9d6e7a", null ],
      [ "CLRTOAWUSINT", "_d_s_p2803x___lin_8h.html#a9563cd0688428d0fe75fbcbe47ea1bcd", null ],
      [ "CLRTXINT", "_d_s_p2803x___lin_8h.html#a019cdefcb1021e335e6e3231d89bb2c0", null ],
      [ "CLRWAKEUPINT", "_d_s_p2803x___lin_8h.html#acf2cb0609b896ba56e93ae354f910212", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a3bbd345f1f773ea97f65c42e282d0dae", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#ab24c77fbb06f5d7b06ce20961deb6562", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#a094ef01f26f9c793ef8154a7237b076e", null ],
      [ "rsvd4", "_d_s_p2803x___lin_8h.html#aaed18b7cd0ed057c7cdf801487f7bbd4", null ],
      [ "rsvd5", "_d_s_p2803x___lin_8h.html#a9357f08e593993e2badcf20ce7fc4398", null ],
      [ "rsvd6", "_d_s_p2803x___lin_8h.html#a8188e33be6c5170dd8ed5cffbc2ad08e", null ],
      [ "rsvd7", "_d_s_p2803x___lin_8h.html#a18668e57748469555f6b2e2670d69c8c", null ]
    ] ],
    [ "SCICLEARINT_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_c_l_e_a_r_i_n_t___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#aa9542936ce1a414e04b54400568f4b96", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#ab72e1472941de34a654d494d60fe1d6b", null ]
    ] ],
    [ "SCISETINTLVL_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_s_e_t_i_n_t_l_v_l___b_i_t_s", [
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a82bf0b5b268bb3c3c5e466cf66d4e6d5", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#a4165464c5240ab846c79271cba2f41a8", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#a1250ebca380332d84d0238066cc6700b", null ],
      [ "rsvd4", "_d_s_p2803x___lin_8h.html#ad4e496fa7e96ac50d70f890eb841a1bc", null ],
      [ "rsvd5", "_d_s_p2803x___lin_8h.html#a48513f5e2b7e70717339738ad24df006", null ],
      [ "rsvd6", "_d_s_p2803x___lin_8h.html#aafbd74cc8213053c4a097fbfb991afc5", null ],
      [ "rsvd7", "_d_s_p2803x___lin_8h.html#ab1f361729b47d023f01b673f9364d688", null ],
      [ "SETBEINTLVL", "_d_s_p2803x___lin_8h.html#a433e60d7fa1baa8fa2457236db8d5ed0", null ],
      [ "SETBRKDTINTLVL", "_d_s_p2803x___lin_8h.html#a0864dd1da3215735862511f6044dc05d", null ],
      [ "SETCEINTLVL", "_d_s_p2803x___lin_8h.html#ac9843b9d4eedca382265e577ae9d475e", null ],
      [ "SETFEINTLVL", "_d_s_p2803x___lin_8h.html#ab74d8ed4908c6aa3cedc3f69477df247", null ],
      [ "SETIDINTLVL", "_d_s_p2803x___lin_8h.html#a808e75895522a2ca5a29a3b0b7a4c960", null ],
      [ "SETISFEINTLVL", "_d_s_p2803x___lin_8h.html#a9efc3663edf5f753954280b457a0e3b9", null ],
      [ "SETNREINTLVL", "_d_s_p2803x___lin_8h.html#a7554ec07d481f879de4c7fe0fdd1fbee", null ],
      [ "SETOEINTLVL", "_d_s_p2803x___lin_8h.html#a4ca3858bf610cf3f43e491e69e09c2da", null ],
      [ "SETPBEINTLVL", "_d_s_p2803x___lin_8h.html#a8da2310c7862be690b596b397049866b", null ],
      [ "SETPEINTLVL", "_d_s_p2803x___lin_8h.html#a9e9011dca9c5250cfb4e2ec122cfd811", null ],
      [ "SETRXINTOVO", "_d_s_p2803x___lin_8h.html#a44c1a4653a9a599540656f5471293018", null ],
      [ "SETTIMEOUTINTLVL", "_d_s_p2803x___lin_8h.html#aff823af7f4838b4015c98d08e47d0250", null ],
      [ "SETTOA3WUSINTLVL", "_d_s_p2803x___lin_8h.html#acef9398fda42d39786ce8001f45d26d3", null ],
      [ "SETTOAWUSINTLVL", "_d_s_p2803x___lin_8h.html#aa15c0493db1652c8efaad7ef891570dc", null ],
      [ "SETTXINTLVL", "_d_s_p2803x___lin_8h.html#aac89e49b1c66df34a504f9eaa85c7da1", null ],
      [ "SETWAKEUPINTLVL", "_d_s_p2803x___lin_8h.html#a0bb8a56a4b6cbeb8e2624e998266f133", null ]
    ] ],
    [ "SCISETINTLVL_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_s_e_t_i_n_t_l_v_l___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a7121443db78cbc72df4832de1b6be20b", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a11e47d9cf834ebcc2bc5fe3baa1cce4c", null ]
    ] ],
    [ "SCICLEARINTLVL_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_c_l_e_a_r_i_n_t_l_v_l___b_i_t_s", [
      [ "CLRBEINTLVL", "_d_s_p2803x___lin_8h.html#a52472b4f686dd2a4a11203263a97e44e", null ],
      [ "CLRBRKDTINTLVL", "_d_s_p2803x___lin_8h.html#a57ed462201e2720819433273a837cd92", null ],
      [ "CLRCEINTLVL", "_d_s_p2803x___lin_8h.html#af579954cec360a68d5d9d2213d230e7b", null ],
      [ "CLRFEINTLVL", "_d_s_p2803x___lin_8h.html#a4787133a257311d514b5472bd393d1e1", null ],
      [ "CLRIDINTLVL", "_d_s_p2803x___lin_8h.html#af058380d45d0ea263c5c1b17acbece9d", null ],
      [ "CLRISFEINTLVL", "_d_s_p2803x___lin_8h.html#a32c874cc4ae84a93abb24abc83ac0d2c", null ],
      [ "CLRNREINTLVL", "_d_s_p2803x___lin_8h.html#a40022e18cff706f160447c88886e13c5", null ],
      [ "CLROEINTLVL", "_d_s_p2803x___lin_8h.html#af90e27275b89b93ee54f368dcf74297f", null ],
      [ "CLRPBEINTLVL", "_d_s_p2803x___lin_8h.html#aa0ab5e22e4e20da7eec4991713dec460", null ],
      [ "CLRPEINTLVL", "_d_s_p2803x___lin_8h.html#a25e9424d4af6787da658c3cb1f5dcfe7", null ],
      [ "CLRRXINTLVL", "_d_s_p2803x___lin_8h.html#a1a64c41167e55811c43fca5f2b2443d2", null ],
      [ "CLRTIMEOUTINTLVL", "_d_s_p2803x___lin_8h.html#a4e58caf2ed9d8518bb5cbb198a805568", null ],
      [ "CLRTOA3WUSINTLVL", "_d_s_p2803x___lin_8h.html#a62a828cd67fa820efc7be09b35663bd2", null ],
      [ "CLRTOAWUSINTLVL", "_d_s_p2803x___lin_8h.html#a689c73021c335844b9d49277e7396326", null ],
      [ "CLRTXINTLVL", "_d_s_p2803x___lin_8h.html#a422a678ec4f91f4acdd7e31bb3b8e0ce", null ],
      [ "CLRWAKEUPINTLVL", "_d_s_p2803x___lin_8h.html#ac6a45011895d1722cdf03cc84fb0d462", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a5099db0bbfe00682ee9f2323964f3cf3", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#a1f922a64e6c7a7cf3728ab5ca9c15373", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#ab120128b613b0f9716f9fc5f04a1eda3", null ],
      [ "rsvd4", "_d_s_p2803x___lin_8h.html#a24b778622b93d4472a31163640b64e49", null ],
      [ "rsvd5", "_d_s_p2803x___lin_8h.html#a6be4ff7a78420726c1d5d037028ad2ae", null ],
      [ "rsvd6", "_d_s_p2803x___lin_8h.html#a2002270a9fcad71e91b6d1a8f9ddb6f2", null ],
      [ "rsvd7", "_d_s_p2803x___lin_8h.html#a1184afd3e6b0ae35a5bf63c537450859", null ]
    ] ],
    [ "SCICLEARINTLVL_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_c_l_e_a_r_i_n_t_l_v_l___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#ae4932f90d855046d867175d5223fb76c", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#ab82a81ba0b77defbf693ceb0a11a2802", null ]
    ] ],
    [ "SCIFLR_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_f_l_r___b_i_t_s", [
      [ "BE", "_d_s_p2803x___lin_8h.html#a60a47fbeb67ae5566b7a2621a3a594a2", null ],
      [ "BRKDT", "_d_s_p2803x___lin_8h.html#acfe04a02200f7bb0ca9731a5b2d53cb5", null ],
      [ "BUSY", "_d_s_p2803x___lin_8h.html#a086c35ea37a23546dad2204449d64f53", null ],
      [ "CE", "_d_s_p2803x___lin_8h.html#a2d574030aa411f3eefbb6f22513b123c", null ],
      [ "FE", "_d_s_p2803x___lin_8h.html#ae47469771b93121cbd99d0b7ad26f9d4", null ],
      [ "IDLE", "_d_s_p2803x___lin_8h.html#a952e9c2c3b58c5fe012ded59bdb8a861", null ],
      [ "IDRXFLAG", "_d_s_p2803x___lin_8h.html#a912f73f1fd26232123958edec1892151", null ],
      [ "IDTXFLAG", "_d_s_p2803x___lin_8h.html#af9ffbf3b79b1b66547be3a60882e6da0", null ],
      [ "ISFE", "_d_s_p2803x___lin_8h.html#a38ea9ff834b77de63ac0924a96e63296", null ],
      [ "NRE", "_d_s_p2803x___lin_8h.html#a3ae9bd590f0ad8dc3f171400a097e79b", null ],
      [ "OE", "_d_s_p2803x___lin_8h.html#aa409d7f628e38a55178223ab13945d90", null ],
      [ "PBE", "_d_s_p2803x___lin_8h.html#a29a9e255322960519e36439107d0ef40", null ],
      [ "PE", "_d_s_p2803x___lin_8h.html#a25ef4d8c42b7c81295f815ccf019114f", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#a2c84e494a0481e69a4e22157cd786101", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#a51280c87d18686c3a8e925a1563ef10e", null ],
      [ "rsvd4", "_d_s_p2803x___lin_8h.html#a54e577f749b4879acab444e628e7aacd", null ],
      [ "RXRDY", "_d_s_p2803x___lin_8h.html#a32df6d8bc9c83e87015056814809f5a9", null ],
      [ "RXWAKE", "_d_s_p2803x___lin_8h.html#a18e47509c1ae75663bab9160fd43fe4a", null ],
      [ "TIMEOUT", "_d_s_p2803x___lin_8h.html#a5bf7aacd8e0561f7d9905377d3a1d87c", null ],
      [ "TOA3WUS", "_d_s_p2803x___lin_8h.html#af4f91f63ebbf219d3c3f0c9ea8027de5", null ],
      [ "TOAWUS", "_d_s_p2803x___lin_8h.html#a03439196d4daab5aaadd91024ba70e92", null ],
      [ "TXEMPTY", "_d_s_p2803x___lin_8h.html#ac5443abe8eacb29e4041872322ca087c", null ],
      [ "TXRDY", "_d_s_p2803x___lin_8h.html#ad8205449adb378c654759f0e1fbece91", null ],
      [ "TXWAKE", "_d_s_p2803x___lin_8h.html#a6876d0653f12c6c014870ba3faf7bd2b", null ],
      [ "WAKEUP", "_d_s_p2803x___lin_8h.html#af4a23cc1aefaa7a1febda57b860d6061", null ]
    ] ],
    [ "SCIFLR_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_f_l_r___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#aab417ba05fa75db7be87f57f655ae1f6", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#abba1d2bda485fbef3d33bb601d6cd936", null ]
    ] ],
    [ "SCIINTVECT0_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_i_n_t_v_e_c_t0___b_i_t_s", [
      [ "INTVECT0", "_d_s_p2803x___lin_8h.html#aeab1ba48c83e2d61d948af8f4cc4c509", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#ae5698db01e7282200b9214d9c1112f1f", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#adca44cf6baa0a18e676cc638ba93f9ee", null ]
    ] ],
    [ "SCIINTVECT0_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_i_n_t_v_e_c_t0___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#af3fe92a730628150ffa88cb6158f5122", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a407270fae6c0495186551119e0b92f8c", null ]
    ] ],
    [ "SCIINTVECT1_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_i_n_t_v_e_c_t1___b_i_t_s", [
      [ "INTVECT1", "_d_s_p2803x___lin_8h.html#a2d8fb3e5cd36e9c5fe9bd8dbd2f00f28", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a0a9ca4ce7f77d62e01886fc707e8a83c", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#af4b2b9631ce43354e31ecd2ea8524a32", null ]
    ] ],
    [ "SCIINTVECT1_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_i_n_t_v_e_c_t1___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a6bcaab2c26352a66e7a834fffc8b32f7", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#adf51d0a39596d2d4b9245ec6f6c3a72c", null ]
    ] ],
    [ "SCIFORMAT_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_f_o_r_m_a_t___b_i_t_s", [
      [ "CHAR", "_d_s_p2803x___lin_8h.html#a484508ad4c03202f00d0fd2b02b96605", null ],
      [ "LENGTH", "_d_s_p2803x___lin_8h.html#af95226666273aa1e88cbe44ce2f9686a", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#aae9fba8dc3aaff027d52595512d085a3", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#afcd238357368a05daf7e9ad3aff2478a", null ]
    ] ],
    [ "SCIFORMAT_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_f_o_r_m_a_t___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a89e5346bc4ff38285a8f4d7905acdc79", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a3b5de9eeeeab286c0f1fd439162cb554", null ]
    ] ],
    [ "BRSR_BITS", "_d_s_p2803x___lin_8h.html#struct_b_r_s_r___b_i_t_s", [
      [ "M", "_d_s_p2803x___lin_8h.html#ac75ab626e6094ba84155cc3b4a965d61", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a884e1811936b5323e86fa7643e1867ad", null ],
      [ "SCI_LIN_PSH", "_d_s_p2803x___lin_8h.html#a3c74f5b02faa6b022f44abb343ffa9ed", null ],
      [ "SCI_LIN_PSL", "_d_s_p2803x___lin_8h.html#a24fe136631ac3cf8ee63fdccda54980d", null ]
    ] ],
    [ "BRSR_REG", "_d_s_p2803x___lin_8h.html#union_b_r_s_r___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a5860ed4f94a7dce9a716a5127ce198eb", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a4893fa24814e276e8bedf85630235753", null ]
    ] ],
    [ "SCIPIO2_BITS", "_d_s_p2803x___lin_8h.html#struct_s_c_i_p_i_o2___b_i_t_s", [
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a97e8e8b145847007dc0ca3fd2b2fde2b", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#a33c360e55ec5f1cb539bf69abda4f49d", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#af2aece0f0ab42918c749dfe370c553b4", null ],
      [ "RXIN", "_d_s_p2803x___lin_8h.html#a6b85f8167b7ccd6f59fb1374035cde23", null ],
      [ "TXIN", "_d_s_p2803x___lin_8h.html#a67c0dc6643d57f0e13edc084143e95ba", null ]
    ] ],
    [ "SCIPIO2_REG", "_d_s_p2803x___lin_8h.html#union_s_c_i_p_i_o2___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a2febf74fe9fa230672106aae5c5dae51", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a71e62bfd8e54440f8506c8a20e89e141", null ]
    ] ],
    [ "LINCOMP_BITS", "_d_s_p2803x___lin_8h.html#struct_l_i_n_c_o_m_p___b_i_t_s", [
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a046f2b4ec9eb05e403aabac6af55c88e", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#a9b9d3a812fde84211d057373309aa6ef", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#a29159c458a280504fc2f6c702d0e1f58", null ],
      [ "SBREAK", "_d_s_p2803x___lin_8h.html#a4d453e0db7de167f7d77656bc6eeea26", null ],
      [ "SDEL", "_d_s_p2803x___lin_8h.html#ad56c848a01319fcc8822541c3207cc01", null ]
    ] ],
    [ "LINCOMP_REG", "_d_s_p2803x___lin_8h.html#union_l_i_n_c_o_m_p___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#aa22adae6b7f85f1a10c20898dd704c69", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a4e72e802a411fb6c60b0d6a6d8d4030b", null ]
    ] ],
    [ "LINRD0_BITS", "_d_s_p2803x___lin_8h.html#struct_l_i_n_r_d0___b_i_t_s", [
      [ "RD0", "_d_s_p2803x___lin_8h.html#af3160d4da022f123f46ed868fdf76da7", null ],
      [ "RD1", "_d_s_p2803x___lin_8h.html#aab0d63fb179e8cb8e2d6193dc203bcd3", null ],
      [ "RD2", "_d_s_p2803x___lin_8h.html#a623fe2f14a613bdd0774e8d446ad5dca", null ],
      [ "RD3", "_d_s_p2803x___lin_8h.html#a7d8f526874413f66657954435d77ade1", null ]
    ] ],
    [ "LINRD0_REG", "_d_s_p2803x___lin_8h.html#union_l_i_n_r_d0___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a1eb8a55a0831abecfbb7a2cc2bd52670", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#ac67b89238d646979437857a6457af3be", null ]
    ] ],
    [ "LINRD1_BITS", "_d_s_p2803x___lin_8h.html#struct_l_i_n_r_d1___b_i_t_s", [
      [ "RD4", "_d_s_p2803x___lin_8h.html#aaba4fcc9f0064ecbd35fbcdb80a79218", null ],
      [ "RD5", "_d_s_p2803x___lin_8h.html#aae26cc05234bf50d1bee55df600580ea", null ],
      [ "RD6", "_d_s_p2803x___lin_8h.html#a51fe72a0ba85f5c7b2fb59606e66f9fd", null ],
      [ "RD7", "_d_s_p2803x___lin_8h.html#ace1c035bb25ee2e77ef9dc7a72040301", null ]
    ] ],
    [ "LINRD1_REG", "_d_s_p2803x___lin_8h.html#union_l_i_n_r_d1___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#aaf26397603b453e933efb5e1c33bd39d", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a59d9ce2667ef5e600fb98415c2bfcb35", null ]
    ] ],
    [ "LINMASK_BITS", "_d_s_p2803x___lin_8h.html#struct_l_i_n_m_a_s_k___b_i_t_s", [
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a7ba88552e38aec14722528540f703bdc", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#acdd4903f4d010d813793397da16ea40a", null ],
      [ "RXIDMASK", "_d_s_p2803x___lin_8h.html#a2e309cc4da84ceb5d7e85fdc1d3e83d5", null ],
      [ "TXIDMASK", "_d_s_p2803x___lin_8h.html#a9654599066b7a7121ccd726889bbb62c", null ]
    ] ],
    [ "LINMASK_REG", "_d_s_p2803x___lin_8h.html#union_l_i_n_m_a_s_k___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a88187b883c36181feedf365737a09e58", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#ad4d141d661b5de848f87f3f76e7afe80", null ]
    ] ],
    [ "LINID_BITS", "_d_s_p2803x___lin_8h.html#struct_l_i_n_i_d___b_i_t_s", [
      [ "IDBYTE", "_d_s_p2803x___lin_8h.html#acc768f6868d331f83d2a47e82895fd8c", null ],
      [ "IDSLAVETASKBYTE", "_d_s_p2803x___lin_8h.html#abe221c81092749086c87b5e6d70b9d4c", null ],
      [ "RECEIVEDID", "_d_s_p2803x___lin_8h.html#a450883303abdc848f6519815f39eebf7", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#ab5fae6b6f09fb08bd89f4fe29291a8ce", null ]
    ] ],
    [ "LINID_REG", "_d_s_p2803x___lin_8h.html#union_l_i_n_i_d___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a10e7790d098203bd854bfa0c1ed34455", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#affcd64026d8a16aa2f87389f585f08bf", null ]
    ] ],
    [ "LINTD0_BITS", "_d_s_p2803x___lin_8h.html#struct_l_i_n_t_d0___b_i_t_s", [
      [ "TD0", "_d_s_p2803x___lin_8h.html#a336aba0bcf0150de6a19c28ab8d5358f", null ],
      [ "TD1", "_d_s_p2803x___lin_8h.html#a051a84c03b355141c8c1e195e1b354eb", null ],
      [ "TD2", "_d_s_p2803x___lin_8h.html#af9747894fc32a19ef011cd388b527192", null ],
      [ "TD3", "_d_s_p2803x___lin_8h.html#aa084896639da46f0a320a7a39c1495dc", null ]
    ] ],
    [ "LINTD0_REG", "_d_s_p2803x___lin_8h.html#union_l_i_n_t_d0___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#ae3e43cff6a9acd3089e6c53ae75395e2", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a330b91410eea6da5490af7aaf1c0b6aa", null ]
    ] ],
    [ "LINTD1_BITS", "_d_s_p2803x___lin_8h.html#struct_l_i_n_t_d1___b_i_t_s", [
      [ "TD4", "_d_s_p2803x___lin_8h.html#ac96f2f6f1308f05c1b5414e11025d85e", null ],
      [ "TD5", "_d_s_p2803x___lin_8h.html#a6f8ad7fd1cb89d2db0ae298cfad12c26", null ],
      [ "TD6", "_d_s_p2803x___lin_8h.html#a015ed1ac3b783028c1eec8e716916e5b", null ],
      [ "TD7", "_d_s_p2803x___lin_8h.html#aac83b21a4fb39e2aea24c2fa1fd5f254", null ]
    ] ],
    [ "LINTD1_REG", "_d_s_p2803x___lin_8h.html#union_l_i_n_t_d1___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#ab010a8f07201e05e1be171cb9a163a7e", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#a089634ed2cc3a24a799607bb7b85f02c", null ]
    ] ],
    [ "IODFTCTRL_BITS", "_d_s_p2803x___lin_8h.html#struct_i_o_d_f_t_c_t_r_l___b_i_t_s", [
      [ "BERRENA", "_d_s_p2803x___lin_8h.html#aee0962acb645151e3309478c882b9e05", null ],
      [ "BRKDTERRENA", "_d_s_p2803x___lin_8h.html#a91251eb049a4dfbef39eaeb87a27d602", null ],
      [ "CERRENA", "_d_s_p2803x___lin_8h.html#a16dc7c5b82864aba7903790858ffed03", null ],
      [ "FERRENA", "_d_s_p2803x___lin_8h.html#a18418528b01a38c5847d31cde81b241f", null ],
      [ "IODFTENA", "_d_s_p2803x___lin_8h.html#adfda37726d6a919c3f6e21b531387d2f", null ],
      [ "ISFERRENA", "_d_s_p2803x___lin_8h.html#a4ce7487ac9791e058386932d30bfc106", null ],
      [ "LPBENA", "_d_s_p2803x___lin_8h.html#ad153edab200613ac3ae69b7daa8d646e", null ],
      [ "PBERRENA", "_d_s_p2803x___lin_8h.html#add6d617b7820713e5d69b95fbe489b2e", null ],
      [ "PERRENA", "_d_s_p2803x___lin_8h.html#aa2d4c2c16721a0109ce4df85d5d9d4de", null ],
      [ "PINSAMPLEMASK", "_d_s_p2803x___lin_8h.html#a1704faa7b39cce054ec3a3e1652dbd9c", null ],
      [ "rsvd", "_d_s_p2803x___lin_8h.html#adf774de162c47dc644afa3fd72650190", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#aaf784d284028b83ac343578fa5af2b2c", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#a79d6833b4febdca46902197b534561b3", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#aaedb66607de74f1259e742d2e95f4739", null ],
      [ "RXPENA", "_d_s_p2803x___lin_8h.html#a026ff89001559e1b568c747a08b0b8da", null ],
      [ "TXSHIFT", "_d_s_p2803x___lin_8h.html#a4175178058adb9ed906b9ad18015e646", null ]
    ] ],
    [ "IODFTCTRL_REG", "_d_s_p2803x___lin_8h.html#union_i_o_d_f_t_c_t_r_l___r_e_g", [
      [ "all", "_d_s_p2803x___lin_8h.html#a47f837c434a29f81a36f208779f37618", null ],
      [ "bit", "_d_s_p2803x___lin_8h.html#ae9ede939b8c66075b57d09a1ca551d4f", null ]
    ] ],
    [ "LIN_REGS", "_d_s_p2803x___lin_8h.html#struct_l_i_n___r_e_g_s", [
      [ "BRSR", "_d_s_p2803x___lin_8h.html#af23ec7cec4a41366c1c40977e71f51b1", null ],
      [ "IODFTCTRL", "_d_s_p2803x___lin_8h.html#a79716864027179d4b47d6feac67790f2", null ],
      [ "LINCOMP", "_d_s_p2803x___lin_8h.html#a7595987f4c86fe86516ec22960507d65", null ],
      [ "LINID", "_d_s_p2803x___lin_8h.html#afe9f0b20399fd2beafac5f67817971f9", null ],
      [ "LINMASK", "_d_s_p2803x___lin_8h.html#aa54abf4c3b136be359f40e039ffaaf87", null ],
      [ "LINRD0", "_d_s_p2803x___lin_8h.html#a35523871cf406862e800b8de97d73732", null ],
      [ "LINRD1", "_d_s_p2803x___lin_8h.html#af1d735cee2501f126a64d3d6a14364b4", null ],
      [ "LINTD0", "_d_s_p2803x___lin_8h.html#a5c75c8e9d92806055b0887e5cc7ac2a4", null ],
      [ "LINTD1", "_d_s_p2803x___lin_8h.html#a654d566c3c5946c2e0b39b98662bbf7d", null ],
      [ "MBRSR", "_d_s_p2803x___lin_8h.html#a93cd9cbfa1c5661072e64f81e8ed7836", null ],
      [ "rsvd1", "_d_s_p2803x___lin_8h.html#a40e5b548b421262982fa909f1060463f", null ],
      [ "rsvd2", "_d_s_p2803x___lin_8h.html#aba01ff5d901fb853ca915d075167cf3c", null ],
      [ "rsvd3", "_d_s_p2803x___lin_8h.html#a7504038c422da5cf92c8fb030885d8fe", null ],
      [ "SCICLEARINT", "_d_s_p2803x___lin_8h.html#a4ee405d88b149befb77a7574046a7327", null ],
      [ "SCICLEARINTLVL", "_d_s_p2803x___lin_8h.html#a68701ccbfbba0af5082d17c12e03bafe", null ],
      [ "SCIED", "_d_s_p2803x___lin_8h.html#a55ecd8035948342c448755674deaa726", null ],
      [ "SCIFLR", "_d_s_p2803x___lin_8h.html#aab903711dfaf2a6dd04c9f28fc6e2706", null ],
      [ "SCIFORMAT", "_d_s_p2803x___lin_8h.html#a39b26cb0ad7a1d0b4e78be8ce09259df", null ],
      [ "SCIGCR0", "_d_s_p2803x___lin_8h.html#acddcb7c1db5df5a62d098139b5f8e0db", null ],
      [ "SCIGCR1", "_d_s_p2803x___lin_8h.html#a36e3f54bfaef17d43582af49039bf7c0", null ],
      [ "SCIGCR2", "_d_s_p2803x___lin_8h.html#a6ea6f38447a7fb4b27775bb9a45629b7", null ],
      [ "SCIINTVECT0", "_d_s_p2803x___lin_8h.html#a15360a6600ba01fab4f371cc53b55abd", null ],
      [ "SCIINTVECT1", "_d_s_p2803x___lin_8h.html#a107605c0d5cf60cfcf09fcd92fa5322f", null ],
      [ "SCIPIO2", "_d_s_p2803x___lin_8h.html#a475dbc9fdd08bc4c9f4a50f389e635bf", null ],
      [ "SCIRD", "_d_s_p2803x___lin_8h.html#a3b1c257108b8065ecd30f4553afec2e3", null ],
      [ "SCISETINT", "_d_s_p2803x___lin_8h.html#a511fcaf6f62efafc6c67cc2ec63e85cf", null ],
      [ "SCISETINTLVL", "_d_s_p2803x___lin_8h.html#a07d3fd615e9320ee5a55ea6b17eec799", null ],
      [ "SCITD", "_d_s_p2803x___lin_8h.html#af14a4cfbcc2fc7ea7e3614b9cbc563db", null ]
    ] ],
    [ "LinaRegs", "_d_s_p2803x___lin_8h.html#a048abb0432a89559759dc0709b705a58", null ]
];