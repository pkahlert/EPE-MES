var dlog4ch__h_v_a_c_i___sensored_8h =
[
    [ "DLOG_4CH", "struct_d_l_o_g__4_c_h.html", "struct_d_l_o_g__4_c_h" ],
    [ "DLOG_4CH_DEFAULTS", "dlog4ch-_h_v_a_c_i___sensored_8h.html#a4373c133b95a4efe38183875ef6d7fba", null ],
    [ "NULL", "dlog4ch-_h_v_a_c_i___sensored_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4", null ],
    [ "DLOG_4CH_handle", "dlog4ch-_h_v_a_c_i___sensored_8h.html#aebe414f44000e5c728f1fce5cbbb27e7", null ],
    [ "DLOG_4CH_init", "dlog4ch-_h_v_a_c_i___sensored_8h.html#a77875f4cceb9f11f932327722a4289a6", null ],
    [ "DLOG_4CH_update", "dlog4ch-_h_v_a_c_i___sensored_8h.html#a73df429fb1cbabbb0d3541988dda021b", null ]
];