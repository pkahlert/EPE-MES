var _d_s_p2803x___sys_ctrl_8h =
[
    [ "XCLK_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_x_c_l_k___b_i_t_s", [
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a8e3542c22823963f355d798df0794371", null ],
      [ "rsvd3", "_d_s_p2803x___sys_ctrl_8h.html#a49b195da204f6de193577885c9aa3770", null ],
      [ "XCLKINSEL", "_d_s_p2803x___sys_ctrl_8h.html#a46ef46d52a270e74eae080e61f66497f", null ],
      [ "XCLKOUTDIV", "_d_s_p2803x___sys_ctrl_8h.html#abe81b7147e838b53a45cd514c9632dc6", null ]
    ] ],
    [ "XCLK_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_x_c_l_k___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#aba0fd89e8fdeeb0ecfbb5f95f5b01a34", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#aaef08967c0e8056a876c42b20fd6fe85", null ]
    ] ],
    [ "PLLSTS_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_p_l_l_s_t_s___b_i_t_s", [
      [ "DIVSEL", "_d_s_p2803x___sys_ctrl_8h.html#ad40a2b788581cbf64fbcd0783178c4c6", null ],
      [ "MCLKCLR", "_d_s_p2803x___sys_ctrl_8h.html#a4210710247c95097119ec5b588610491", null ],
      [ "MCLKOFF", "_d_s_p2803x___sys_ctrl_8h.html#afca9a16d305fe5c407f8f71b06af76d0", null ],
      [ "MCLKSTS", "_d_s_p2803x___sys_ctrl_8h.html#aabb0abd8c327153969a7a9a3463a32a2", null ],
      [ "NORMRDYE", "_d_s_p2803x___sys_ctrl_8h.html#ae79f3d4466d7a54402c4ed20147bb948", null ],
      [ "OSCOFF", "_d_s_p2803x___sys_ctrl_8h.html#af0e53c081db44d376f5d093b2bd63f1c", null ],
      [ "PLLLOCKS", "_d_s_p2803x___sys_ctrl_8h.html#a7df1b8bd1fc8617ecd13cfd4087bb962", null ],
      [ "PLLOFF", "_d_s_p2803x___sys_ctrl_8h.html#a974b1c4341ab7ed28344c79337d69c8b", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a9fc55d573939747d85d2663590ca8387", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#ab59888f251e1f1717d32526bf7d30540", null ]
    ] ],
    [ "PLLSTS_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_p_l_l_s_t_s___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a09c55a9d3d0af27a2d3a83cbdbb2105c", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a69c8bbd6131fdc87fb9736ce86c41918", null ]
    ] ],
    [ "CLKCTL_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_c_l_k_c_t_l___b_i_t_s", [
      [ "INTOSC1HALTI", "_d_s_p2803x___sys_ctrl_8h.html#a42b61b2d324e1ed2c559a5986227fb30", null ],
      [ "INTOSC1OFF", "_d_s_p2803x___sys_ctrl_8h.html#ae50254df223a25ce3d69f7d2dc5597b8", null ],
      [ "INTOSC2HALTI", "_d_s_p2803x___sys_ctrl_8h.html#a34734c1a2fa4cde7ad0202b98cc35610", null ],
      [ "INTOSC2OFF", "_d_s_p2803x___sys_ctrl_8h.html#ad69963f2445fd78cf4591df94416c23f", null ],
      [ "NMIRESETSEL", "_d_s_p2803x___sys_ctrl_8h.html#acd9cee9a433bb6e65b7737b936d4baec", null ],
      [ "OSCCLKSRC2SEL", "_d_s_p2803x___sys_ctrl_8h.html#a39bf61983f92b5ba22f69b40a25a6f92", null ],
      [ "OSCCLKSRCSEL", "_d_s_p2803x___sys_ctrl_8h.html#a88242d59b4a10bc7898019688844a672", null ],
      [ "TMR2CLKPRESCALE", "_d_s_p2803x___sys_ctrl_8h.html#adb66a462210963c686b533e757291af3", null ],
      [ "TMR2CLKSRCSEL", "_d_s_p2803x___sys_ctrl_8h.html#a039d4e120d217e22d9d27c9268621c35", null ],
      [ "WDCLKSRCSEL", "_d_s_p2803x___sys_ctrl_8h.html#abe9313cb8938bc34d6e455aea5c8e493", null ],
      [ "WDHALTI", "_d_s_p2803x___sys_ctrl_8h.html#ac25efae0e5660014d068b813a33dc88e", null ],
      [ "XCLKINOFF", "_d_s_p2803x___sys_ctrl_8h.html#af6b6adf0df81a244ebc7cabff363e2e0", null ],
      [ "XTALOSCOFF", "_d_s_p2803x___sys_ctrl_8h.html#a87d916a38649d74a6f13d64a96dddc91", null ]
    ] ],
    [ "CLKCTL_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_c_l_k_c_t_l___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a65b15da3e77bed33e4b28b5dee798532", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a20068be71b918a47e2e0ee9d726485e9", null ]
    ] ],
    [ "INTOSC1TRIM_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_i_n_t_o_s_c1_t_r_i_m___b_i_t_s", [
      [ "COARSETRIM", "_d_s_p2803x___sys_ctrl_8h.html#aa265364890ff322e7d545781e418fcf3", null ],
      [ "FINETRIM", "_d_s_p2803x___sys_ctrl_8h.html#a8371e633cbd8825783cc02f55b38d79f", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#aa62fdbfbfbfc48ca80b9f947577662ec", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#a473554c7a830d2a1a8ae193d899c86e1", null ]
    ] ],
    [ "INTOSC1TRIM_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_i_n_t_o_s_c1_t_r_i_m___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#aa09052f3b18f78c1803b8a41d71b62fd", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#ac1ca6092df71efc2c51fe5aede36f6b0", null ]
    ] ],
    [ "INTOSC2TRIM_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_i_n_t_o_s_c2_t_r_i_m___b_i_t_s", [
      [ "COARSETRIM", "_d_s_p2803x___sys_ctrl_8h.html#ac004cca9b31da1c063a7b6c9dadd0dd3", null ],
      [ "FINETRIM", "_d_s_p2803x___sys_ctrl_8h.html#a27e8900df71e0f1e0d46d1656e61e86c", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a378321b4294cf51ee829db82199c5bce", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#a52393513f993b279f070e809dbed5ef1", null ]
    ] ],
    [ "INTOSC2TRIM_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_i_n_t_o_s_c2_t_r_i_m___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a91f5fd7ff6bd9dc666ba410475c5ff90", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a6e8f52ef31f10c105974156299e9f7e9", null ]
    ] ],
    [ "LOSPCP_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_l_o_s_p_c_p___b_i_t_s", [
      [ "LSPCLK", "_d_s_p2803x___sys_ctrl_8h.html#a766a0fe048d5e1343de743d2202a2e16", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#add9555cb679167bb194e235d81e5dcc3", null ]
    ] ],
    [ "LOSPCP_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_l_o_s_p_c_p___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#aff68b322df91ea2c6670964de3b296b5", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a8e0da115cfddedb5794b1d909ffb8f0e", null ]
    ] ],
    [ "PCLKCR0_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_p_c_l_k_c_r0___b_i_t_s", [
      [ "ADCENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a2cc41a325b93fcd24cb6d87b92096fd5", null ],
      [ "ECANAENCLK", "_d_s_p2803x___sys_ctrl_8h.html#ab9ec6019ee2033f0d8fe51d624d44361", null ],
      [ "HRPWMENCLK", "_d_s_p2803x___sys_ctrl_8h.html#af7e98823ad4aa5e13a7d5c04c3eefc1e", null ],
      [ "I2CAENCLK", "_d_s_p2803x___sys_ctrl_8h.html#ae4ff6ce1b2de2d2271a803afd4c84b2a", null ],
      [ "LINAENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a6e8fda8d1cd89994b51aec05592ff442", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a45d13c5879de46538bd777acaa92a6a3", null ],
      [ "rsvd3", "_d_s_p2803x___sys_ctrl_8h.html#a103ca6993498d1e71cb72a109663cef1", null ],
      [ "rsvd5", "_d_s_p2803x___sys_ctrl_8h.html#a7aa90c2f15d508f723feacc433a3c331", null ],
      [ "SCIAENCLK", "_d_s_p2803x___sys_ctrl_8h.html#ab19261798f36ab8a7590c5c2b890c2e1", null ],
      [ "SPIAENCLK", "_d_s_p2803x___sys_ctrl_8h.html#aedb843062f9bc78fc9f284b086d83074", null ],
      [ "SPIBENCLK", "_d_s_p2803x___sys_ctrl_8h.html#ae9658bb27a454d8489bbb512d7aac699", null ],
      [ "TBCLKSYNC", "_d_s_p2803x___sys_ctrl_8h.html#a28851e1f4a0d0fee2a1eb66fd339f75c", null ]
    ] ],
    [ "PCLKCR0_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_p_c_l_k_c_r0___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#acb635bdd7caee4ee7036985307948b7e", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a57362b47d4a11c11099897de92827f9e", null ]
    ] ],
    [ "PCLKCR1_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_p_c_l_k_c_r1___b_i_t_s", [
      [ "ECAP1ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a6e74093f6bcaf284d22924f17e4c82ae", null ],
      [ "EPWM1ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#aec99c0dbabd4c34e4645bb3f83b5b9dd", null ],
      [ "EPWM2ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a1db64813d530c8188b4d570ebbc2327b", null ],
      [ "EPWM3ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a18629aa50c49e02fc3dbe7e888deb457", null ],
      [ "EPWM4ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a393e14eaac54d2218287b543fad1bf2e", null ],
      [ "EPWM5ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#adc84bfd7d3a98cce57fafd44a4f71f86", null ],
      [ "EPWM6ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#af590ef0254da581717dc1c497b74c493", null ],
      [ "EPWM7ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a47beb27d6de0679a0afb271ab3c92d45", null ],
      [ "EQEP1ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#aba660657d56e0c8ae91d48b6f9a6754f", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a6783f7db0507a92abbb8a8954437acf1", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#adbca12f1b9390ac5bf35da54258df3b3", null ],
      [ "rsvd3", "_d_s_p2803x___sys_ctrl_8h.html#ab6de90353e52063bd794fe7490a18e4f", null ]
    ] ],
    [ "PCLKCR1_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_p_c_l_k_c_r1___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a926e917c0816d350e59b322430bf4671", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a0a537e89c134df8729cb1eea2b2128d8", null ]
    ] ],
    [ "PCLKCR3_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_p_c_l_k_c_r3___b_i_t_s", [
      [ "CLA1ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#ae589f3dfc4e8c4e621cda76d03d203e9", null ],
      [ "COMP1ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#ab7873a061134a6d7e490cf6185b99c26", null ],
      [ "COMP2ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a7b30d8e537565f11d7c3ba3450a83188", null ],
      [ "COMP3ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#abcea34454b6ded90987ee8b0a86c9df4", null ],
      [ "CPUTIMER0ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a449cafb3a2d36d7847f8c707a86d2658", null ],
      [ "CPUTIMER1ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#aac7aea219526dc1458fbf46bc404122f", null ],
      [ "CPUTIMER2ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a6b4c50852bde2078572c1c773c10c3ba", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a03d9795fea738b33c075dd55ed8f6e0b", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#a0cb9702a834a566cd007240c944204cb", null ],
      [ "rsvd3", "_d_s_p2803x___sys_ctrl_8h.html#af215ea34d810164538eff23d5c9cf0f6", null ]
    ] ],
    [ "PCLKCR3_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_p_c_l_k_c_r3___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a6d6c88c875ad6245dfa5e791b161201d", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a26c198098151254234fc20cd2bca291b", null ]
    ] ],
    [ "PCLKCR2_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_p_c_l_k_c_r2___b_i_t_s", [
      [ "HRCAP1ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#aa562438cb896b9e55b7346fd709c9ac0", null ],
      [ "HRCAP2ENCLK", "_d_s_p2803x___sys_ctrl_8h.html#a43c3d126342d73bf53068c5325f89812", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a048c1a023a49c3b12d53ef693a43c406", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#a9287e01c312a122a687cf42e295f29b5", null ]
    ] ],
    [ "PCLKCR2_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_p_c_l_k_c_r2___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#ab2f44f68bf7e2f6ac797ccb3938617a6", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a2895c39eb8ac89000f1880a947901982", null ]
    ] ],
    [ "PLLCR_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_p_l_l_c_r___b_i_t_s", [
      [ "DIV", "_d_s_p2803x___sys_ctrl_8h.html#ac084b5f9630ba377da1b825a52557d5f", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#ad08b3a787027d6e6c143788a1c63a4eb", null ]
    ] ],
    [ "PLLCR_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_p_l_l_c_r___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#ab5d69564dc97b4c9db0964f748b79f36", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a1eb34e9269da5517292176dd544c7e85", null ]
    ] ],
    [ "LPMCR0_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_l_p_m_c_r0___b_i_t_s", [
      [ "LPM", "_d_s_p2803x___sys_ctrl_8h.html#a0dd11dbf77e6190bb2e889160a314bab", null ],
      [ "QUALSTDBY", "_d_s_p2803x___sys_ctrl_8h.html#a4b57c1a9470af75c774798d18db0424b", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#aa0d1e76767df9dcf9f1f7edb4d67e825", null ],
      [ "WDINTE", "_d_s_p2803x___sys_ctrl_8h.html#ae02df05b44f6f2b89b927a500b80bf23", null ]
    ] ],
    [ "LPMCR0_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_l_p_m_c_r0___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a93d128db10fffb86e6fa0d53b7c35647", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#abc05ed63aaf36024e3e19b99b84104f2", null ]
    ] ],
    [ "SYS_CTRL_REGS", "_d_s_p2803x___sys_ctrl_8h.html#struct_s_y_s___c_t_r_l___r_e_g_s", [
      [ "CLKCTL", "_d_s_p2803x___sys_ctrl_8h.html#a87a79a18f4431554fe1b7d925da9f109", null ],
      [ "INTOSC1TRIM", "_d_s_p2803x___sys_ctrl_8h.html#a403a822c5797d758e4623f9543f33a29", null ],
      [ "INTOSC2TRIM", "_d_s_p2803x___sys_ctrl_8h.html#a938d8c4399132f2bf36242606ca6b443", null ],
      [ "LOSPCP", "_d_s_p2803x___sys_ctrl_8h.html#a47d376515ad8d8ea6ca56e9a01f967ba", null ],
      [ "LPMCR0", "_d_s_p2803x___sys_ctrl_8h.html#ae03e71e7962023480bf29bb486a2f290", null ],
      [ "PCLKCR0", "_d_s_p2803x___sys_ctrl_8h.html#acd238c6558115a6f6bc9ba60bb2b8048", null ],
      [ "PCLKCR1", "_d_s_p2803x___sys_ctrl_8h.html#ad4114eb042095b43d1aa33c19edcdd5b", null ],
      [ "PCLKCR2", "_d_s_p2803x___sys_ctrl_8h.html#a9425be01217db3cece2fcd9e1eb7c356", null ],
      [ "PCLKCR3", "_d_s_p2803x___sys_ctrl_8h.html#a8ff46de9dde77535c5975ceb732b794a", null ],
      [ "PLLCR", "_d_s_p2803x___sys_ctrl_8h.html#a8025cf3655933b18ac398fc1f7aac8ac", null ],
      [ "PLLLOCKPRD", "_d_s_p2803x___sys_ctrl_8h.html#ac2189e58509c228c67b03ab8ac19433a", null ],
      [ "PLLSTS", "_d_s_p2803x___sys_ctrl_8h.html#a13b1bddad30d3266f4160bc1fd0de68a", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a92fe15d379e0656fa835523dbca62358", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#a850403ec6116dca8c67b0f0c21d13980", null ],
      [ "rsvd3", "_d_s_p2803x___sys_ctrl_8h.html#a9790be6d3c12cb7a30e5a982b7d8635b", null ],
      [ "rsvd4", "_d_s_p2803x___sys_ctrl_8h.html#a770233f4e7f0eccd807279b48cb9d76d", null ],
      [ "rsvd5", "_d_s_p2803x___sys_ctrl_8h.html#a8d7c54fa03c9349cb769eaa45a72838f", null ],
      [ "rsvd6", "_d_s_p2803x___sys_ctrl_8h.html#a762915bfe57460770023a3d79221f7e8", null ],
      [ "rsvd7", "_d_s_p2803x___sys_ctrl_8h.html#af7821a52c69a159ae3927574f6ac31fc", null ],
      [ "SCSR", "_d_s_p2803x___sys_ctrl_8h.html#ae6000479e34b786d1bc87c6f2e42049d", null ],
      [ "WDCNTR", "_d_s_p2803x___sys_ctrl_8h.html#a92b24af23d12a6923e477f4468b839e2", null ],
      [ "WDCR", "_d_s_p2803x___sys_ctrl_8h.html#a3ceb4cad7e7068a2872a2d50c647745c", null ],
      [ "WDKEY", "_d_s_p2803x___sys_ctrl_8h.html#a1ed06323c33e1bba4a06aaf56186286a", null ],
      [ "XCLK", "_d_s_p2803x___sys_ctrl_8h.html#a8b90a98e47de4db8f9f3cc1e191dab54", null ]
    ] ],
    [ "BORCFG_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_b_o_r_c_f_g___b_i_t_s", [
      [ "BORENZ", "_d_s_p2803x___sys_ctrl_8h.html#a1a013e39c112b7c6ce9e95ad4adad372", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a11fe914023c1470cb6fe89e2f01c3429", null ]
    ] ],
    [ "BORCFG_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_b_o_r_c_f_g___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#afd339f614d1e8c64ae93d8937c770226", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#ad6f5b238332b1f833da7c30eb8994625", null ]
    ] ],
    [ "SYS_PWR_CTRL_REGS", "_d_s_p2803x___sys_ctrl_8h.html#struct_s_y_s___p_w_r___c_t_r_l___r_e_g_s", [
      [ "BORCFG", "_d_s_p2803x___sys_ctrl_8h.html#a6e6950559d6f0fb074b1ec1c3bd07e87", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a10be692731308b63242c4a8f8d54dc9a", null ]
    ] ],
    [ "CSMSCR_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_c_s_m_s_c_r___b_i_t_s", [
      [ "FORCESEC", "_d_s_p2803x___sys_ctrl_8h.html#aa410b0a58e542d686621a910c633e241", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a231f9bcb4cec686eda3df920afc80b3a", null ],
      [ "SECURE", "_d_s_p2803x___sys_ctrl_8h.html#af9a8d39bcfe9f90add69b261eb25b795", null ]
    ] ],
    [ "CSMSCR_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_c_s_m_s_c_r___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a8cae8c039202b2507d03cab325844976", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#afc38165358ce48cfba84877599c29bb3", null ]
    ] ],
    [ "CSM_REGS", "_d_s_p2803x___sys_ctrl_8h.html#struct_c_s_m___r_e_g_s", [
      [ "CSMSCR", "_d_s_p2803x___sys_ctrl_8h.html#ac8f9409f438f898359135dcec87670f8", null ],
      [ "KEY0", "_d_s_p2803x___sys_ctrl_8h.html#a7e06a87597063e7639e0d9594b64a815", null ],
      [ "KEY1", "_d_s_p2803x___sys_ctrl_8h.html#ad30fde77f060f4f690c010e011479855", null ],
      [ "KEY2", "_d_s_p2803x___sys_ctrl_8h.html#a66ce0b5b350b5ef634917e77a33d33ba", null ],
      [ "KEY3", "_d_s_p2803x___sys_ctrl_8h.html#a8ee53df67d4b8800b17abbec51631dfc", null ],
      [ "KEY4", "_d_s_p2803x___sys_ctrl_8h.html#ae15274359fc1e12c28362089732012a0", null ],
      [ "KEY5", "_d_s_p2803x___sys_ctrl_8h.html#a56af8aa2b4eeaf318b71a449f26bf663", null ],
      [ "KEY6", "_d_s_p2803x___sys_ctrl_8h.html#ac759c33046c4fd9fc61f746de092c078", null ],
      [ "KEY7", "_d_s_p2803x___sys_ctrl_8h.html#a7484c680a52621bb3796eae8bd80e7f0", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a73fdc3c764412fd753d6dcbd80fa072b", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#a8764b38dd3d522f0e91381302958eb78", null ],
      [ "rsvd3", "_d_s_p2803x___sys_ctrl_8h.html#a99e02d181935057376511671542dd61c", null ],
      [ "rsvd4", "_d_s_p2803x___sys_ctrl_8h.html#aae4e714538d044e01433943510615c54", null ],
      [ "rsvd5", "_d_s_p2803x___sys_ctrl_8h.html#adb1133c4a93f1b9e2dceda2b3dcf83a5", null ],
      [ "rsvd6", "_d_s_p2803x___sys_ctrl_8h.html#ae58303f1818d0833e2050b37be5f84f8", null ],
      [ "rsvd7", "_d_s_p2803x___sys_ctrl_8h.html#a2aa082d9f598ea9e0a93de9af6498c06", null ]
    ] ],
    [ "CSM_PWL", "_d_s_p2803x___sys_ctrl_8h.html#struct_c_s_m___p_w_l", [
      [ "PSWD0", "_d_s_p2803x___sys_ctrl_8h.html#a3d8f3f88f583af59df6436aa5cac7807", null ],
      [ "PSWD1", "_d_s_p2803x___sys_ctrl_8h.html#af3c3743d45b54af8d57a349bc1ab13a4", null ],
      [ "PSWD2", "_d_s_p2803x___sys_ctrl_8h.html#add8a4f2a2bcc3b4987a6622b2dec631a", null ],
      [ "PSWD3", "_d_s_p2803x___sys_ctrl_8h.html#a0423aae279c277031c59865c8231289c", null ],
      [ "PSWD4", "_d_s_p2803x___sys_ctrl_8h.html#a46d058d571dc38310acb1cc8972f8020", null ],
      [ "PSWD5", "_d_s_p2803x___sys_ctrl_8h.html#a68f79eeb333c4baf2cc0902c14db22f0", null ],
      [ "PSWD6", "_d_s_p2803x___sys_ctrl_8h.html#a4d58e243c2e2121bc0f87e12511421bd", null ],
      [ "PSWD7", "_d_s_p2803x___sys_ctrl_8h.html#abb13ae8c5d8b99203e18d5b0ea9c5792", null ]
    ] ],
    [ "FOPT_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_f_o_p_t___b_i_t_s", [
      [ "ENPIPE", "_d_s_p2803x___sys_ctrl_8h.html#a361e7496ee5059a373055063bcdaed20", null ],
      [ "rsvd", "_d_s_p2803x___sys_ctrl_8h.html#a39d2b2c0301e0cce10e1f0cb97591e63", null ]
    ] ],
    [ "FOPT_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_f_o_p_t___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a9a76411d7be66de47078d5f5ba236842", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a1b186a871005bdd73900c43bd4aa45c9", null ]
    ] ],
    [ "FPWR_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_f_p_w_r___b_i_t_s", [
      [ "PWR", "_d_s_p2803x___sys_ctrl_8h.html#a4d54370d9d141da652a5c729adb8252f", null ],
      [ "rsvd", "_d_s_p2803x___sys_ctrl_8h.html#a57f27439cf48049a7582c1c1f8298cdc", null ]
    ] ],
    [ "FPWR_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_f_p_w_r___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a1dbac8f10a721593bfed4c7d48168e80", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a4b6679e9ad0a5c691aeb596d27bf933f", null ]
    ] ],
    [ "FSTATUS_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_f_s_t_a_t_u_s___b_i_t_s", [
      [ "ACTIVEWAITS", "_d_s_p2803x___sys_ctrl_8h.html#a94ed8236a55892509cd30e8c9ad9d0a2", null ],
      [ "PWRS", "_d_s_p2803x___sys_ctrl_8h.html#a0c2da5d8192ee49caf2ee5cd99ce6156", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#aee514807140c6a9d0817d8487c8f17c5", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#ad12c115aa33da7b47f2a205ca7fa8698", null ],
      [ "STDBYWAITS", "_d_s_p2803x___sys_ctrl_8h.html#acb8fd0ba47941bb14991829c4338e301", null ],
      [ "V3STAT", "_d_s_p2803x___sys_ctrl_8h.html#aa00cd6ec86807a3d218d670b06526007", null ]
    ] ],
    [ "FSTATUS_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_f_s_t_a_t_u_s___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a1cf9569655267b3df3a7fadcb904cd65", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#abd9dab32178d2480a2be0f8c05560aad", null ]
    ] ],
    [ "FSTDBYWAIT_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_f_s_t_d_b_y_w_a_i_t___b_i_t_s", [
      [ "rsvd", "_d_s_p2803x___sys_ctrl_8h.html#aa05420e317ff33994846ee579aa96d97", null ],
      [ "STDBYWAIT", "_d_s_p2803x___sys_ctrl_8h.html#aa8b04e63dce365a4be147052f0e81966", null ]
    ] ],
    [ "FSTDBYWAIT_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_f_s_t_d_b_y_w_a_i_t___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#ab7dc0564d976b733ce61f4b0c1fda330", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a9373cc0e11fbfed38c003b846dac753f", null ]
    ] ],
    [ "FACTIVEWAIT_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_f_a_c_t_i_v_e_w_a_i_t___b_i_t_s", [
      [ "ACTIVEWAIT", "_d_s_p2803x___sys_ctrl_8h.html#a5c15af4a405316e22931ab8d7bf4a0b8", null ],
      [ "rsvd", "_d_s_p2803x___sys_ctrl_8h.html#a32609d601ac20bd394aba79efa655b42", null ]
    ] ],
    [ "FACTIVEWAIT_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_f_a_c_t_i_v_e_w_a_i_t___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#a47ada74d1099cebe7f42a4c21183c25c", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#ab9ddc5bbc54ac32460e14faf81728c09", null ]
    ] ],
    [ "FBANKWAIT_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_f_b_a_n_k_w_a_i_t___b_i_t_s", [
      [ "PAGEWAIT", "_d_s_p2803x___sys_ctrl_8h.html#ab71734d37cf0bcf6dec57611e02b16fd", null ],
      [ "RANDWAIT", "_d_s_p2803x___sys_ctrl_8h.html#a51e4f58ff980ecf2107b921d8511c5bb", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a0e349785deb6785684dc6171b0c01873", null ],
      [ "rsvd2", "_d_s_p2803x___sys_ctrl_8h.html#a4c11f6983334381618df77caee206ecf", null ]
    ] ],
    [ "FBANKWAIT_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_f_b_a_n_k_w_a_i_t___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#aedae156c4b8204ccec122c8ea5e8ead0", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#a94cadf33b8d56788736dbd7da4f32dc8", null ]
    ] ],
    [ "FOTPWAIT_BITS", "_d_s_p2803x___sys_ctrl_8h.html#struct_f_o_t_p_w_a_i_t___b_i_t_s", [
      [ "OTPWAIT", "_d_s_p2803x___sys_ctrl_8h.html#ae771a262cbcef7cd6697640e938c1c44", null ],
      [ "rsvd", "_d_s_p2803x___sys_ctrl_8h.html#af83512e965409fdf9a6eb167f9798d38", null ]
    ] ],
    [ "FOTPWAIT_REG", "_d_s_p2803x___sys_ctrl_8h.html#union_f_o_t_p_w_a_i_t___r_e_g", [
      [ "all", "_d_s_p2803x___sys_ctrl_8h.html#ab014549b16696d6ae7c81a15e8ba6985", null ],
      [ "bit", "_d_s_p2803x___sys_ctrl_8h.html#ae75b3daac3662a229c803d7c3c8c2509", null ]
    ] ],
    [ "FLASH_REGS", "_d_s_p2803x___sys_ctrl_8h.html#struct_f_l_a_s_h___r_e_g_s", [
      [ "FACTIVEWAIT", "_d_s_p2803x___sys_ctrl_8h.html#a40e915f21d965b80013e0001d1b1c655", null ],
      [ "FBANKWAIT", "_d_s_p2803x___sys_ctrl_8h.html#a02edad7918489475c25c28eba3cc2552", null ],
      [ "FOPT", "_d_s_p2803x___sys_ctrl_8h.html#a4e3737164105da516d12cf96d72e4462", null ],
      [ "FOTPWAIT", "_d_s_p2803x___sys_ctrl_8h.html#ab19b5708a0955d8ed65a2e534ed1d9ea", null ],
      [ "FPWR", "_d_s_p2803x___sys_ctrl_8h.html#a08947a9a22155823234bd3697acfa82c", null ],
      [ "FSTATUS", "_d_s_p2803x___sys_ctrl_8h.html#a6cab5a44e4b47f9a71c97561a6fd904b", null ],
      [ "FSTDBYWAIT", "_d_s_p2803x___sys_ctrl_8h.html#ac70507eabc1bf0e5539c4add4b93aed9", null ],
      [ "rsvd1", "_d_s_p2803x___sys_ctrl_8h.html#a908f202dcf45f912317192cf9217cc37", null ]
    ] ],
    [ "FLASH_ACTIVE", "_d_s_p2803x___sys_ctrl_8h.html#a1d9ab918a359cb8781d9c1f1c6786f0f", null ],
    [ "FLASH_SLEEP", "_d_s_p2803x___sys_ctrl_8h.html#a2dc9734a0b2f432f047075c63d48508b", null ],
    [ "FLASH_STANDBY", "_d_s_p2803x___sys_ctrl_8h.html#a871237900954b95dcc7a8813806f49f9", null ],
    [ "CsmPwl", "_d_s_p2803x___sys_ctrl_8h.html#ac9dc5e4502b16fb9b5cb23f5309681b8", null ],
    [ "CsmRegs", "_d_s_p2803x___sys_ctrl_8h.html#a1a144b03b3cc9af96c9b382be313f4ec", null ],
    [ "FlashRegs", "_d_s_p2803x___sys_ctrl_8h.html#a9948e3a8fba441406755db2526c2a6b6", null ],
    [ "SysCtrlRegs", "_d_s_p2803x___sys_ctrl_8h.html#a06a9b1dafff9d14e02c7a3945732a211", null ],
    [ "SysPwrCtrlRegs", "_d_s_p2803x___sys_ctrl_8h.html#abb84a76185036fcde2f878d8ea343a9a", null ]
];