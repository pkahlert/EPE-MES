var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "a", "globals_func_0x61.html", null ],
    [ "b", "globals_func_0x62.html", null ],
    [ "c", "globals_func_0x63.html", null ],
    [ "d", "globals_func_0x64.html", null ],
    [ "e", "globals_func_0x65.html", null ],
    [ "f", "globals_func_0x66.html", null ],
    [ "h", "globals_func_0x68.html", null ],
    [ "i", "globals_func_0x69.html", null ],
    [ "l", "globals_func_0x6c.html", null ],
    [ "m", "globals_func_0x6d.html", null ],
    [ "p", "globals_func_0x70.html", null ],
    [ "s", "globals_func_0x73.html", null ],
    [ "t", "globals_func_0x74.html", null ],
    [ "w", "globals_func_0x77.html", null ]
];