var _d_s_p2803x___gpio_8h =
[
    [ "GPACTRL_BITS", "_d_s_p2803x___gpio_8h.html#struct_g_p_a_c_t_r_l___b_i_t_s", [
      [ "QUALPRD0", "_d_s_p2803x___gpio_8h.html#a381d1c5f8c215931e8111274d30445dc", null ],
      [ "QUALPRD1", "_d_s_p2803x___gpio_8h.html#afbe6985bf678ffcf846614bb7f1f0507", null ],
      [ "QUALPRD2", "_d_s_p2803x___gpio_8h.html#a1bb5e7173a98248f70106c6048d4a5a4", null ],
      [ "QUALPRD3", "_d_s_p2803x___gpio_8h.html#aeb7639e10787b43b4bdbe6a9e362bb53", null ]
    ] ],
    [ "GPACTRL_REG", "_d_s_p2803x___gpio_8h.html#union_g_p_a_c_t_r_l___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#a2fe0bdb772eab62d30103039b13e0787", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#a6735d0cf7a08286497e508ed2be10428", null ]
    ] ],
    [ "GPBCTRL_BITS", "_d_s_p2803x___gpio_8h.html#struct_g_p_b_c_t_r_l___b_i_t_s", [
      [ "QUALPRD0", "_d_s_p2803x___gpio_8h.html#a6e190edbc8689646dde55e5e7ec48bf6", null ],
      [ "QUALPRD1", "_d_s_p2803x___gpio_8h.html#a216f7b8ca8d9fa96d23741c4b9190ea2", null ],
      [ "rsvd2", "_d_s_p2803x___gpio_8h.html#a4407401c007e2586f286e53a4e2d2a6a", null ]
    ] ],
    [ "GPBCTRL_REG", "_d_s_p2803x___gpio_8h.html#union_g_p_b_c_t_r_l___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#a6c9a5a1bb2ecf7e7e9782a38ad76b5f1", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#a395ea0635e645472960a09db6c851555", null ]
    ] ],
    [ "GPA1_BITS", "_d_s_p2803x___gpio_8h.html#struct_g_p_a1___b_i_t_s", [
      [ "GPIO0", "_d_s_p2803x___gpio_8h.html#ad770aeb6125d2434bdc6a96e8164a094", null ],
      [ "GPIO1", "_d_s_p2803x___gpio_8h.html#a72883a1bd144c6c9cd93a39d3763d0d8", null ],
      [ "GPIO10", "_d_s_p2803x___gpio_8h.html#a4856943e07d1e37a1b1f64b46841f50f", null ],
      [ "GPIO11", "_d_s_p2803x___gpio_8h.html#a8e3ced9b09a8fb39df0d4f1f5236a4b7", null ],
      [ "GPIO12", "_d_s_p2803x___gpio_8h.html#a256c057b15ce22be1298afe6425e3b74", null ],
      [ "GPIO13", "_d_s_p2803x___gpio_8h.html#a8ecf8e6048cf0c440cb7221910b4c09d", null ],
      [ "GPIO14", "_d_s_p2803x___gpio_8h.html#ab5c86d6c342b38eed7d6afb4e983451d", null ],
      [ "GPIO15", "_d_s_p2803x___gpio_8h.html#ad1a268e8e60f56fd3acca43b37bd642f", null ],
      [ "GPIO2", "_d_s_p2803x___gpio_8h.html#a017782b584b6b4f753cfbe21cfb3e148", null ],
      [ "GPIO3", "_d_s_p2803x___gpio_8h.html#add0fdcb0791f81ad95711e1c1ce3367a", null ],
      [ "GPIO4", "_d_s_p2803x___gpio_8h.html#ad4383f9004c70dee3fdf5983374bf51d", null ],
      [ "GPIO5", "_d_s_p2803x___gpio_8h.html#a017d53ff1b943ede86bfdd535bb2fbc3", null ],
      [ "GPIO6", "_d_s_p2803x___gpio_8h.html#ab2d5ab606730a1401600e11eb15b9619", null ],
      [ "GPIO7", "_d_s_p2803x___gpio_8h.html#ad3d2fcdf697e1df9c62d1f62ddb23cbd", null ],
      [ "GPIO8", "_d_s_p2803x___gpio_8h.html#adba7f5d08867e0325d9a18af346e0842", null ],
      [ "GPIO9", "_d_s_p2803x___gpio_8h.html#aff2c1b599b48835736926d2c5b1577bf", null ]
    ] ],
    [ "GPA2_BITS", "_d_s_p2803x___gpio_8h.html#struct_g_p_a2___b_i_t_s", [
      [ "GPIO16", "_d_s_p2803x___gpio_8h.html#a461a9315ae7ce63640cc0ba48be955f5", null ],
      [ "GPIO17", "_d_s_p2803x___gpio_8h.html#a9c5bf62bcb32ff8b1793c41dd5adc143", null ],
      [ "GPIO18", "_d_s_p2803x___gpio_8h.html#a179e29eba3afc9bf5e13bd491e67f719", null ],
      [ "GPIO19", "_d_s_p2803x___gpio_8h.html#a98b6380a48867540003bfc40335c8d87", null ],
      [ "GPIO20", "_d_s_p2803x___gpio_8h.html#afec08dcba8a0d15f24487131a51190e3", null ],
      [ "GPIO21", "_d_s_p2803x___gpio_8h.html#a4f703470c3d1a372a6e4ac830451c25e", null ],
      [ "GPIO22", "_d_s_p2803x___gpio_8h.html#ada0a5dab59cb09565e66bf15d9e458f1", null ],
      [ "GPIO23", "_d_s_p2803x___gpio_8h.html#a09dad0e58b557d26eec59c06a85bb9ba", null ],
      [ "GPIO24", "_d_s_p2803x___gpio_8h.html#a5a452719bb05f7a563d6ca1d670988e4", null ],
      [ "GPIO25", "_d_s_p2803x___gpio_8h.html#aae570fae8991fc006fb3b9f5c0eaf120", null ],
      [ "GPIO26", "_d_s_p2803x___gpio_8h.html#ae4fa4270167996d8007a642976990cc2", null ],
      [ "GPIO27", "_d_s_p2803x___gpio_8h.html#a0d372fdec8df1ab1359734b050761ad6", null ],
      [ "GPIO28", "_d_s_p2803x___gpio_8h.html#a371055b5684b12b54ac797367b24743f", null ],
      [ "GPIO29", "_d_s_p2803x___gpio_8h.html#a36673659ad7e911860e50df8ce5221fd", null ],
      [ "GPIO30", "_d_s_p2803x___gpio_8h.html#a19fb51642598c9b21cb79eff2c09c929", null ],
      [ "GPIO31", "_d_s_p2803x___gpio_8h.html#ae4a1fb2e1a0aec4792812fbd35f72a71", null ]
    ] ],
    [ "GPB1_BITS", "_d_s_p2803x___gpio_8h.html#struct_g_p_b1___b_i_t_s", [
      [ "GPIO32", "_d_s_p2803x___gpio_8h.html#a0be945b42bc0eae583a0be722112affa", null ],
      [ "GPIO33", "_d_s_p2803x___gpio_8h.html#a58a9e510ee748bd3e012e27e034fcc88", null ],
      [ "GPIO34", "_d_s_p2803x___gpio_8h.html#ab44083ee25a421e9e1de8ae8ce4d8069", null ],
      [ "GPIO35", "_d_s_p2803x___gpio_8h.html#a71bf7c6b0d085b6ed3373d17d1c1f97f", null ],
      [ "GPIO36", "_d_s_p2803x___gpio_8h.html#a2012fae7ab8a4a05f3362fbb9bbd4dfa", null ],
      [ "GPIO37", "_d_s_p2803x___gpio_8h.html#a0f034a8a55b24283754847bcc1e12fd3", null ],
      [ "GPIO38", "_d_s_p2803x___gpio_8h.html#a7ad27d48f2f6804acc443994f7df5065", null ],
      [ "GPIO39", "_d_s_p2803x___gpio_8h.html#acfe2518ad26a404eaaa1a196217f358a", null ],
      [ "GPIO40", "_d_s_p2803x___gpio_8h.html#a1d35eb957b09c7cfd2514e57e57840e3", null ],
      [ "GPIO41", "_d_s_p2803x___gpio_8h.html#a14351fc83cd2bf4b86031e05d2ad5b84", null ],
      [ "GPIO42", "_d_s_p2803x___gpio_8h.html#a5bba72b6563442f79dd2bb6b7ef2f053", null ],
      [ "GPIO43", "_d_s_p2803x___gpio_8h.html#a249ba15ec2d1790737075724124f28c6", null ],
      [ "GPIO44", "_d_s_p2803x___gpio_8h.html#ac3d3bf632ae12b2e4b23104762297163", null ],
      [ "rsvd1", "_d_s_p2803x___gpio_8h.html#a65b12e2d2d4370e0a218bbed8e3da227", null ]
    ] ],
    [ "AIO_BITS", "_d_s_p2803x___gpio_8h.html#struct_a_i_o___b_i_t_s", [
      [ "AIO10", "_d_s_p2803x___gpio_8h.html#a38547b7d18c4da9bc626ed06d359b8a4", null ],
      [ "AIO12", "_d_s_p2803x___gpio_8h.html#a34aced33b0fc22f8d357ec7489b492cd", null ],
      [ "AIO14", "_d_s_p2803x___gpio_8h.html#a1051328d17d8d209a285b2cb0876e713", null ],
      [ "AIO2", "_d_s_p2803x___gpio_8h.html#a0225978233556d6c440fdeb73e9ea812", null ],
      [ "AIO4", "_d_s_p2803x___gpio_8h.html#aadec1a4f9984bd3bad6c2aae58953aa2", null ],
      [ "AIO6", "_d_s_p2803x___gpio_8h.html#ae63334bcf1713bebe9115927cacdc752", null ],
      [ "rsvd1", "_d_s_p2803x___gpio_8h.html#ad7c48b3172ea54bc8f0edd5bd50e22d0", null ],
      [ "rsvd10", "_d_s_p2803x___gpio_8h.html#a66fb7a59be93738178f9687a75209997", null ],
      [ "rsvd2", "_d_s_p2803x___gpio_8h.html#a36bc51f589bbdc798196ceac769ec9c3", null ],
      [ "rsvd3", "_d_s_p2803x___gpio_8h.html#a0962935bfb043d9d3e7ed4ba6eaa474c", null ],
      [ "rsvd4", "_d_s_p2803x___gpio_8h.html#ad8b1a468ccc2496731b6b4ed4da8ba1a", null ],
      [ "rsvd5", "_d_s_p2803x___gpio_8h.html#abe675bb2a630420c0f7068e1c4bc75a0", null ],
      [ "rsvd6", "_d_s_p2803x___gpio_8h.html#acd1dab2864e6d0790472099431e17395", null ],
      [ "rsvd7", "_d_s_p2803x___gpio_8h.html#a521edfd686a9d0fd719711ecbbdbcd20", null ],
      [ "rsvd8", "_d_s_p2803x___gpio_8h.html#ab71461d49c79e887d0f8af758629d661", null ],
      [ "rsvd9", "_d_s_p2803x___gpio_8h.html#a9bed31c61aedb51be120886dc8c30077", null ]
    ] ],
    [ "GPA1_REG", "_d_s_p2803x___gpio_8h.html#union_g_p_a1___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#a4570f5195599b92ad0084dd3bbc9b17d", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#a36344dcd055b6bac21ff994fc323cda8", null ]
    ] ],
    [ "GPA2_REG", "_d_s_p2803x___gpio_8h.html#union_g_p_a2___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#acd8ad13a097fc14c03caf18d89352c31", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#a55447d19f51fb230c7a7b5e57b624f5e", null ]
    ] ],
    [ "GPB1_REG", "_d_s_p2803x___gpio_8h.html#union_g_p_b1___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#ac8f6e54fd1cd26295cc2e54ee5bd9230", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#a227ff344e3623960e459c3f6170cbf32", null ]
    ] ],
    [ "AIO_REG", "_d_s_p2803x___gpio_8h.html#union_a_i_o___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#adf3d2afd2dcea12faaa24d2da66a7387", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#a867476f6698d3c5b6a7fe4a9c7d320f0", null ]
    ] ],
    [ "GPADAT_BITS", "_d_s_p2803x___gpio_8h.html#struct_g_p_a_d_a_t___b_i_t_s", [
      [ "GPIO0", "_d_s_p2803x___gpio_8h.html#ac3f5536d7a957c9c0081e67abe9b41f6", null ],
      [ "GPIO1", "_d_s_p2803x___gpio_8h.html#af07cf5c7ee552b3d7294639cea9450bb", null ],
      [ "GPIO10", "_d_s_p2803x___gpio_8h.html#a9afa4de4d0f91972071fb94314fb4405", null ],
      [ "GPIO11", "_d_s_p2803x___gpio_8h.html#affb0760aa2890f00cea2406bd1a24d29", null ],
      [ "GPIO12", "_d_s_p2803x___gpio_8h.html#a5ddf666d63178e83dcd2d53a1eb1bd88", null ],
      [ "GPIO13", "_d_s_p2803x___gpio_8h.html#a9504e4f9108b2aa9c6703cd396cb04df", null ],
      [ "GPIO14", "_d_s_p2803x___gpio_8h.html#a38232df8eccba68c51756bcecac29f82", null ],
      [ "GPIO15", "_d_s_p2803x___gpio_8h.html#af4e83c094ec9a3b552ed1530b6e65b3d", null ],
      [ "GPIO16", "_d_s_p2803x___gpio_8h.html#a47070728f97fc17ed61cf8a0a38f7cdc", null ],
      [ "GPIO17", "_d_s_p2803x___gpio_8h.html#ada6fbf9a24a7127d1e8478630c4f8cff", null ],
      [ "GPIO18", "_d_s_p2803x___gpio_8h.html#a5435bf5c9f3fe616cfdeb751ef52dd86", null ],
      [ "GPIO19", "_d_s_p2803x___gpio_8h.html#aa38e2e510b2afeb8d1fcbb7e2b09ae50", null ],
      [ "GPIO2", "_d_s_p2803x___gpio_8h.html#af8a7d31ee85edc78a56d89a74b90d64e", null ],
      [ "GPIO20", "_d_s_p2803x___gpio_8h.html#a4ced84efa3071648d0819f7e1953d4cc", null ],
      [ "GPIO21", "_d_s_p2803x___gpio_8h.html#adfdcbdf32e684acbc0fd0664eaa7c2f2", null ],
      [ "GPIO22", "_d_s_p2803x___gpio_8h.html#a49bdba9fe5bd1fcaa015fa2365963a85", null ],
      [ "GPIO23", "_d_s_p2803x___gpio_8h.html#a4ab19f1cbcd22e9c6da8f216483ca432", null ],
      [ "GPIO24", "_d_s_p2803x___gpio_8h.html#ab6d87fdc8e1a33ed7bcf9e0cd816031d", null ],
      [ "GPIO25", "_d_s_p2803x___gpio_8h.html#a9f48d3f001a5e646fb1805ae91ce9f07", null ],
      [ "GPIO26", "_d_s_p2803x___gpio_8h.html#aa658b5f1a60e0e1e10ebfbda9d8783fa", null ],
      [ "GPIO27", "_d_s_p2803x___gpio_8h.html#a5fd9609a9ad81f2ab7d7adf825c80a29", null ],
      [ "GPIO28", "_d_s_p2803x___gpio_8h.html#ac3267808b7af3692118e5393f55719a6", null ],
      [ "GPIO29", "_d_s_p2803x___gpio_8h.html#a98fb82d196423e4028c3ba570054258e", null ],
      [ "GPIO3", "_d_s_p2803x___gpio_8h.html#ae0cdbcd198c504b596d2d8dfde9cc13c", null ],
      [ "GPIO30", "_d_s_p2803x___gpio_8h.html#a40ad925bcdf753994505dd9b27f42c5b", null ],
      [ "GPIO31", "_d_s_p2803x___gpio_8h.html#accaf2bccc5392103755b36c7dc7cbd0d", null ],
      [ "GPIO4", "_d_s_p2803x___gpio_8h.html#a60e900937c2d93c7f1a25d32ca8eefbc", null ],
      [ "GPIO5", "_d_s_p2803x___gpio_8h.html#a5ea180a156d9d32e889b3a4af4ecd7e8", null ],
      [ "GPIO6", "_d_s_p2803x___gpio_8h.html#a9542378c2ac1c876ef158e2329453dda", null ],
      [ "GPIO7", "_d_s_p2803x___gpio_8h.html#ad466d5fdc128e643c0a3208e7b053c16", null ],
      [ "GPIO8", "_d_s_p2803x___gpio_8h.html#add12038a6e1717beabf8569c959ef374", null ],
      [ "GPIO9", "_d_s_p2803x___gpio_8h.html#a26ae2b7aa7309fd84edcecd533082caf", null ]
    ] ],
    [ "GPBDAT_BITS", "_d_s_p2803x___gpio_8h.html#struct_g_p_b_d_a_t___b_i_t_s", [
      [ "GPIO32", "_d_s_p2803x___gpio_8h.html#a981125143e66de959da1abfd017fc312", null ],
      [ "GPIO33", "_d_s_p2803x___gpio_8h.html#a111131d857008ac74381f5df451e4d5e", null ],
      [ "GPIO34", "_d_s_p2803x___gpio_8h.html#ab83ff2fae58e99199de5c11d6d023df1", null ],
      [ "GPIO35", "_d_s_p2803x___gpio_8h.html#afb7dceb60d7307dc7c5b00c1e73caf30", null ],
      [ "GPIO36", "_d_s_p2803x___gpio_8h.html#aebb82f21e819b0e764b5ad19af88bd4a", null ],
      [ "GPIO37", "_d_s_p2803x___gpio_8h.html#aa1befdf28c641d439f64b45a02df65d8", null ],
      [ "GPIO38", "_d_s_p2803x___gpio_8h.html#a4e934b93cd175ac43d0ae09c51cff1e8", null ],
      [ "GPIO39", "_d_s_p2803x___gpio_8h.html#a76bbad5b5cf23725ce2968c9ffff75b6", null ],
      [ "GPIO40", "_d_s_p2803x___gpio_8h.html#a6fee46b1d1b1b1059150c887478515c5", null ],
      [ "GPIO41", "_d_s_p2803x___gpio_8h.html#a2e747f4f7413af54291f8e2ddc087b1c", null ],
      [ "GPIO42", "_d_s_p2803x___gpio_8h.html#a93cdc3eb74f7ae3d15aeddbe0313bdf0", null ],
      [ "GPIO43", "_d_s_p2803x___gpio_8h.html#aae8fdd5bb5d0a1730faabbc5873b8a71", null ],
      [ "GPIO44", "_d_s_p2803x___gpio_8h.html#a6e3da90780a56127eb66c9e0a68103d7", null ],
      [ "rsvd1", "_d_s_p2803x___gpio_8h.html#a1bb8235776979571b875067586f52d7e", null ],
      [ "rsvd2", "_d_s_p2803x___gpio_8h.html#a43808c93675f341c23c9abcec3facf87", null ]
    ] ],
    [ "AIODAT_BITS", "_d_s_p2803x___gpio_8h.html#struct_a_i_o_d_a_t___b_i_t_s", [
      [ "AIO10", "_d_s_p2803x___gpio_8h.html#ae587a74b97404b79bbcfb8f6dcf50f57", null ],
      [ "AIO12", "_d_s_p2803x___gpio_8h.html#aa3db751d27d5c69479dbcaad2b6c53f5", null ],
      [ "AIO14", "_d_s_p2803x___gpio_8h.html#a333776b98808d214c4fd93c654826e30", null ],
      [ "AIO2", "_d_s_p2803x___gpio_8h.html#a526c16cfa5f8fde463780d3590c45593", null ],
      [ "AIO4", "_d_s_p2803x___gpio_8h.html#af1489d2160b81a3d38695c178d0bed35", null ],
      [ "AIO6", "_d_s_p2803x___gpio_8h.html#a23b9f7d26b828c7364c2ffeab3d03c73", null ],
      [ "rsvd1", "_d_s_p2803x___gpio_8h.html#a319e363eb7a5c18c2d682ac89502cd47", null ],
      [ "rsvd10", "_d_s_p2803x___gpio_8h.html#ac48914e1c2033bf4461441f8362d7451", null ],
      [ "rsvd2", "_d_s_p2803x___gpio_8h.html#a7cc71d1559900da1b73221e57534571e", null ],
      [ "rsvd3", "_d_s_p2803x___gpio_8h.html#a1fb52355b42f72a075e43bc2ff2de075", null ],
      [ "rsvd4", "_d_s_p2803x___gpio_8h.html#a8d4f575588694d91f5817010fb1739ac", null ],
      [ "rsvd5", "_d_s_p2803x___gpio_8h.html#adc494651d9f418a328b2607b08cecc20", null ],
      [ "rsvd6", "_d_s_p2803x___gpio_8h.html#a3655ec73d3287407c2351d9fb000dc2e", null ],
      [ "rsvd7", "_d_s_p2803x___gpio_8h.html#a9fdb173d7fb582321a6df1b2a6f596d2", null ],
      [ "rsvd8", "_d_s_p2803x___gpio_8h.html#af29e93fd9fbd17e19c53dd7d8654f478", null ],
      [ "rsvd9", "_d_s_p2803x___gpio_8h.html#ae46e9c4f112e9a6680b6728cbfebd241", null ]
    ] ],
    [ "GPADAT_REG", "_d_s_p2803x___gpio_8h.html#union_g_p_a_d_a_t___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#a529384777c9a527658109b0a00d472e1", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#ab89336279405e10b3735b2cfa53f9c74", null ]
    ] ],
    [ "GPBDAT_REG", "_d_s_p2803x___gpio_8h.html#union_g_p_b_d_a_t___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#a23e77e094dc4db8362dd12feda55a219", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#ace89803ea35885e7876a1c3b5f2bf5e9", null ]
    ] ],
    [ "AIODAT_REG", "_d_s_p2803x___gpio_8h.html#union_a_i_o_d_a_t___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#add1f4681bab468dda9ee08959eb82c24", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#a0715f93ce1fcd7ae82d571d61e4627eb", null ]
    ] ],
    [ "GPIOXINT_BITS", "_d_s_p2803x___gpio_8h.html#struct_g_p_i_o_x_i_n_t___b_i_t_s", [
      [ "GPIOSEL", "_d_s_p2803x___gpio_8h.html#a0eeb47a8aecc2cc436fe8e14e261ede4", null ],
      [ "rsvd1", "_d_s_p2803x___gpio_8h.html#aa460c9e58914bcc6398f172662e232c1", null ]
    ] ],
    [ "GPIOXINT_REG", "_d_s_p2803x___gpio_8h.html#union_g_p_i_o_x_i_n_t___r_e_g", [
      [ "all", "_d_s_p2803x___gpio_8h.html#a567dc5e26b43cf9ea4728c755c78dc84", null ],
      [ "bit", "_d_s_p2803x___gpio_8h.html#a033840a01a0c9470605ada223c057928", null ]
    ] ],
    [ "GPIO_CTRL_REGS", "_d_s_p2803x___gpio_8h.html#struct_g_p_i_o___c_t_r_l___r_e_g_s", [
      [ "AIODIR", "_d_s_p2803x___gpio_8h.html#ac7f9fc7e8a12278599c14443f1af5862", null ],
      [ "AIOMUX1", "_d_s_p2803x___gpio_8h.html#a4d900f5fcc56e48ee6eb463eb66ae319", null ],
      [ "GPACTRL", "_d_s_p2803x___gpio_8h.html#ad99e4d5e7720e5c446fbe5b908774d99", null ],
      [ "GPADIR", "_d_s_p2803x___gpio_8h.html#a38950b2a5bf15f007c127ed833d8ed70", null ],
      [ "GPAMUX1", "_d_s_p2803x___gpio_8h.html#aa61a65b9fdc7cbb2fb155137171857b5", null ],
      [ "GPAMUX2", "_d_s_p2803x___gpio_8h.html#ad275b7e2f978ba4df141f52bd0f407f6", null ],
      [ "GPAPUD", "_d_s_p2803x___gpio_8h.html#a18d16e95d398eaaf8076730793e8d57b", null ],
      [ "GPAQSEL1", "_d_s_p2803x___gpio_8h.html#a35efd78dbe398d76d1840a2207a9d695", null ],
      [ "GPAQSEL2", "_d_s_p2803x___gpio_8h.html#aa8653fc3c9b06de3010610f6f07c2855", null ],
      [ "GPBCTRL", "_d_s_p2803x___gpio_8h.html#ae3ed6dd1954f3f1913e4105a2d532d90", null ],
      [ "GPBDIR", "_d_s_p2803x___gpio_8h.html#aeb62e68c3105aa59a3a5ddd435df992d", null ],
      [ "GPBMUX1", "_d_s_p2803x___gpio_8h.html#ae944bcdeca2f5052da1b8c6ff66caa19", null ],
      [ "GPBPUD", "_d_s_p2803x___gpio_8h.html#a6e2d71ceebe281273d7bcc8b3c33f8b3", null ],
      [ "GPBQSEL1", "_d_s_p2803x___gpio_8h.html#adbe3c0baefa6e8dd7cea974b40e8550a", null ],
      [ "rsvd1", "_d_s_p2803x___gpio_8h.html#a85066fcf35918e216ba6e16d18372ac8", null ],
      [ "rsvd2", "_d_s_p2803x___gpio_8h.html#af2201c06faae11cee8c45db067486a20", null ],
      [ "rsvd3", "_d_s_p2803x___gpio_8h.html#ae6790a162bce2ce41704dff902f386c2", null ],
      [ "rsvd4", "_d_s_p2803x___gpio_8h.html#a4f48ed726c6ab074051b734020029e72", null ],
      [ "rsvd5", "_d_s_p2803x___gpio_8h.html#a914af2a4206db8e2badb60ac78c4b651", null ],
      [ "rsvd6", "_d_s_p2803x___gpio_8h.html#a2a852c87d77bb1740332ab139b940ccf", null ]
    ] ],
    [ "GPIO_DATA_REGS", "_d_s_p2803x___gpio_8h.html#struct_g_p_i_o___d_a_t_a___r_e_g_s", [
      [ "AIOCLEAR", "_d_s_p2803x___gpio_8h.html#a5df60813fcb08358f24cea1bbfef3c12", null ],
      [ "AIODAT", "_d_s_p2803x___gpio_8h.html#a1bbc831d8647887541a2e09d9f05ed05", null ],
      [ "AIOSET", "_d_s_p2803x___gpio_8h.html#a0b9c695d4bc2db48faf456211d498016", null ],
      [ "AIOTOGGLE", "_d_s_p2803x___gpio_8h.html#a237d956bd8f96eaaf4db4416887b5586", null ],
      [ "GPACLEAR", "_d_s_p2803x___gpio_8h.html#a66b4427575a86b91795dabdc6a361e69", null ],
      [ "GPADAT", "_d_s_p2803x___gpio_8h.html#a85f4f90fde565247c25e38e8ca66ac8a", null ],
      [ "GPASET", "_d_s_p2803x___gpio_8h.html#a8828ae9beffd4ff2c86f5edbe7bf8eae", null ],
      [ "GPATOGGLE", "_d_s_p2803x___gpio_8h.html#a40a58d8dab5ec4ff9c79ef1db970e65e", null ],
      [ "GPBCLEAR", "_d_s_p2803x___gpio_8h.html#a5655e29e2cae26360246e87942d97e28", null ],
      [ "GPBDAT", "_d_s_p2803x___gpio_8h.html#ac6805f9c6b35efee1905310bbe42dd2e", null ],
      [ "GPBSET", "_d_s_p2803x___gpio_8h.html#adbfd6f9f7c582027c1b3fe5aa9096aab", null ],
      [ "GPBTOGGLE", "_d_s_p2803x___gpio_8h.html#a3ab36ec281be3524adf068a5edb85f5c", null ],
      [ "rsvd1", "_d_s_p2803x___gpio_8h.html#ae33ce91255743df8b4221c0c70d64792", null ],
      [ "rsvd2", "_d_s_p2803x___gpio_8h.html#afad5894fe0393684b9f08a688f170231", null ],
      [ "rsvd3", "_d_s_p2803x___gpio_8h.html#a180582d1a751e51a587e4e7b5c399c95", null ],
      [ "rsvd4", "_d_s_p2803x___gpio_8h.html#a5999c53f21cd9a216448597f4efc9cfa", null ],
      [ "rsvd5", "_d_s_p2803x___gpio_8h.html#ab8b2fcf4e5f65ae113bc061496e63c7d", null ]
    ] ],
    [ "GPIO_INT_REGS", "_d_s_p2803x___gpio_8h.html#struct_g_p_i_o___i_n_t___r_e_g_s", [
      [ "GPIOLPMSEL", "_d_s_p2803x___gpio_8h.html#a0b444af67e75935725bc5b7a68171e0d", null ],
      [ "GPIOXINT1SEL", "_d_s_p2803x___gpio_8h.html#a7160ca361c5037ee7f7d0264e0db210d", null ],
      [ "GPIOXINT2SEL", "_d_s_p2803x___gpio_8h.html#a07ece14fc658b96ef1c7f4247f0bd50b", null ],
      [ "GPIOXINT3SEL", "_d_s_p2803x___gpio_8h.html#a3968f7df5ef670ff333a6b9fbf1df8bd", null ],
      [ "rsvd1", "_d_s_p2803x___gpio_8h.html#a50537536ee1a5c77cde5b4cef89a720e", null ],
      [ "rsvd2", "_d_s_p2803x___gpio_8h.html#a293dd8f5e933a098f4800d668b00067d", null ]
    ] ],
    [ "GpioCtrlRegs", "_d_s_p2803x___gpio_8h.html#a1283c4977f4ffafe003fcc3c77221ed3", null ],
    [ "GpioDataRegs", "_d_s_p2803x___gpio_8h.html#af28a7174a784af9b7db6ed653bd4bd41", null ],
    [ "GpioIntRegs", "_d_s_p2803x___gpio_8h.html#a83a32378b729c6f472eda8cd3c9c359c", null ]
];