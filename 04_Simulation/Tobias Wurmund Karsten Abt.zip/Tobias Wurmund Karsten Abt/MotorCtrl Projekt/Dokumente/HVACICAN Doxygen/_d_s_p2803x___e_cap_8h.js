var _d_s_p2803x___e_cap_8h =
[
    [ "ECCTL1_BITS", "_d_s_p2803x___e_cap_8h.html#struct_e_c_c_t_l1___b_i_t_s", [
      [ "CAP1POL", "_d_s_p2803x___e_cap_8h.html#a94f4047f64935d56428dbd9596d56138", null ],
      [ "CAP2POL", "_d_s_p2803x___e_cap_8h.html#a9e878df10ce215f351606238448633ab", null ],
      [ "CAP3POL", "_d_s_p2803x___e_cap_8h.html#aea28a992f2d7b073f816fc518c54d69e", null ],
      [ "CAP4POL", "_d_s_p2803x___e_cap_8h.html#a2b024101df33249c4ade9fb94f5cd891", null ],
      [ "CAPLDEN", "_d_s_p2803x___e_cap_8h.html#a8d904ef611ec2cb9caab24349d91a2e8", null ],
      [ "CTRRST1", "_d_s_p2803x___e_cap_8h.html#aee503cfff7ced8f3b06596249d6d7732", null ],
      [ "CTRRST2", "_d_s_p2803x___e_cap_8h.html#a1c1ce2b561c5e83af44b049bcd37fa37", null ],
      [ "CTRRST3", "_d_s_p2803x___e_cap_8h.html#a3709cf2a23fd835fd10e5deeae171506", null ],
      [ "CTRRST4", "_d_s_p2803x___e_cap_8h.html#a856b9e8c71efcd3a46c8ae4ab41e5676", null ],
      [ "FREE_SOFT", "_d_s_p2803x___e_cap_8h.html#a6aee455b23fcba9d3f3957e075c14120", null ],
      [ "PRESCALE", "_d_s_p2803x___e_cap_8h.html#a3d52ff7e82a942c1fd1b0b1557b7ef76", null ]
    ] ],
    [ "ECCTL1_REG", "_d_s_p2803x___e_cap_8h.html#union_e_c_c_t_l1___r_e_g", [
      [ "all", "_d_s_p2803x___e_cap_8h.html#a075e068fb5842891beda01182b652e0c", null ],
      [ "bit", "_d_s_p2803x___e_cap_8h.html#ad17fd4d0830d024d2f29abcadf651806", null ]
    ] ],
    [ "ECCTL2_BITS", "_d_s_p2803x___e_cap_8h.html#struct_e_c_c_t_l2___b_i_t_s", [
      [ "APWMPOL", "_d_s_p2803x___e_cap_8h.html#a3384e0b748d0e45dfc9a6df07b3f96d1", null ],
      [ "CAP_APWM", "_d_s_p2803x___e_cap_8h.html#a5a370ab37413118cd3509cd666066b4f", null ],
      [ "CONT_ONESHT", "_d_s_p2803x___e_cap_8h.html#a14aaad9e9e0c72f168966250acb005dc", null ],
      [ "REARM", "_d_s_p2803x___e_cap_8h.html#a0bf6b1897a0c9996d6af69cf556faf02", null ],
      [ "rsvd1", "_d_s_p2803x___e_cap_8h.html#a3bcf558007fd7ddf770f781c9c3e7aae", null ],
      [ "STOP_WRAP", "_d_s_p2803x___e_cap_8h.html#ac0eb9714435ec841c66225b6ddc4f272", null ],
      [ "SWSYNC", "_d_s_p2803x___e_cap_8h.html#ac74e602ef54f51c03a9c1a4f3fd37f83", null ],
      [ "SYNCI_EN", "_d_s_p2803x___e_cap_8h.html#af9812042d466ebeec961ae900da093a8", null ],
      [ "SYNCO_SEL", "_d_s_p2803x___e_cap_8h.html#a04d25d4e6b9af8542a1b51f89370992c", null ],
      [ "TSCTRSTOP", "_d_s_p2803x___e_cap_8h.html#a8cbdc454e8e8a6026e2c7cc283d53e14", null ]
    ] ],
    [ "ECCTL2_REG", "_d_s_p2803x___e_cap_8h.html#union_e_c_c_t_l2___r_e_g", [
      [ "all", "_d_s_p2803x___e_cap_8h.html#a8b4bd86d229b37c2fe48d7f073484f6e", null ],
      [ "bit", "_d_s_p2803x___e_cap_8h.html#a128462e351fa97a90d6488945404d538", null ]
    ] ],
    [ "ECEINT_BITS", "_d_s_p2803x___e_cap_8h.html#struct_e_c_e_i_n_t___b_i_t_s", [
      [ "CEVT1", "_d_s_p2803x___e_cap_8h.html#ad2efafbc0ad99d74d64a8fb7d084363e", null ],
      [ "CEVT2", "_d_s_p2803x___e_cap_8h.html#a2fbef3b6d5a81c0158e1572880ef5242", null ],
      [ "CEVT3", "_d_s_p2803x___e_cap_8h.html#a9af94a18cf2d6ba5aefc191d568de6cb", null ],
      [ "CEVT4", "_d_s_p2803x___e_cap_8h.html#aeb37cf07a287eb8f15d3bebd5f332eb8", null ],
      [ "CTR_EQ_CMP", "_d_s_p2803x___e_cap_8h.html#a3e35ee86f8942c3d9c178b981c5e78c2", null ],
      [ "CTR_EQ_PRD", "_d_s_p2803x___e_cap_8h.html#ab6d627ea5c198a0f3791918b6d1d928a", null ],
      [ "CTROVF", "_d_s_p2803x___e_cap_8h.html#a17cf1a9a494ae3dca3b46dab502bec97", null ],
      [ "rsvd1", "_d_s_p2803x___e_cap_8h.html#a790cd8d5945052c1f742b321290eb632", null ],
      [ "rsvd2", "_d_s_p2803x___e_cap_8h.html#a05a2a5468e9c0421d82b10b9c6bafd30", null ]
    ] ],
    [ "ECEINT_REG", "_d_s_p2803x___e_cap_8h.html#union_e_c_e_i_n_t___r_e_g", [
      [ "all", "_d_s_p2803x___e_cap_8h.html#a05772d66509f4bd93db324e8b82b1794", null ],
      [ "bit", "_d_s_p2803x___e_cap_8h.html#abcc762591cd216e560fc38be7be539ee", null ]
    ] ],
    [ "ECFLG_BITS", "_d_s_p2803x___e_cap_8h.html#struct_e_c_f_l_g___b_i_t_s", [
      [ "CEVT1", "_d_s_p2803x___e_cap_8h.html#a393e73a8458e1e612f02b139983f3592", null ],
      [ "CEVT2", "_d_s_p2803x___e_cap_8h.html#ad29b523dc5a22b99deb6a40959855bde", null ],
      [ "CEVT3", "_d_s_p2803x___e_cap_8h.html#a7ec3741636c80d563584414af6fe8df7", null ],
      [ "CEVT4", "_d_s_p2803x___e_cap_8h.html#a5e349199201609c7cd0cb748dd182cb2", null ],
      [ "CTR_EQ_CMP", "_d_s_p2803x___e_cap_8h.html#a8a5ffee9e2323a54c5273ca529f4310f", null ],
      [ "CTR_EQ_PRD", "_d_s_p2803x___e_cap_8h.html#a664ef83feafe31149ab2f19312f017b0", null ],
      [ "CTROVF", "_d_s_p2803x___e_cap_8h.html#ab1417dade7485b40d47bb64b5b3eef81", null ],
      [ "INT", "_d_s_p2803x___e_cap_8h.html#ab6f86fdb07a28c59d8cab3000aeaa971", null ],
      [ "rsvd2", "_d_s_p2803x___e_cap_8h.html#a37e13d634434a5accdf84ff95b5acc6e", null ]
    ] ],
    [ "ECFLG_REG", "_d_s_p2803x___e_cap_8h.html#union_e_c_f_l_g___r_e_g", [
      [ "all", "_d_s_p2803x___e_cap_8h.html#a169489924d1cf0694a41a5d421f2006d", null ],
      [ "bit", "_d_s_p2803x___e_cap_8h.html#a187d6453b8749a5c349f2bf838581e31", null ]
    ] ],
    [ "ECAP_REGS", "_d_s_p2803x___e_cap_8h.html#struct_e_c_a_p___r_e_g_s", [
      [ "CAP1", "_d_s_p2803x___e_cap_8h.html#a5a05dbca568a792018da16891acae3c8", null ],
      [ "CAP2", "_d_s_p2803x___e_cap_8h.html#a3bebb090261767e32bbfa4a166d1f9bc", null ],
      [ "CAP3", "_d_s_p2803x___e_cap_8h.html#a4c9775132229605a80476b5c02fce840", null ],
      [ "CAP4", "_d_s_p2803x___e_cap_8h.html#a6aac307e836bc7028a35701e1e551203", null ],
      [ "CTRPHS", "_d_s_p2803x___e_cap_8h.html#a72fa3140be072978df30c73647d629b2", null ],
      [ "ECCLR", "_d_s_p2803x___e_cap_8h.html#adac3d7edbb10e57159958c36d3eb43b3", null ],
      [ "ECCTL1", "_d_s_p2803x___e_cap_8h.html#aa99878bb52d4091b5f68911435bf41ba", null ],
      [ "ECCTL2", "_d_s_p2803x___e_cap_8h.html#a6796138ea8c100dcb295ab5f639b8f77", null ],
      [ "ECEINT", "_d_s_p2803x___e_cap_8h.html#a4e0a782f9f422e3032dec725f7c7ef69", null ],
      [ "ECFLG", "_d_s_p2803x___e_cap_8h.html#a7ded1715c5d811cee06c18ef4536d5c2", null ],
      [ "ECFRC", "_d_s_p2803x___e_cap_8h.html#aac4672948d6b2a31af2bab995cad912d", null ],
      [ "rsvd1", "_d_s_p2803x___e_cap_8h.html#a37da0f873b57fe54332a26839355000b", null ],
      [ "rsvd2", "_d_s_p2803x___e_cap_8h.html#a7f2037bf2181e25aa04fa346139e7ae9", null ],
      [ "TSCTR", "_d_s_p2803x___e_cap_8h.html#aaec359f7445364075ac3bc2120dc34de", null ]
    ] ],
    [ "ECap1Regs", "_d_s_p2803x___e_cap_8h.html#a93428339318e5c5a2b67304650e44ad5", null ]
];